/*
 * File  : InAnimRadarPic.bmp
 * Width : 4
 * Height: 4
*/
#define INANIMRADARPIC_WIDTH   (4)
#define INANIMRADARPIC_HEIGHT  (4)
#define INANIMRADARPIC_SIZE   (16)

const u32 InAnimRadarPic_Bitmap[4*4]={
0x49AB4E72, 0x49AB4E72, 
0x4EB54E6F, 0x4EB54E6F, 
0x49AB4E72, 0x49AB4E72, 
0x4EB54E6F, 0x4EB54E6F, 
};
/* END OF FILE */
