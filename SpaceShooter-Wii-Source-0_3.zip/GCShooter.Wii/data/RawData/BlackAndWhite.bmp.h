/*
 * File  : BlackAndWhite.bmp
 * Width : 2
 * Height: 4
*/
#define BLACKANDWHITE_WIDTH   (2)
#define BLACKANDWHITE_HEIGHT  (4)
#define BLACKANDWHITE_SIZE   (8)

const u32 BlackAndWhite_Bitmap[4*2]={
0xFF80FF80, 	// WHITE WHITE
0x0080FF80, 	// BLACK WHITE
0xFF800080, 	// WHITE BLACK
0x00800080, 	// BLACK BLACK
};
/* END OF FILE */
