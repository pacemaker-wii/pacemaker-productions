###########################################################
# Bitmap to Y1CbY2Cr Converter Utility (c) Peter          #
###########################################################


"Bitmap to Y1CbY2Cr Converter Utility" is supplied as is.
The author disclaims all warranties, expressed or implied, 
including, without limitation the warranties of merchantability 
and of fitness for any purpose.

The author assumes no liability for damages, direct or 
consequential, which may result from the use of 
"Bitmap to Y1CbY2Cr Converter Utility".


###########################################################
# Whats it do                                             #
###########################################################

This programm converts 4/8/16/24 colordepth bitmaps images
into either an 1D array or a 2D c/c++ arrays where 2 pixels are
packed together and will be stored as Y1CbY2Cr format.

Starts at top left and ends at the bottom right

###########################################################
# Usage                                                   #
###########################################################

Usage: gfx2gx.exe [-mode] <bitmap file>

Modes:
       -1d  :  Create 1D c/c++ array
       -2d  :  Create 2D c/c++ array

###########################################################
# Updates and Fixes                                       #
###########################################################

22/06/2003 - Initial Release


###########################################################
# Website                                                 #
###########################################################

http://www.console-dev.de



+++ EOF +++