/*



	Level loading / setting up object



*/

#include <fstream>

#include "ShooterLevelLoader.h"
#include "ShooterWorld.h"
#include "GameConstants.h"


#include "ShooterLevels.h"


bool ShooterLevelLoader::LoadLevel (int nLevel, char * szLevelTitle, class ShooterWorld * pWorld)
{
int x, y, nNumItems;
const char * szOneLine;
char szSubLevelTitle [256];
char szItemName [256];
char * p;
int nLevelDataIndex;



	// First find the correct level
	sprintf (szSubLevelTitle, "Level %d", nLevel);
	bool bFoundIt = false;
	nLevelDataIndex = 0;
	while ((szOneLine = LevelData [nLevelDataIndex]) != NULL)
	{
		nLevelDataIndex ++;

		// Ignore comments.
		if (szOneLine [0] == '#')
			continue;

		// Look for the correct start of the title.
		if (strncmp (szOneLine, szSubLevelTitle, strlen (szSubLevelTitle)) == 0)
		{
			bFoundIt = true;
			break;
		}
	}

	// For some bad reason, we couldn't find the level.
	if (! bFoundIt)
	{
		return (false);
	}


	// Clear the board.
	pWorld -> DeleteAllObjects ();

	// Found it, read the next six lines for the data.
	// Save the title.  Don't save the "Level n -" part.
	p = strstr (szOneLine, " - ");
	if (p)
		strcpy (szLevelTitle, p + 3);
	else
		strcpy (szLevelTitle, szOneLine);


	// Parse the data.
	while (1)
	{
		// Get the next line.
		if ((szOneLine = LevelData [nLevelDataIndex]) == NULL)
			break;

		nLevelDataIndex ++;

		if (strncmp (szOneLine, "END", 3) == 0)
		{
			break;
		}

		switch (szOneLine [0])
		{
			// Hero location
			case 'H':
				if (sscanf (szOneLine, "H=(%d,%d)", &x, &y) == 2)
				{
					BibPoint bpLoc (x, y);
					pWorld -> SetHeroLocation (bpLoc);
				}
			break;

			// Viewport location
			case 'V':
				if (sscanf (szOneLine, "V=(%d,%d)", &x, &y) == 2)
				{
					BibPoint bpVC (x, y);
					pWorld -> SetViewCoords (bpVC);
				}
			break;

			// Randomly placed items.
			case 'R':
				if (sscanf (szOneLine, "R=%s (%d)", szItemName, &nNumItems) == 2)
				{
					PlaceRanomly (pWorld, szItemName, nNumItems);
				}
			break;


			// Enemy
			case 'E':
				switch (szOneLine [1])
				{
					// Devil enemy.
					case 'D':
						if (sscanf (szOneLine, "ED=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateDevilEnemy (bpCreate);
						}
					break;

					// Poke enemy.
					case 'P':
						if (sscanf (szOneLine, "EP=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreatePokeEnemy (bpCreate);
						}
					break;

					// Seekerenemy.
					case 'S':
						if (sscanf (szOneLine, "ES=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateSeekerEnemy (bpCreate);
						}
					break;

					// Turret.
					case 'T':
						if (sscanf (szOneLine, "ET=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateTurretEnemy (bpCreate);
						}
					break;
				}
			break;

			// Inanimate Object
			case 'I':
				switch (szOneLine [1])
				{
					// Moon
					case 'M':
						if (sscanf (szOneLine, "IM=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::MOON);
						}
					break;

					// Rock
					case 'R':
						if (sscanf (szOneLine, "IR=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::ROCK);
						}
					break;

					// Black Hole
					case 'B':
						if (sscanf (szOneLine, "IB=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::BLACK_HOLE);
						}
					break;

					// Star
					case 'S':
						if (sscanf (szOneLine, "IS=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::STAR);
						}
					break;

					// Point Star
					case 'P':
						if (sscanf (szOneLine, "IPS=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::POINT_STAR);
						}
					break;

					// Red Galaxy
					case 'G':
						if (sscanf (szOneLine, "IGR=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::RED_GALAXY);
						}
					break;

					// Earth
					case 'E':
						if (sscanf (szOneLine, "IE=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::EARTH);
						}
					break;
				}
			break;
		}
	}


	return (true);
}



void ShooterLevelLoader::PlaceRanomly (class ShooterWorld * pWorld, char * szItemName, int nNumItems)
{
int x, y, i;

	if (strcmp (szItemName, "IPS") == 0)
	{
		for (i = 0; i < nNumItems; i ++)
		{
			x = rand () % MAP_SIZE_X;
			y = rand () % MAP_SIZE_Y;
			BibPoint bpCreate (x, y);
			pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::POINT_STAR);
		}
	}
}












#if 0
// Original level loader, which loads levels from disk.

bool ShooterLevelLoader::LoadLevel (int nLevel, char * szLevelTitle, class ShooterWorld * pWorld)
{
int x, y, nNumItems;
char cDummy;
char szOneLine [256];
char szSubLevelTitle [256];
char szItemName [256];
std::ifstream ifsLevelsFile;
char * p;


	ifsLevelsFile.open (LEVELS_FILE_NAME);
	if (!ifsLevelsFile)
	{
		// Error, couldn't open.
		return (false);
	}


	// First find the correct level
	sprintf (szSubLevelTitle, "Level %d", nLevel);
	bool bFoundIt = false;
	while (ifsLevelsFile.get (szOneLine, 256, '\n'))
	{
		// Read the '\n'
		ifsLevelsFile.get (cDummy);

		// Ignore comments.
		if (szOneLine [0] == '#')
			continue;

		// Look for the correct start of the title.
		if (strncmp (szOneLine, szSubLevelTitle, strlen (szSubLevelTitle)) == 0)
		{
			bFoundIt = true;
			break;
		}
	}

	// For some bad reason, we couldn't find the level.
	if (! bFoundIt)
	{
		ifsLevelsFile.close();
		return (false);
	}


	// Clear the board.
	pWorld -> DeleteAllObjects ();

	// Found it, read the next six lines for the data.
	// Save the title.  Don't save the "Level n -" part.
	p = strstr (szOneLine, " - ");
	if (p)
		strcpy (szLevelTitle, p + 3);
	else
		strcpy (szLevelTitle, szOneLine);


	// Parse the data.
	while (1)
	{
		// Get the next line.
		if (! ifsLevelsFile.get (szOneLine, 256, '\n'))
			break;

//		TRACE (szOneLine);
//		TRACE ("\n");

		// Read the '\n'
		ifsLevelsFile.get (cDummy);


		if (strncmp (szOneLine, "END", 3) == 0)
		{
			break;
		}

		switch (szOneLine [0])
		{
			// Hero location
			case 'H':
				if (sscanf (szOneLine, "H=(%d,%d)", &x, &y) == 2)
				{
					BibPoint bpLoc (x, y);
					pWorld -> SetHeroLocation (bpLoc);
				}
			break;

			// Viewport location
			case 'V':
				if (sscanf (szOneLine, "V=(%d,%d)", &x, &y) == 2)
				{
					BibPoint bpVC (x, y);
					pWorld -> SetViewCoords (bpVC);
				}
			break;

			// Randomly placed items.
			case 'R':
				if (sscanf (szOneLine, "R=%s (%d)", & szItemName, &nNumItems) == 2)
				{
					PlaceRanomly (pWorld, szItemName, nNumItems);
				}
			break;


			// Enemy
			case 'E':
				switch (szOneLine [1])
				{
					// Devil enemy.
					case 'D':
						if (sscanf (szOneLine, "ED=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateDevilEnemy (bpCreate);
						}
					break;

					// Poke enemy.
					case 'P':
						if (sscanf (szOneLine, "EP=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreatePokeEnemy (bpCreate);
						}
					break;

					// Seekerenemy.
					case 'S':
						if (sscanf (szOneLine, "ES=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateSeekerEnemy (bpCreate);
						}
					break;

					// Turret.
					case 'T':
						if (sscanf (szOneLine, "ET=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateTurretEnemy (bpCreate);
						}
					break;
				}
			break;

			// Inanimate Object
			case 'I':
				switch (szOneLine [1])
				{
					// Moon
					case 'M':
						if (sscanf (szOneLine, "IM=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::MOON);
						}
					break;

					// Rock
					case 'R':
						if (sscanf (szOneLine, "IR=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::ROCK);
						}
					break;

					// Black Hole
					case 'B':
						if (sscanf (szOneLine, "IB=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::BLACK_HOLE);
						}
					break;

					// Star
					case 'S':
						if (sscanf (szOneLine, "IS=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::STAR);
						}
					break;

					// Point Star
					case 'P':
						if (sscanf (szOneLine, "IPS=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::POINT_STAR);
						}
					break;

					// Red Galaxy
					case 'G':
						if (sscanf (szOneLine, "IGR=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::RED_GALAXY);
						}
					break;

					// Earth
					case 'E':
						if (sscanf (szOneLine, "IE=(%d,%d)", &x, &y) == 2)
						{
							BibPoint bpCreate (x, y);
							pWorld -> CreateInanimateObject (bpCreate, InAnimateObjectCtrl::EARTH);
						}
					break;
				}
			break;
		}
	}


	ifsLevelsFile.close();


	return (true);
}
#endif
