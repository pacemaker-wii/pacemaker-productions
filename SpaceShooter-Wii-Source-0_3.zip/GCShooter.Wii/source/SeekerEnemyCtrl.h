/*

	SeekerEnemyControl Class

*/

#include "BibLib/BibCtrl.h"
#include "BibLib/BibPointFP.h"


class SeekerEnemyCtrl : public BibControl
{
private:
	BibPointFP bpVel;
	BibPointFP bpInternalLoc;

	class ShooterWorld * pWorld;

	bool bNewLock;
	float fSeekSoundTimer;
public:
	void Initialize (class BibWorld * pWorld);
	void UnInitialize ();

	// This is called very often to have the object move, etc.
	bool UpdateMovement (float fSpeedFactor);

	void SetLocation (BibPoint & inbpLoc);

	bool Shot (int nHits) { return (true); }

};
