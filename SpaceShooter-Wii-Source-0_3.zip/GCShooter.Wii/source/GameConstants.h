// GameConstants.h

/*
	Version Number to display
*/
//#define SHOOTER_VERSION "Alpha: " __DATE__
#define SHOOTER_VERSION "Version: 0.3, " __DATE__

/*
	PRODUCTION switch (i.e. no debugging stuff)
*/
#define PRODUCTION
//#undef PRODUCTION	// Not in production mode...in debug/development mode.



// These are constants/ranges for the time-independent movement
// stuff.
#define EXPECT_FRAMES_PER_SECOND		60		// Keep at 60 for sprite animation


/*
	Screen, Viewport, and Radar sizes.
*/

#define SCREEN_WIDTH	640
#define SCREEN_HEIGHT	480

#define MAP_SIZE_X		3000
#define MAP_SIZE_Y		3000

#define RADAR_SIZE_X	100
#define RADAR_SIZE_Y	100

#define	RADAR_OFFSET_X	508
#define	RADAR_OFFSET_Y	24

#define VIEWPORT_WIDTH	640
#define VIEWPORT_HEIGHT	480

#define VIEWPORT_SCROLL_BUFFER_X	375
#define VIEWPORT_SCROLL_BUFFER_Y	275


// This is due to the fact that we check vs. upper left
//  coords, but the bottom of the graphic may still show,
//  even though the upper left coord isn't in the viewport.
// This number should be the size of the largest bitmap.
#define	VIEW_GRAPHICS_FUDGE		101


// This should be slightly faster than the hero velocity so it can't fall behind.
#define SCROLL_INCREMENT (7.0f)

/*
	Fixed Graphic Locations.
*/

#define LEVEL_TITLE_X	96
#define LEVEL_TITLE_Y	24

#define LEVEL_NUMBER_X	32
#define LEVEL_NUMBER_Y	395

#define SCORE_NUMBER_X	32
#define SCORE_NUMBER_Y	420

//#define SCORE_PLUS_NUMBER_X	410
//#define SCORE_PLUS_NUMBER_Y	440

#define LIVES_NUMBER_X	250
#define LIVES_NUMBER_Y	420

#define TIME_LEFT_NUMBER_X	430
#define TIME_LEFT_NUMBER_Y	395

#define SHIELDS_LEFT_NUMBER_X	430
#define SHIELDS_LEFT_NUMBER_Y	420


#define GAME_OVER_X		(SCREEN_WIDTH/2-100)
#define GAME_OVER_Y		(SCREEN_HEIGHT/2-100)

#define NEXT_LEVEL_X	(SCREEN_WIDTH/2-200)
#define NEXT_LEVEL_Y	(SCREEN_HEIGHT/2)

/*
	Velocities.

	These are in pixels per frame.
*/

#define HERO_VELOCITY	(6.2f)
#define SEEKER_VELOCITY (5.2f)
#define TURRET_BULLET_VELOCITY (4.2f)
#define POKE_VELOCITY	(10.5f)

// Time between bullet shots from the hero.
#define MIN_BULLET_SHOOT_TIME	6

#undef LEVELS_FILE_NAME
#define LEVELS_FILE_NAME	"ShooterLevels.txt"

#define	SEEKER_SOUND_TIME	60
#define TURRET_SHOT_TIME	20


// Time in seconds
#define STD_LEVEL_TIME_LEFT	(60*15)	// 15 minutes

// Units are in frames.
#define GAME_OVER_WAIT_TIME  (10*60)

#define NEXT_LEVEL_DELAY	120
/* Debug settings
#define NEXT_LEVEL_DELAY	2
//  #define SHOW_OVERSCAN_BOX
*/
#define SHOW_FPS
