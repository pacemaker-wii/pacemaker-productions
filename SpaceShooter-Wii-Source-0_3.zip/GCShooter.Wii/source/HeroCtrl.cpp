/*

	Hero Control Class

*/

#include "GameConstants.h"
#include "HeroCtrl.h"
#include "ShooterWorld.h"

#include "Sprites/Hero.sprite.h"
#include "Sprites/HeroDownTurn.sprite.h"
#include "Sprites/HeroLeftTurn.sprite.h"
#include "Sprites/HeroRightTurn.sprite.h"


#define FRAMES_TO_BUZZ	12
#define IBOUNDS(var,min,max) ((var >= min) && (var <= max))


static BibWiiInputDevice::SingleAction saFire [MAX_ACTION_SETS] = {
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2},
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2},
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
																	{BibWiiInputDevice::CTRL_GAMECUBE, PAD_BUTTON_A}
																};
static BibWiiInputDevice::SingleAction saTurn [MAX_ACTION_SETS] = {
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_1},
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_1},
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_B},
																	{BibWiiInputDevice::CTRL_GAMECUBE, PAD_BUTTON_B}
																};
static BibWiiInputDevice::SingleAction saMoveUp [MAX_ACTION_SETS] = {
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_RIGHT},
																	{BibWiiInputDevice::CTRL_NONE, 0},
																	{BibWiiInputDevice::CTRL_NONE, 0},
																	{BibWiiInputDevice::CTRL_NONE, 0}
																};
static BibWiiInputDevice::SingleAction saMoveDown [MAX_ACTION_SETS] = {
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_LEFT},
																	{BibWiiInputDevice::CTRL_NONE, 0},
																	{BibWiiInputDevice::CTRL_NONE, 0},
																	{BibWiiInputDevice::CTRL_NONE, 0}
																};
static BibWiiInputDevice::SingleAction saMoveLeft [MAX_ACTION_SETS] = {
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_UP},
																	{BibWiiInputDevice::CTRL_NONE, 0},
																	{BibWiiInputDevice::CTRL_NONE, 0},
																	{BibWiiInputDevice::CTRL_NONE, 0}
																};
static BibWiiInputDevice::SingleAction saMoveRight [MAX_ACTION_SETS] = {
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_DOWN},
																	{BibWiiInputDevice::CTRL_NONE, 0},
																	{BibWiiInputDevice::CTRL_NONE, 0},
																	{BibWiiInputDevice::CTRL_NONE, 0}
																};

HeroCtrl::HeroCtrl ()
{
}

HeroCtrl::~HeroCtrl ()
{
}

void HeroCtrl::Initialize (class BibWorld * inpWorld)
{
	// Call the base class initialize.
	BibControl::Initialize (inpWorld);

	pWorld = (ShooterWorld *) inpWorld;

	// Add the sprites.
	basSpriteData . AddFrame (0, 900000, 0, Hero_Bitmap, HERO_WIDTH, HERO_HEIGHT);
	basSpriteData . AddSequence ();
	basSpriteData . AddFrame (1, 900000, 0, HeroRightTurn_Bitmap, HERORIGHTTURN_WIDTH, HERORIGHTTURN_HEIGHT);
	basSpriteData . AddSequence ();
	basSpriteData . AddFrame (2, 900000, 0, HeroDownTurn_Bitmap, HERODOWNTURN_WIDTH, HERODOWNTURN_HEIGHT);
	basSpriteData . AddSequence ();
	basSpriteData . AddFrame (3, 900000, 0, HeroLeftTurn_Bitmap, HEROLEFTTURN_WIDTH, HEROLEFTTURN_HEIGHT);

	// Save graphic sizes based on current sprite.
	bpSize.x = basSpriteData.GetCurSprite () . GetWidth ();
	bpSize.y = basSpriteData.GetCurSprite () . GetHeight ();

	// This is a hero!
	nFlags = IS_HERO;

	// Controller Input Actions.
	WiiFireAction = pWorld->WiiInputDevice.DefineAction (saFire);
	WiiTurnAction = pWorld->WiiInputDevice.DefineAction (saTurn);

	WiiMoveUpAction = pWorld->WiiInputDevice.DefineAction (saMoveUp);
	WiiMoveDownAction = pWorld->WiiInputDevice.DefineAction (saMoveDown);
	WiiMoveLeftAction = pWorld->WiiInputDevice.DefineAction (saMoveLeft);
	WiiMoveRightAction = pWorld->WiiInputDevice.DefineAction (saMoveRight);
	
	nHitCounter = 0;

	Reset ();

}

void HeroCtrl::UnInitialize ()
{

}


void HeroCtrl::Reset (void)
{
	// Set starting velocity.
	bpVel.x = 0;
	bpVel.y = 0;

	// Hero direction.
	eFacing = DIR_UP;

	// Time till next bullet.
	fBulletTime = MIN_BULLET_SHOOT_TIME + 1;	// Ready to fire immediately
	fMinBulletTime = MIN_BULLET_SHOOT_TIME;

	// Weapon System to use first.
	WeaponsSystems = NORMAL;
#ifndef PRODUCTION
	WeaponsSystems |= SEEKER;
#endif
	

	// Hits/Shield level.
	nHitPoints = 5;

	// Set starting sprite sequence.
	basSpriteData.SetCurSequence (0);
	basSpriteData.SetCurFrame (0);
}

bool HeroCtrl::UpdateMovement (float fSpeedFactor)
{
BibPoint bpSaveMyLocation;
BibPointFP bpTestLoc;
bool bCanMove;

	// Call the base class to update sprite data, etc.
	if (BibControl::UpdateMovement (fSpeedFactor))
	{
		return (true);
	}


	//!!! This assumes that UpdateMovement is called once per frame, 
	//!!!      which is almost always true so far.
	if (nHitCounter != 0)
	{
		nHitCounter --;
		if (nHitCounter == 0)
		{
			//!!!! This should rumble the GC controller if the action set == 3.
			pWorld->WiiInputDevice.ControlMotor (BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_CHAN_0, FALSE);
		}
	}

	// If the Turn key is pressed turn the ship.
	if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiTurnAction))
	{
		Turn ();
	}

	if (pWorld->WiiInputDevice.GetCurActionSet () == 0)
	{
		// Check X Velocity.
		if (pWorld->WiiInputDevice.ActionHeld (WPAD_CHAN_0, WiiMoveLeftAction))
		{
			bpVel.x = -1 * HERO_VELOCITY;
		}
		else if (pWorld->WiiInputDevice.ActionHeld (WPAD_CHAN_0, WiiMoveRightAction))
		{
			bpVel.x = HERO_VELOCITY;
		}
		else
		{
			bpVel.x = 0;
		}
		
		// Check Y Velocity.
		if (pWorld->WiiInputDevice.ActionHeld (WPAD_CHAN_0, WiiMoveUpAction))
		{
			bpVel.y = -1 * HERO_VELOCITY;
		}
		else if (pWorld->WiiInputDevice.ActionHeld (WPAD_CHAN_0, WiiMoveDownAction))
		{
			bpVel.y = HERO_VELOCITY;
		}
		else
		{
			bpVel.y = 0;
		}
	}
	else if (pWorld->WiiInputDevice.GetCurActionSet () == 1)
	{
		//	WiiRemote Sideways, tilt to move
		bool bStatus;
		int pitch, yaw, roll;
		bStatus = pWorld->WiiInputDevice.Wii_Orientation (WPAD_CHAN_0, pitch, yaw, roll);
		if (bStatus)
		{
			if (pitch < -50)
				bpVel.x = HERO_VELOCITY;
			else if (pitch > 50)
				bpVel.x = -1 * HERO_VELOCITY;
			else
				bpVel.x = 0;
				
			if (roll < -50)
				bpVel.y = HERO_VELOCITY;
			else if (roll > 50)
				bpVel.y = -1 * HERO_VELOCITY;
			else
				bpVel.y = 0;
		}
	}
	else if (pWorld->WiiInputDevice.GetCurActionSet () == 2)
	{
		// WiiRemote Nunchuk to move
		bool bStatus;
		int nAngle, nMagnitude;
		bStatus = pWorld->WiiInputDevice.Nunchuk_Stick (WPAD_CHAN_0, nAngle, nMagnitude);

		if (bStatus && (nMagnitude > 40))
		{
			bpVel.y = 0;
			if (IBOUNDS (nAngle, 0, 45) || IBOUNDS (nAngle, 315, 360))
			{
				bpVel.y = -1 * HERO_VELOCITY * nMagnitude / 100;
			}
			if (IBOUNDS (nAngle, 45, 90) || IBOUNDS (nAngle, 270, 315))
			{
				bpVel.y = -1 * HERO_VELOCITY * nMagnitude / 100 / 2;
			}

			if (IBOUNDS (nAngle, 135, 180) || IBOUNDS (nAngle, 180, 225))
			{
				bpVel.y = HERO_VELOCITY * nMagnitude / 100;
			}
			if (IBOUNDS (nAngle, 90, 135) || IBOUNDS (nAngle, 225, 270))
			{
				bpVel.y = HERO_VELOCITY * nMagnitude / 100 / 2;
			}
			
			bpVel.x = 0;
			if (IBOUNDS (nAngle, 225, 270) || IBOUNDS (nAngle, 270, 315))
			{
				bpVel.x = -1 * HERO_VELOCITY * nMagnitude / 100;
			}
			if (IBOUNDS (nAngle, 180, 225) || IBOUNDS (nAngle, 315, 360))
			{
				bpVel.x = -1 * HERO_VELOCITY * nMagnitude / 100 / 2;
			}

			if (IBOUNDS (nAngle, 45, 90) || IBOUNDS (nAngle, 90, 135))
			{
				bpVel.x = HERO_VELOCITY * nMagnitude / 100;
			}
			if (IBOUNDS (nAngle, 0, 45) || IBOUNDS (nAngle, 135, 180))
			{
				bpVel.x = HERO_VELOCITY * nMagnitude / 100 / 2;
			}
		}
		else
		{
			bpVel.x = 0;
			bpVel.y = 0;
		}
	}
	else if (pWorld->WiiInputDevice.GetCurActionSet () == 3)
	{
		// Game Cube Stick.
		
		// Check X Velocity.
		if (pWorld->WiiInputDevice.GC_StickX(PAD_CHAN0) < -18)
		{
			bpVel.x = -1 * HERO_VELOCITY;
		}
		else if (pWorld->WiiInputDevice.GC_StickX(PAD_CHAN0) > 18)
		{
			bpVel.x = HERO_VELOCITY;
		}
		else
		{
			bpVel.x = 0;
		}

		// Check Y Velocity.
		if (pWorld->WiiInputDevice.GC_StickY(PAD_CHAN0) > 18)
		{
			bpVel.y = -1 * HERO_VELOCITY;
		}
		else if (pWorld->WiiInputDevice.GC_StickY(PAD_CHAN0) < -18)
		{
			bpVel.y = HERO_VELOCITY;
		}
		else
		{
			bpVel.y = 0;
		}
	}


	// Find future position.
	bpTestLoc = bpInternalLoc + bpVel * fSpeedFactor;

	// Is this position valid?
	if ((bpTestLoc.x < 0) || (bpTestLoc.x > MAP_SIZE_X - bpSize.x))
	{
		bpTestLoc.x = bpInternalLoc.x;
	}
	if ((bpTestLoc.y < 0) || (bpTestLoc.y > MAP_SIZE_Y - bpSize.y))
	{
		bpTestLoc.y = bpInternalLoc.y;
	}

	// Save this, since EnvironmentCollision will use it later.
	bpSaveMyLocation = bpMyLocation;

	// Check for collisions with the environment
	bCanMove = true;
	bpMyLocation.x = (int) bpTestLoc.x;
	bpMyLocation.y = (int) bpTestLoc.y;
	
	if (pWorld -> EnvironmentCollision (*this))
	{
		// There is a collision, try other possible moves.
		bpMyLocation.x = (int) bpInternalLoc.x;
		bpMyLocation.y = (int) bpTestLoc.y;
		if (pWorld -> EnvironmentCollision (*this))
		{
			// There is a collision, try other possible moves.
			bpMyLocation.x = (int) bpTestLoc.x;
			bpMyLocation.y = (int) bpInternalLoc.y;
			if (pWorld -> EnvironmentCollision (*this))
			{
				bCanMove = false;
			}
			else
			{
				bpTestLoc.y = bpInternalLoc.y;
			}
		}
		else
		{
			bpTestLoc.x = bpInternalLoc.x;
		}
	}

	// Resetore this, in case it changed.
	bpMyLocation = bpSaveMyLocation;


	if (bCanMove)
	{
		// Commit the new position.
		bpInternalLoc = bpTestLoc;

		// Set location for external access.
		bpMyLocation.x = (int) bpInternalLoc.x;
		bpMyLocation.y = (int) bpInternalLoc.y;
	}

	CheckForFiring (fSpeedFactor);

	return (false);
}


void HeroCtrl::SetLocation (BibPoint & inbpLoc)
{
	BibControl::SetLocation (inbpLoc);
	bpInternalLoc.x = inbpLoc.x;
	bpInternalLoc.y = inbpLoc.y;
}


void HeroCtrl::Turn (void)
{
int nCurSeq;

	// Increment the sprite sequence.
	nCurSeq = basSpriteData . GetCurSequence ();
	nCurSeq ++;

	if (nCurSeq >= 4)
		nCurSeq = 0;

	eFacing = (eFacingDirection) nCurSeq;

	basSpriteData . SetCurSequence (nCurSeq);

	// Save graphic sizes based on current sprite.
	bpSize.x = basSpriteData.GetCurSprite () . GetWidth ();
	bpSize.y = basSpriteData.GetCurSprite () . GetHeight ();
}


BibPoint HeroCtrl::GetBulletStart (eFacingDirection ineFacing)
{
	switch (ineFacing)
	{
		default:
		case DIR_UP:
			return (bpMyLocation + BibPoint (22, -17));
		break;

		case DIR_RIGHT:
			return (bpMyLocation + BibPoint (45, 25));
		break;

		case DIR_DOWN:
			return (bpMyLocation + BibPoint (22, 45));
		break;

		case DIR_LEFT:
			return (bpMyLocation + BibPoint (0, 25));
		break;
	}

}



BibPoint HeroCtrl::GetBigBombBulletStart (eFacingDirection ineFacing)
{
	switch (ineFacing)
	{
		default:
		case DIR_DOWN:
			return (bpMyLocation + BibPoint (-25, -100));
		break;

		case DIR_LEFT:
			return (bpMyLocation + BibPoint (35, 0));
		break;

		case DIR_UP:
			return (bpMyLocation + BibPoint (-25, 35));
		break;

		case DIR_RIGHT:
			return (bpMyLocation + BibPoint (-100, -25));
		break;
	}

}



BibPointFP HeroCtrl::GetBulletVelocity (eFacingDirection ineFacing)
{
	switch (ineFacing)
	{
		default:
		case DIR_UP:
			return (BibPointFP (0.0f, -10.0f));
		break;

		case DIR_RIGHT:
			return (BibPointFP (10.0f, 0.0f));
		break;

		case DIR_DOWN:
			return (BibPointFP (0.0f, 10.0f));
		break;

		case DIR_LEFT:
			return (BibPointFP (-10.0f, 0.0f));
		break;
	}

}


void HeroCtrl::SetWeaponsSystem (eWeaponsSystemType ineWeaponsSystem)
{
	WeaponsSystems = ineWeaponsSystem; 
	if (WeaponsSystems == BIG_BOMB)
	{
		fMinBulletTime = MIN_BULLET_SHOOT_TIME * 8;
	}
	else if (WeaponsSystems == SEEKER)
	{
		fMinBulletTime = MIN_BULLET_SHOOT_TIME * 8;
	}
	else if (WeaponsSystems == SLOW_MULTI)
	{
		fMinBulletTime = MIN_BULLET_SHOOT_TIME * 2;
	}
	else
	{
		fMinBulletTime = MIN_BULLET_SHOOT_TIME;
	}
}

void HeroCtrl::AddWeaponsSystem (eWeaponsSystemType ineWeaponsSystem)
{
	WeaponsSystems |= ineWeaponsSystem; 
	if (WeaponsSystems & BIG_BOMB)
	{
		fMinBulletTime = MIN_BULLET_SHOOT_TIME * 8;
	}
	else if (WeaponsSystems & SEEKER)
	{
		fMinBulletTime = MIN_BULLET_SHOOT_TIME * 8;
	}
	else if (WeaponsSystems & SLOW_MULTI)
	{
		fMinBulletTime = MIN_BULLET_SHOOT_TIME * 2;
	}
	else
	{
		fMinBulletTime = MIN_BULLET_SHOOT_TIME;
	}
}


void HeroCtrl::CheckForFiring (float fSpeedFactor)
{
	fBulletTime += fSpeedFactor;

	// If the fire button is pressed and it's time for another bullet...
	if (
		(fBulletTime > fMinBulletTime) && 
		(pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiFireAction))
	   )
	{
		// Reset bullet counter.
		fBulletTime = 0;

		if (WeaponsSystems & NORMAL)
		{
			CreateNormalBullet ();
		}
		if (WeaponsSystems & SLOW_MULTI)
		{
			CreateSlowMultiBullet ();
		}
		if (WeaponsSystems & BIG_BOMB)
		{
			CreateBigBombBullet ();
		}
		if (WeaponsSystems & SEEKER)
		{
			CreateSeekerBullet ();
		}
	}
}


void HeroCtrl::CreateNormalBullet (void)
{
BibPoint bpLoc;
BibPointFP bpVel;

	// Get the bullet's location.
	bpLoc = GetBulletStart (eFacing);

	// Get the velocity of the bullet.
	bpVel = GetBulletVelocity (eFacing);

	// Ask the world to create the proper object.
	pWorld -> CreateHeroBullet (bpLoc, bpVel, (int)eFacing, 0);
}

void HeroCtrl::CreateSlowMultiBullet (void)
{
BibPoint bpLoc;
BibPointFP bpVel;

	// Get the bullet's location.
	bpLoc = GetBulletStart (eFacing);

	// Get the velocity of the bullet.
	bpVel = GetBulletVelocity (eFacing);

	bpVel = bpVel / 3;
	pWorld -> CreateHeroBullet (bpLoc, bpVel, eFacing, 2);

	bpVel = bpVel / 3;
	pWorld -> CreateHeroBullet (bpLoc, bpVel, eFacing, 2);

}

void HeroCtrl::CreateSeekerBullet (void)
{
BibPoint bpLoc;
BibPointFP bpVel;

	// Get the bullet's location.
	bpLoc = GetBulletStart (eFacing);

	// Get the velocity of the bullet.
	bpVel = GetBulletVelocity (eFacing);

	// Create one special seeker bullet.
	pWorld -> CreateHeroBullet (bpLoc, bpVel, eFacing, 4);
}


// Big Bombs shoot backwards.
void HeroCtrl::CreateBigBombBullet (void)
{
BibPoint bpLoc;
BibPointFP bpVel;

	// Get the bullet's location.
	bpLoc = GetBigBombBulletStart (eFacing);
	
	// Get the velocity of the bullet.
	bpVel = GetBulletVelocity (eFacing);
	bpVel = bpVel * -1;

	bpVel.x += (rand () % 3) - 1;
	bpVel.y += (rand () % 3) - 1;
	bpVel = bpVel / 3;
	pWorld -> CreateHeroBullet (bpLoc, bpVel, eFacing, 3);
}


bool HeroCtrl::Shot (int nHits)
{
	// We are shot.
	nHitPoints -= nHits;

	if (nHitPoints <= 0)
	{
		// We are dead.
		return (true);
	}
	else
	{
		// We are not dead yet.
		nHitCounter = FRAMES_TO_BUZZ;
		pWorld->WiiInputDevice.ControlMotor (BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_CHAN_0, TRUE);
		return (false);
	}
}


