/*

	PokeEnemy Control Class

*/

#include <math.h>

#include "GameConstants.h"
#include "PokeEnemyCtrl.h"
#include "ShooterWorld.h"

#include "Sprites/Explosion.sprite.h"
#include "Sprites/PokeEnemy.sprite.h"


void PokeEnemyCtrl::Initialize (class BibWorld * inpWorld)
{
	// Call the base class initialize.
	BibControl::Initialize (inpWorld);

	// Add the sprites.
	basSpriteData . AddFrame (0, 100000, 0, PokeEnemy_Bitmap, POKEENEMY_WIDTH, POKEENEMY_HEIGHT);
	basSpriteData . AddSequence ();
	basSpriteData . AddFrame (1, 30, 1, Explosion_Bitmap, EXPLOSION_WIDTH, EXPLOSION_HEIGHT);
	basSpriteData . AddFrame (1, 100000, 1, NULL, 0, 0);

	basSpriteData.SetCurSequence (0);
	basSpriteData.SetCurFrame (0);

	bpSize.x = basSpriteData.GetCurSprite () . GetWidth ();
	bpSize.y = basSpriteData.GetCurSprite () . GetHeight ();

	// This is a PokeEnemy!
	nFlags = IS_ENEMY;
}

void PokeEnemyCtrl::UnInitialize ()
{

}



bool PokeEnemyCtrl::UpdateMovement (float fSpeedFactor)
{
BibPointFP bpNextLoc;

	// If this was set outside of this function,
	//	then something (e.g. a bullet) wants us dead.
	if (SelfDestruct ())
	{
		ClearSelfDestruct ();
		basSpriteData.SetCurSequence (1);
	}

	// Call the base class to update sprite data, etc.
	if (BibControl::UpdateMovement (fSpeedFactor))
	{
		return (true);
	}

	// If we are in the exploding state, don't move.
	if (basSpriteData.GetCurSequence () == 1)
	{
		if (basSpriteData.GetCurFrame () == 1)
		{
			// We are done exploding, self destruct object.
			SetSelfDestruct ();
		}
		return (false);
	}


	/*
		Calculate the next position.
	*/

	fMoveTimer += fSpeedFactor;

	// This guy circles at fRadius around bpCenter point;

	// Find next circle point to move to.
	if (bDirection)
	{
		bpNextLoc.x = bpCenter.x + sin (fMoveTimer / 10) * fRadius;
		bpNextLoc.y = bpCenter.y + cos (fMoveTimer / 10) * fRadius;
	}
	else
	{
		bpNextLoc.x = bpCenter.x + cos (fMoveTimer / 10) * fRadius;
		bpNextLoc.y = bpCenter.y + sin (fMoveTimer / 10) * fRadius;
	}

	// Add some randomness.
//	bpNextLoc.x += rand () % 150;
//	bpNextLoc.x += rand () % 150;

	// Calculate vector
	bpNextLoc = (bpNextLoc - bpInternalLoc);


	// Normalize and set to the correct velocity.
	bpNextLoc.Normalize ();
	bpNextLoc = bpNextLoc * POKE_VELOCITY;


	// Apply vector to calculate next location.
	bpInternalLoc = bpInternalLoc + (bpNextLoc * fSpeedFactor);





	// Are we inside the map.
	if (bpInternalLoc.x < 0)
	{
		bpInternalLoc.x = 0;
	}
	else if (bpInternalLoc.x > MAP_SIZE_X - bpSize.x)
	{
		bpInternalLoc.x = MAP_SIZE_X - bpSize.x;
	}
	if (bpInternalLoc.y < 0)
	{
		bpInternalLoc.y = 0;
	}
	else if (bpInternalLoc.y > MAP_SIZE_Y - bpSize.y)
	{
		bpInternalLoc.y = MAP_SIZE_Y - bpSize.y;
	}

	// Set location for external access.
	bpMyLocation.x = (int) bpInternalLoc.x;
	bpMyLocation.y = (int) bpInternalLoc.y;


	return (false);
}



void PokeEnemyCtrl::SetLocation (BibPoint & inbpLoc)
{
	BibControl::SetLocation (inbpLoc);
	bpInternalLoc.x = inbpLoc.x;
	bpInternalLoc.y = inbpLoc.y;

	bpCenter = bpInternalLoc;
	fRadius = (rand () % 175) + 25.0f;
	fMoveTimer = (rand () % 100) / 10.0f;
	bDirection = (rand () % 2) ? true : false;
}
