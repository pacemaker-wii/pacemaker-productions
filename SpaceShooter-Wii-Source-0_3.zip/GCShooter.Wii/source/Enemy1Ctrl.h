/*

	Enemy1Control Class

*/

#include "BibLib/BibCtrl.h"
#include "BibLib/BibPointFP.h"


class Enemy1Ctrl : public BibControl
{
private:
	BibPointFP bpVel;
	BibPointFP bpInternalLoc;
public:
	void Initialize (class BibWorld * pWorld);
	void UnInitialize ();

	// This is called very often to have the object move, etc.
	bool UpdateMovement (float fSpeedFactor);

	void SetLocation (BibPoint & inbpLoc);

	bool Shot (int nHits) { return (true); }

};
