/*

	Bullet Control Class

*/

#include "GameConstants.h"
#include "BulletCtrl.h"
#include "ShooterWorld.h"

#include "Sprites/Bullet.sprite.h"
#include "Sprites/BulletRight.sprite.h"
#include "Sprites/EnemyBullet.sprite.h"
#include "Sprites/SlowMultiBulletUp.sprite.h"
#include "Sprites/SlowMultiBulletRight.sprite.h"
#include "Sprites/SlowMultiBulletDown.sprite.h"
#include "Sprites/SlowMultiBulletLeft.sprite.h"
#include "Sprites/BigBomb.sprite.h"
#include "Sprites/SeekerHero.sprite.h"



void BulletCtrl::Initialize (class BibWorld * inpWorld)
{
	// Call the base class initialize.
	BibControl::Initialize (inpWorld);

	pWorld = (ShooterWorld *) inpWorld;

	// Add the sprites.
	basSpriteData . AddFrame (0, 200000, 0, Bullet_Bitmap, BULLET_WIDTH, BULLET_HEIGHT);
	basSpriteData . AddFrame (0, 200000, 1, BulletRight_Bitmap, BULLETRIGHT_WIDTH, BULLETRIGHT_HEIGHT);
	basSpriteData . AddFrame (0, 200000, 2, Bullet_Bitmap, BULLET_WIDTH, BULLET_HEIGHT);
	basSpriteData . AddFrame (0, 200000, 3, BulletRight_Bitmap, BULLETRIGHT_WIDTH, BULLETRIGHT_HEIGHT);
	basSpriteData . AddSequence ();
	basSpriteData . AddFrame (1, 200000, 0, EnemyBullet_Bitmap, ENEMYBULLET_WIDTH, ENEMYBULLET_HEIGHT);
	basSpriteData . AddSequence ();
	basSpriteData . AddFrame (2, 200000, 0, SlowMultiBulletUp_Bitmap, SLOWMULTIBULLETUP_WIDTH, SLOWMULTIBULLETUP_HEIGHT);
	basSpriteData . AddFrame (2, 200000, 1, SlowMultiBulletRight_Bitmap, SLOWMULTIBULLETRIGHT_WIDTH, SLOWMULTIBULLETRIGHT_HEIGHT);
	basSpriteData . AddFrame (2, 200000, 2, SlowMultiBulletDown_Bitmap, SLOWMULTIBULLETDOWN_WIDTH, SLOWMULTIBULLETDOWN_HEIGHT);
	basSpriteData . AddFrame (2, 200000, 3, SlowMultiBulletLeft_Bitmap, SLOWMULTIBULLETLEFT_WIDTH, SLOWMULTIBULLETLEFT_HEIGHT);
	basSpriteData . AddSequence ();
	basSpriteData . AddFrame (3, 200000, 0, BigBomb_Bitmap, BIGBOMB_WIDTH, BIGBOMB_HEIGHT);
	basSpriteData . AddFrame (3, 200000, 1, BigBomb_Bitmap, BIGBOMB_WIDTH, BIGBOMB_HEIGHT);
	basSpriteData . AddFrame (3, 200000, 2, BigBomb_Bitmap, BIGBOMB_WIDTH, BIGBOMB_HEIGHT);
	basSpriteData . AddFrame (3, 200000, 3, BigBomb_Bitmap, BIGBOMB_WIDTH, BIGBOMB_HEIGHT);
	basSpriteData . AddSequence ();
	basSpriteData . AddFrame (4, 200000, 0, SeekerHero_Bitmap, SEEKERHERO_WIDTH, SEEKERHERO_HEIGHT);
	basSpriteData . AddFrame (4, 200000, 1, SeekerHero_Bitmap, SEEKERHERO_WIDTH, SEEKERHERO_HEIGHT);
	basSpriteData . AddFrame (4, 200000, 2, SeekerHero_Bitmap, SEEKERHERO_WIDTH, SEEKERHERO_HEIGHT);
	basSpriteData . AddFrame (4, 200000, 3, SeekerHero_Bitmap, SEEKERHERO_WIDTH, SEEKERHERO_HEIGHT);


	bpVel.x = 0;
	bpVel.y = 0;

	basSpriteData.SetCurSequence (0);
	basSpriteData.SetCurFrame (0);

	bpSize.x = basSpriteData.GetCurSprite () . GetWidth ();
	bpSize.y = basSpriteData.GetCurSprite () . GetHeight ();

	// This is a Bullet!
	nFlags = IS_BULLET;
}

void BulletCtrl::UnInitialize ()
{

}



bool BulletCtrl::UpdateMovement (float fSpeedFactor)
{
BibPoint bpEnemyLoc;
BibPointFP bpNextLoc;

	// Call the base class to update sprite data, etc.
	if (BibControl::UpdateMovement (fSpeedFactor))
	{
		return (true);
	}


	// If we are a seeker bullet...
	if (basSpriteData . GetCurSequence () == 4)
	{
		if (pWorld -> FindClosestEnemy (bpMyLocation, bpEnemyLoc))
		{
			// Found a close enemy.
			// Calculate the movement vector.
			bpNextLoc.x = bpEnemyLoc.x - bpInternalLoc.x;
			bpNextLoc.y = bpEnemyLoc.y - bpInternalLoc.y;

			// Normalize and set to the correct velocity.
			bpNextLoc.Normalize ();
			bpNextLoc = bpNextLoc * SEEKER_VELOCITY;

			// Apply vector to calculate next location.
			bpInternalLoc = bpInternalLoc + (bpNextLoc * fSpeedFactor);

			// Set location for external access.
			bpMyLocation.x = (int) bpInternalLoc.x;
			bpMyLocation.y = (int) bpInternalLoc.y;


			// Are we off the viewport?
			if (! pWorld->IsInViewPort (bpMyLocation))
			{
				bSelfDestruct = true;
				return (true);
			}

			return (false);
		}
	}


	// Calculate our next position.
	bpInternalLoc = bpInternalLoc + bpVel * fSpeedFactor;

	// Set location for external access.
	bpMyLocation.x = (int) bpInternalLoc.x;
	bpMyLocation.y = (int) bpInternalLoc.y;

	// Are we off the viewport?
	if (! pWorld->IsInViewPort (bpMyLocation))
	{
		bSelfDestruct = true;
		return (true);
	}

	return (false);
}


void BulletCtrl::SetVelocity (BibPointFP & inbpVel)
{
	bpVel = inbpVel;
}

void BulletCtrl::SetLocation (BibPoint & inbpLoc)
{
	BibControl::SetLocation (inbpLoc);
	bpInternalLoc.x = inbpLoc.x;
	bpInternalLoc.y = inbpLoc.y;
}

void BulletCtrl::SetFlags (ePieceFlags eFlags)
{
	BibControl::SetFlags (eFlags);

	if (eFlags == IS_ENEMY)
	{
		// Set the graphic to the right one.
		basSpriteData.SetCurSequence (1);
		basSpriteData.SetCurFrame (0);

		// Save the size of the graphic
		bpSize.x = basSpriteData.GetCurSprite () . GetWidth ();
		bpSize.y = basSpriteData.GetCurSprite () . GetHeight ();
	}
}

void BulletCtrl::SetDirectionAndType (int nFacing, int nType)
{
	// Set the graphic so the bullet looks right.
   	basSpriteData.SetCurSequence (nType);

	// Set the graphic so the bullet looks right.
	basSpriteData.SetCurFrame (nFacing);

	// Save the size of the graphic
	bpSize.x = basSpriteData.GetCurSprite () . GetWidth ();
	bpSize.y = basSpriteData.GetCurSprite () . GetHeight ();

	// Big Bomb
	if (nType == 3)
	{
		nHitPoints = 3;
	}

#ifndef PRODUCTION
	// Seeker
	if (nType == 4)
	{
		nHitPoints = 30;
	}
#endif
}

bool BulletCtrl::Shot (int nHits)
{
	// We are shot.
	nHitPoints -= nHits;

	if (nHitPoints <= 0)
	{
		// We are dead.
		return (true);
	}
	else
	{
		// We are not dead yet.
		return (false);
	}
}

