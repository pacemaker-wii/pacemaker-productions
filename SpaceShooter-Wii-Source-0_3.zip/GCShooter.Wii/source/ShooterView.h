// ShooterView.h: interface for the ShooterView class.
//
//////////////////////////////////////////////////////////////////////


#include "BibLib/BibView.h"


#define pTheWorld ((ShooterWorld *) pWorld)

class ShooterView : public BibView
{
private:

public:
	BibSprite SplashScreenSprite;
	BibSprite ThanksEasterEggSprite;


public:
	ShooterView();
	virtual ~ShooterView();

	virtual void Render (BibGraphicsDevice & GD);
};

