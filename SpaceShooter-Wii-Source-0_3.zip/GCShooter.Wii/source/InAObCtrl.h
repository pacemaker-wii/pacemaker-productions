/*

	InAnimateObjectControl Class

*/

#pragma once

#include "BibLib/BibCtrl.h"

class InAnimateObjectCtrl : public BibControl
{
public:
	enum eInAnimType { MOON, ROCK, BLACK_HOLE, STAR, POINT_STAR, RED_GALAXY, EARTH };
private:
	eInAnimType eObType;

public:
	void Initialize (class BibWorld * pWorld);
	void UnInitialize ();

	// This is called very often to have the object move, etc.
	bool UpdateMovement (float fSpeedFactor);
	
	void SetObType (eInAnimType ineObType) { eObType = ineObType; }

	bool Shot (int nHits) { return (false); }
	bool OnRadar (void);

};
