/*



	Level loading / setting up object



*/

#pragma once

#include "GameConstants.h"

class ShooterLevelLoader
{
private:
	void PlaceRanomly (class ShooterWorld * pWorld, char * szItemName, int nNumItems);

public:

	bool LoadLevel (int nLevel, char * szLevelTitle, class ShooterWorld * pWorld);
};

