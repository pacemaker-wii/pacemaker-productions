
// Shooter Main Menu

#include "BibLib\BibMenus.h"

class MainMenu
{
private:
	BibMenus bmMainMenu;
	ShooterWorld * pWorld;

	// From WiiInputDevice ActionMap
	//   For Menus
	int WiiMainMenuAction;
	int WiiMainMenuUpAction;
	int WiiMainMenuDownAction;
	int WiiMainMenuSelectAction;
	int WiiMainMenuBackAction;

	enum eMenuStateType { MENU_STATE_MAIN, MENU_STATE_CONTROLS };
	eMenuStateType eMenuState;

	void DoMainMenu (void);
	void DoControlMenu (void);
	void MarkActiveControlOption (void);


public:
	void Initialize (ShooterWorld * pWorld);
	// This is called every game loop.
	//  It returns true if it swallowed some user input, false if not.
	bool UpdateMovement (void);
	void DisplayListBox (BibGraphicsDevice & GD) { bmMainMenu.DisplayListBox (GD); }


};

