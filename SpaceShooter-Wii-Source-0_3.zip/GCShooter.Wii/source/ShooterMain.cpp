//
// Shooter.cpp : Defines the entry point for the application.
//

/*
	Includes
*/
#include "GameConstants.h"
#include "BibLib/BibGraphicsDevice.h"
#include "BibLib/BibBitmapServer.h"

#include "ShooterView.h"
#include "ShooterWorld.h"


/*
	Global Game Objects
	
	Here to keep them off the stack.
*/
static BibGraphicsDevice GraphicsDevice;
static ShooterView pView;
static ShooterWorld pWorld;



/*
	Main Entry Point.
*/
int main (void)
{

	/* initialize random seed: */
	srand (time(NULL));


	/*
		Initialize Global Game Objects
	*/
	GraphicsDevice . Initialize ();

	pWorld . SetView (&pView);
	pWorld . Initialize (GraphicsDevice.GetVMode ());
	pView . SetWorld (& pWorld);
	pView . fps . Init (EXPECT_FRAMES_PER_SECOND);


	// enter main event loop
    while(1)
    {
		// Update the frames-per-second data.
		pView . fps . SetSpeedFactor ();

		// Move/update all objects.
		pWorld . UpdateMovement (pView.fps.fspeedfactor);

		// Render the view into the Memory Device Context.
		pView . Render (GraphicsDevice);

		// Put the back buffer into the screen.
		GraphicsDevice . SwapMemToScreen ();

    } // end while

	return 0;
}
