/*
	Intersection
*/

#if 0
static bool CheckIntersectionSpheres (BibPoint & bpOb1Center, BibPoint & bpOb1Size,
					    BibPoint & bpOb2Center, BibPoint & bpOb2Size)
{
int nDist1, nDist2;

	nDist1 = (bpOb1Center.x - bpOb2Center.x) * (bpOb1Center.x - bpOb2Center.x) +
			 (bpOb1Center.y - bpOb2Center.y) * (bpOb1Center.y - bpOb2Center.y);

	// Size is diameter, we need radius.
	nDist2 = ((bpOb1Size.x + bpOb2Size.x) / 2) * ((bpOb1Size.x + bpOb2Size.x) / 2);

	if (nDist1 < nDist2)
		return (true);
	
	return (false);
}
#endif

// Object-to-object bounding-box collision detector:
static bool CheckIntersection (BibControl & bcOb1, BibControl & bcOb2)
{
int left1, left2;
int right1, right2;
int top1, top2;
int bottom1, bottom2;

    left1 = bcOb1.GetLocation().x;
    left2 = bcOb2.GetLocation().x;
    right1 = left1 + bcOb1.GetSize().x;
    right2 = left2 + bcOb2.GetSize().x;

    top1 = bcOb1.GetLocation().y;
    top2 = bcOb2.GetLocation().y;
    bottom1 = top1 + bcOb1.GetSize().y;
    bottom2 = top2 + bcOb2.GetSize().y;

    if (bottom1 < top2) return(false);
    if (top1 > bottom2) return(false);

    if (right1 < left2) return(false);
    if (left1 > right2) return(false);

    return(true);
}




// Distance Calculator.
static int CheckIntersection (BibPoint & bpOb1, BibPoint & bpOb2)
{
int nDist;

	nDist = (bpOb1.x - bpOb2.x) * (bpOb1.x - bpOb2.x) +
			(bpOb1.y - bpOb2.y) * (bpOb1.y - bpOb2.y);

	return (nDist);
}


