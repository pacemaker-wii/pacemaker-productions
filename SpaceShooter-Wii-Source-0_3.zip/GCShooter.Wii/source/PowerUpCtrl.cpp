/*

	PowerUps Control Class

*/

#include "GameConstants.h"
#include "PowerUpCtrl.h"
#include "ShooterWorld.h"


//     (u32 *)_Bitmap, _WIDTH, _HEIGHT
#include "Sprites/LivesPlus1.sprite.h"
#include "Sprites/PowerUp_BigBombWeaponsSystem.sprite.h"
#include "Sprites/PowerUp_MissileWeaponsSystem.sprite.h"
#include "Sprites/PowerUp_MoreTime.sprite.h"
#include "Sprites/PowerUp_NormalWeaponsSystem.sprite.h"
#include "Sprites/PowerUp_SlowWeaponsSystem.sprite.h"

PowerUpsCtrl::PowerUpsCtrl ()
{
	eObType = (ePowerUpType) (rand () % LAST_POWERUP_TYPE);
}

PowerUpsCtrl::~PowerUpsCtrl ()
{
}

void PowerUpsCtrl::Initialize (class BibWorld * inpWorld)
{
	// Call the base class initialize.
	BibControl::Initialize (inpWorld);

	pWorld = (ShooterWorld *) inpWorld;

	// Add the sprites.
	switch (eObType)
	{
		default:
		case LIVES_PLUS_1:
			basSpriteData . AddFrame (0, 100000, 0, LivesPlus1_Bitmap, LIVESPLUS1_WIDTH, LIVESPLUS1_HEIGHT);
		break;

		case SLOW_WEAPONS_SYSTEM:
			basSpriteData . AddFrame (0, 100000, 0, PowerUp_SlowWeaponsSystem_Bitmap, POWERUP_SLOWWEAPONSSYSTEM_WIDTH, POWERUP_SLOWWEAPONSSYSTEM_HEIGHT);
		break;

		case BIG_BOMB_WEAPONS_SYSTEM:
			basSpriteData . AddFrame (0, 100000, 0, PowerUp_BigBombWeaponsSystem_Bitmap, POWERUP_BIGBOMBWEAPONSSYSTEM_WIDTH, POWERUP_BIGBOMBWEAPONSSYSTEM_HEIGHT);
		break;

		case NORMAL_WEAPONS_SYSTEM:
			basSpriteData . AddFrame (0, 100000, 0, PowerUp_NormalWeaponsSystem_Bitmap, POWERUP_NORMALWEAPONSSYSTEM_WIDTH, POWERUP_NORMALWEAPONSSYSTEM_HEIGHT);
		break;

		case MISSILE_WEAPONS_SYSTEM:
			basSpriteData . AddFrame (0, 100000, 0, PowerUp_MissileWeaponsSystem_Bitmap, POWERUP_MISSILEWEAPONSSYSTEM_WIDTH, POWERUP_MISSILEWEAPONSSYSTEM_HEIGHT);
		break;

		case ADD_MORE_TIME:
			basSpriteData . AddFrame (0, 100000, 0, PowerUp_MoreTime_Bitmap, POWERUP_MORETIME_WIDTH, POWERUP_MORETIME_HEIGHT);
		break;
	}

	basSpriteData.SetCurSequence (0);
	basSpriteData.SetCurFrame (0);

	bpSize.x = basSpriteData.GetCurSprite () . GetWidth ();
	bpSize.y = basSpriteData.GetCurSprite () . GetHeight ();

	// This is a PowerUps!
	nFlags = IS_WALL;
}

void PowerUpsCtrl::UnInitialize ()
{

}



bool PowerUpsCtrl::UpdateMovement (float fSpeedFactor)
{

	// Call the base class to update sprite data, etc.
	if (BibControl::UpdateMovement (fSpeedFactor))
	{
		return (true);
	}

	return (false);
}


void PowerUpsCtrl::HeroPickedUp (void)
{
	switch (eObType)
	{
		default:
		case LIVES_PLUS_1:
			pWorld -> IncLives ();
		break;

		case SLOW_WEAPONS_SYSTEM:
			pWorld->GetHeroCtrl().AddWeaponsSystem (HeroCtrl::SLOW_MULTI);
		break;

		case BIG_BOMB_WEAPONS_SYSTEM:
			pWorld->GetHeroCtrl().AddWeaponsSystem (HeroCtrl::BIG_BOMB);
		break;

		case NORMAL_WEAPONS_SYSTEM:
			pWorld->GetHeroCtrl().AddWeaponsSystem (HeroCtrl::NORMAL);
		break;

		case MISSILE_WEAPONS_SYSTEM:
			pWorld->GetHeroCtrl().AddWeaponsSystem (HeroCtrl::SEEKER);
		break;
	
		case ADD_MORE_TIME:
			pWorld->IncTimeLeft (20);
		break;
	
	}


	// Play the powerup sound.
	pWorld -> pSound . PlaySoundAsync (ShooterSound::POWER_UP);

	// Give the player some points.
	pWorld -> IncLevelScore (100);

	// Delete this object.
	SetSelfDestruct ();
}
