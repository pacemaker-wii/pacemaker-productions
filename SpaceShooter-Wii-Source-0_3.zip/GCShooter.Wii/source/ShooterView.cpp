// ShooterView.h: interface for the ShooterView class.
//
//////////////////////////////////////////////////////////////////////


#include "ShooterView.h"
#include "ShooterWorld.h"


static int Parade_CharWidths [128] = {
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
9, /* * */
7, /*   */
7, /* ! */
9, /* " */
14, /* # */
11, /* $ */
23, /* % */
15, /* & */
5, /* ' */
7, /* ( */
7, /* ) */
9, /* * */
13, /* + */
5, /* , */
10, /* - */
5, /* . */
10, /* / */
16, /* 0 */
16, /* 1 */
16, /* 2 */
16, /* 3 */
16, /* 4 */
16, /* 5 */
16, /* 6 */
16, /* 7 */
16, /* 8 */
16, /* 9 */
5, /* : */
5, /* ; */
13, /* < */
13, /* = */
13, /* > */
12, /* ? */
17, /* @ */
17, /* A */
15, /* B */
15, /* C */
17, /* D */
15, /* E */
14, /* F */
16, /* G */
18, /* H */
8, /* I */
14, /* J */
16, /* K */
14, /* L */
21, /* M */
17, /* N */
16, /* O */
14, /* P */
16, /* Q */
15, /* R */
14, /* S */
14, /* T */
17, /* U */
19, /* V */
25, /* W */
18, /* X */
17, /* Y */
15, /* Z */
7, /* [ */
10, /* \ */
7, /* ] */
13, /* ^ */
13, /* _ */
4, /* ` */
13, /* a */
14, /* b */
12, /* c */
14, /* d */
12, /* e */
8, /* f */
12, /* g */
15, /* h */
8, /* i */
7, /* j */
13, /* k */
7, /* l */
19, /* m */
14, /* n */
12, /* o */
13, /* p */
14, /* q */
10, /* r */
10, /* s */
9, /* t */
14, /* u */
15, /* v */
19, /* w */
15, /* x */
17, /* y */
12, /* z */
7, /* { */
13, /* | */
7, /* } */
13, /* ~ */
9, /* * */
};


#include "Sprites/ParadeBitmapFont.Sprite.h"
#include "Sprites/ShooterSplashScreen.sprite.h"
#include "Sprites/ThanksEasterEgg.sprite.h"
ShooterView::ShooterView()
{
	BibView::BibView ();
	//!!!! This should really be in a ShooterView::Initialize() function.
	ScreenFont . Initialize ((u32 *) ParadeBitmapFont_Bitmap, PARADEBITMAPFONT_WIDTH, PARADEBITMAPFONT_HEIGHT, 26, 26+8, Parade_CharWidths, 20);
	SplashScreenSprite.LoadBitmap ((u32 *)ShooterSplashScreen_Bitmap, SHOOTERSPLASHSCREEN_WIDTH, SHOOTERSPLASHSCREEN_HEIGHT);
	ThanksEasterEggSprite.LoadBitmap ((u32 *)ThanksEasterEgg_Bitmap, THANKSEASTEREGG_WIDTH, THANKSEASTEREGG_HEIGHT);
}

ShooterView::~ShooterView()
{
}


//!!!! For Debug only.
char szDebugMsg1 [256] = "";
char szDebugMsg2 [256] = "";
char szDebugMsg3 [256] = "";


static int nFrameCounter = 0;

void ShooterView::Render (BibGraphicsDevice & GD)
{
char szBuf [1024];
ShooterWorld::BulletListType * pBulletList;
ShooterWorld::BulletListIteratorType bit;
ShooterWorld::EnemyListType * pEnemyList;
ShooterWorld::EnemyListIteratorType eit;
BibPoint bpLoc;

	// Check to see if we have been initialized.
	if (! pWorld)
		return;


	if (pTheWorld -> GetGameState () == ShooterWorld::SPLASH_SCREEN)
	{
		bpLoc . x = 0;
		bpLoc . y = 0;
		GD . RenderBitmap (SplashScreenSprite, bpLoc);

		GD.ConsoleDrawString(34, 432, SHOOTER_VERSION);
	}
	else if (pTheWorld -> GetGameState () == ShooterWorld::THANK_YOU_EASTER_EGG)
	{
		bpLoc . x = 0;
		bpLoc . y = 0;
		GD . RenderBitmap (ThanksEasterEggSprite, bpLoc);
	}
	else
	{

		/*
			Put background bitmap in here.
		*/
		bpLoc . x = 0;
		bpLoc . y = 0;
		GD . RenderBitmap (pWorld -> GetBackgroundSprite (), bpLoc);


		/*
			Iterate over all Inanimate objects.
		*/
		pEnemyList = pTheWorld -> GetInAnimatesList ();
		for (eit = pEnemyList->begin(); eit != pEnemyList->end();  ++eit)
		{
			bpLoc =  (*eit) -> GetLocation ();
			if (pTheWorld -> IsInViewPort (bpLoc))
			{
				bpLoc = pTheWorld -> TranslateWorldToScreenCoords (bpLoc);
				GD . RenderBitmap ((*eit) -> GetCurSprite (), bpLoc);
			}
		}


		/*
			Iterate over all Power Ups.
		*/
		pEnemyList = pTheWorld -> GetPowerUpsList ();
		for (eit = pEnemyList->begin(); eit != pEnemyList->end();  ++eit)
		{
			bpLoc =  (*eit) -> GetLocation ();
			if (pTheWorld -> IsInViewPort (bpLoc))
			{
				bpLoc = pTheWorld -> TranslateWorldToScreenCoords (bpLoc);
				GD . RenderBitmap ((*eit) -> GetCurSprite (), bpLoc);
			}
		}

		/*
			Display the hero.
		*/
		bpLoc = pTheWorld -> GetHeroCtrl () . GetLocation ();
		if (pTheWorld -> IsInViewPort (bpLoc))
		{
			bpLoc = pTheWorld -> TranslateWorldToScreenCoords (bpLoc);
			GD . RenderBitmap (pTheWorld -> GetHeroCtrl () . GetCurSprite (), bpLoc);
		}


		/*
			Iterate over all bullets.
		*/
		pBulletList = pTheWorld -> GetBulletList ();
		for (bit = pBulletList->begin(); bit != pBulletList->end();  ++bit)
		{
			bpLoc =  (*bit) -> GetLocation ();
			if (pTheWorld -> IsInViewPort (bpLoc))
			{
				bpLoc = pTheWorld -> TranslateWorldToScreenCoords (bpLoc);
				GD . RenderBitmap ((*bit) -> GetCurSprite (), bpLoc);
			}
		}

		/*
			Iterate over all enemies.
		*/
		pEnemyList = pTheWorld -> GetEnemyList ();
		for (eit = pEnemyList->begin(); eit != pEnemyList->end();  ++eit)
		{
			bpLoc =  (*eit) -> GetLocation ();
			if (pTheWorld -> IsInViewPort (bpLoc))
			{
				bpLoc = pTheWorld -> TranslateWorldToScreenCoords (bpLoc);
				GD . RenderBitmap ((*eit) -> GetCurSprite (), bpLoc);
			}
		}

		/*
			Iterate over all dead enemies.
		*/
		pEnemyList = pTheWorld -> GetDeadEnemyList ();
		for (eit = pEnemyList->begin(); eit != pEnemyList->end();  ++eit)
		{
			bpLoc =  (*eit) -> GetLocation ();
			if (pTheWorld -> IsInViewPort (bpLoc))
			{
				bpLoc = pTheWorld -> TranslateWorldToScreenCoords (bpLoc);
				GD . RenderBitmap ((*eit) -> GetCurSprite (), bpLoc);
			}
		}



		/*
			Radar display.
			//!!!! Should combine this iteration with the ones above.
			//!!!! This will give some speed optimization.
		*/
		// Iterate over all Inanimate objects.
		pEnemyList = pTheWorld -> GetInAnimatesList ();
		for (eit = pEnemyList->begin(); eit != pEnemyList->end();  ++eit)
		{
			if ((*eit) -> OnRadar ())
			{
				bpLoc =  (*eit) -> GetLocation ();
				bpLoc = pTheWorld -> TranslateWorldToRadarCoords (bpLoc);
				GD . RenderBitmap (pTheWorld -> GetInAnimRadarSprite (), bpLoc);
			}
		}

		// Iterate over all enemies.
		pEnemyList = pTheWorld -> GetEnemyList ();
		for (eit = pEnemyList->begin(); eit != pEnemyList->end();  ++eit)
		{
			bpLoc =  (*eit) -> GetLocation ();
			bpLoc = pTheWorld -> TranslateWorldToRadarCoords (bpLoc);
			GD . RenderBitmap (pTheWorld -> GetEnemyRadarSprite (), bpLoc);
		}


		// Display Hero.
		bpLoc = pTheWorld -> GetHeroCtrl () . GetLocation ();
		bpLoc = pTheWorld -> TranslateWorldToRadarCoords (bpLoc);
		GD . RenderBitmap (pTheWorld -> GetHeroRadarSprite (), bpLoc);

		/* End Radar Display */




		/*
			Display Level Title.
		*/
		ScreenFont . DisplayText (GD, LEVEL_TITLE_X, LEVEL_TITLE_Y, 
									pWorld -> GetLevelTitle ());

		/*
			Display Level Number
		*/
		sprintf (szBuf, "Level: %03d", pWorld -> GetLevel ());
		ScreenFont . DisplayText (GD, LEVEL_NUMBER_X, LEVEL_NUMBER_Y, szBuf);

		/*
			Display the score.
		*/
		sprintf (szBuf, "Score: %03d", pWorld -> GetScore () + pWorld -> GetLevelScore ());
		ScreenFont . DisplayText (GD, SCORE_NUMBER_X, SCORE_NUMBER_Y, szBuf);

		/*
			Display the points potentially earned in this level
		*/
	/*
		sprintf (szBuf, "Score + %d", pWorld -> GetLevelScore ());
		ScreenFont . DisplayText (GD, SCORE_PLUS_NUMBER_X, SCORE_PLUS_NUMBER_Y, szBuf);
	*/
		/*
			Display the number of lives left.
		*/
		sprintf (szBuf, "Lives: %d", pWorld -> GetLives ());
		ScreenFont . DisplayText (GD, LIVES_NUMBER_X, LIVES_NUMBER_Y, szBuf);

		/*
			Display the amount of time left.
		*/
		sprintf (szBuf, "Time: %0.02f", pWorld -> GetTimeLeft ());
		ScreenFont . DisplayText (GD, TIME_LEFT_NUMBER_X, TIME_LEFT_NUMBER_Y, szBuf);

		/*
			Display the hero's hit points (shields).
		*/
		sprintf (szBuf, "Shields: %d", pTheWorld -> GetHeroCtrl () . GetHitPoints ());
		ScreenFont . DisplayText (GD, SHIELDS_LEFT_NUMBER_X, SHIELDS_LEFT_NUMBER_Y, szBuf);



		if (pTheWorld -> GetGameState () == ShooterWorld::GAME_OVER)
			ScreenFont . DisplayText (GD, GAME_OVER_X, GAME_OVER_Y, "GAME OVER");

		if (pTheWorld -> GetGameState () == ShooterWorld::START_OF_LEVEL)
			ScreenFont . DisplayText (GD, NEXT_LEVEL_X, NEXT_LEVEL_Y, "Ready for Next Level...");

		if (pTheWorld -> GetGameState () == ShooterWorld::RESTART_OF_LEVEL)
			ScreenFont . DisplayText (GD, NEXT_LEVEL_X, NEXT_LEVEL_Y, "Restarting Level...");

		if (pTheWorld -> GetGameState () == ShooterWorld::END_OF_LEVEL)
			ScreenFont . DisplayText (GD, NEXT_LEVEL_X, NEXT_LEVEL_Y, "Congrats! Level Complete.");

		// Display generic message from the World object, typically controller missing.
		const char * pMsg = pTheWorld -> GetWorldMsg ();
		if (pMsg && (pMsg [0]))
			ScreenFont . DisplayText (GD, 40, 220, pMsg);
	}



	if (pTheWorld->IsDebugOn())
	{
		/*
			Show PAD Inputs and frame numbers.
		*/

		sprintf (szBuf, "(%d)", nFrameCounter ++);
		GD.ConsoleDrawString (40, 50, szBuf);


		if (szDebugMsg1 [0]) GD.ConsoleDrawString (40, 72, szDebugMsg1);
		if (szDebugMsg2 [0]) GD.ConsoleDrawString (40, 88, szDebugMsg2);
		if (szDebugMsg3 [0]) GD.ConsoleDrawString (40, 104, szDebugMsg3);


		sprintf (szBuf, "(%d)(%s)", pTheWorld->pSound.AudioStatus, pTheWorld->pSound.szAudioLastMsg);
		GD.ConsoleDrawString(40, 350, szBuf);


		extern int nDebugCounterL;
		extern int nDebugCounterR;
		sprintf (szBuf, "nDCL(%d) nDCR(%d)", nDebugCounterL, nDebugCounterR);
		GD.ConsoleDrawString(40, 366, szBuf);

	#ifdef SHOW_OVERSCAN_BOX
		bpLoc.x = 0;
		bpLoc.y = 0;
		GD.RenderBitmap (pTheWorld->bsOverscanBox, bpLoc);
	#endif

	}	// End if (bDebugOn)



	/*
		Main Menu Display
	*/
	if (pTheWorld -> GetGameState () == ShooterWorld::MAIN_MENU)
	{
		pTheWorld -> TheMainMenu.DisplayListBox (GD);
	}




	// Put this at the bottom so it won't be greyed out when the menu is active.
	if (pTheWorld->IsDebugOn())
	{
		/*
			Put the fps at the bottom.
		*/
		sprintf (szBuf, "fps %04.0f, sf %04.0f", fps.fps, fps.fspeedfactor);
		GD.ConsoleDrawString(40, 334, szBuf);
	}
}

