/*

	PowerUpsControl Class

*/

#pragma once

#include "BibLib/BibCtrl.h"

class PowerUpsCtrl : public BibControl
{
public:
	enum ePowerUpType { LIVES_PLUS_1 = 0, NORMAL_WEAPONS_SYSTEM, 
						SLOW_WEAPONS_SYSTEM, BIG_BOMB_WEAPONS_SYSTEM, 
						MISSILE_WEAPONS_SYSTEM, ADD_MORE_TIME,
						LAST_POWERUP_TYPE };

private:
	ePowerUpType eObType;

	class ShooterWorld * pWorld;

public:
	PowerUpsCtrl ();
	~PowerUpsCtrl ();

	void Initialize (class BibWorld * pWorld);
	void UnInitialize ();

	// This is called very often to have the object move, etc.
	bool UpdateMovement (float fSpeedFactor);
	
	void SetObType (ePowerUpType ineObType) { eObType = ineObType; }

	bool Shot (int nHits) { return (false); }
	void HeroPickedUp (void);

};
