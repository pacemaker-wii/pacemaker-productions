/*

	ShooterSound.cpp

*/



#include "ShooterSound.h"
#include <gccore.h>


#define IncludeWav(name) \
	asm ( \
	   ".rodata\n" \
	   ".globl " #name "\n" \
	   ".balign 32\n" \
	   "" #name "SndData:\n" \
	   ".incbin \"../data/" #name ".wav\"\n" \
		 ); \
	extern u8 name## SndData[];


#define IncludeMp3(name) \
	asm ( \
	   ".rodata\n" \
	   ".globl " #name "\n" \
	   ".globl " #name "Mp3SndData_length\n" \
	   ".balign 32\n" \
	   "" #name "Mp3SndData:\n" \
	   ".incbin \"../data/" #name ".mp3\"\n" \
	   "" #name "Mp3SndData_end:\n" \
	   "" #name "Mp3SndData_length: .long 0\n" \
		 ); \
	extern u8 name## Mp3SndData[]; \
	extern u32 name## Mp3SndData_length;


IncludeWav(Explosion);
IncludeWav(SeekerLock);
IncludeWav(TurretShot);
IncludeWav(PowerUp);
IncludeWav(OUCH);

IncludeMp3(_87704_Hillbilly_breakout_);
#if 0
IncludeMp3(_119512_shaolin_temple_);
IncludeMp3(_99757_Made_in_plastic_demo_);
IncludeMp3(_128910_Aimless_);
IncludeMp3(_155475_Generic_Stimulation_Factor_);
IncludeMp3(_122701_Uranium_Shark_);
#endif

ShooterSound::ShooterSound ()
{
	LoadSoundWav (EXPLOSION, ExplosionSndData);
	LoadSoundWav (SEEKER_LOCK, SeekerLockSndData);
	LoadSoundWav (TURRET_SHOT, TurretShotSndData);
	LoadSoundWav (POWER_UP, PowerUpSndData);
	LoadSoundWav (OUCH, OUCHSndData);
	
	_87704_Hillbilly_breakout_Mp3SndData_length = (unsigned int) (& _87704_Hillbilly_breakout_Mp3SndData_length) - (unsigned int) (_87704_Hillbilly_breakout_Mp3SndData);
	LoadSoundMp3 (MP3_HILLBILLY_BREAKOUT, _87704_Hillbilly_breakout_Mp3SndData, _87704_Hillbilly_breakout_Mp3SndData_length);
#if 0
	_119512_shaolin_temple_Mp3SndData_length = (unsigned int) (& _119512_shaolin_temple_Mp3SndData_length) - (unsigned int) (_119512_shaolin_temple_Mp3SndData);
	LoadSoundMp3 (MP3_SHAOLIN_TEMPLE, _119512_shaolin_temple_Mp3SndData, _119512_shaolin_temple_Mp3SndData_length);

	_99757_Made_in_plastic_demo_Mp3SndData_length = (unsigned int) (& _99757_Made_in_plastic_demo_Mp3SndData_length) - (unsigned int) (_99757_Made_in_plastic_demo_Mp3SndData);
	LoadSoundMp3 (MP3_MADE_IN_PLASTIC, _99757_Made_in_plastic_demo_Mp3SndData, _99757_Made_in_plastic_demo_Mp3SndData_length);

	_128910_Aimless_Mp3SndData_length = (unsigned int) (& _128910_Aimless_Mp3SndData_length) - (unsigned int) (_128910_Aimless_Mp3SndData);
	LoadSoundMp3 (MP3_AIMLESS, _128910_Aimless_Mp3SndData, _128910_Aimless_Mp3SndData_length);

	_155475_Generic_Stimulation_Factor_Mp3SndData_length = (unsigned int) (& _155475_Generic_Stimulation_Factor_Mp3SndData_length) - (unsigned int) (_155475_Generic_Stimulation_Factor_Mp3SndData);
	LoadSoundMp3 (MP3_GENERIC_FACTOR, _155475_Generic_Stimulation_Factor_Mp3SndData, _155475_Generic_Stimulation_Factor_Mp3SndData_length);

	_122701_Uranium_Shark_Mp3SndData_length = (unsigned int) (& _122701_Uranium_Shark_Mp3SndData_length) - (unsigned int) (_122701_Uranium_Shark_Mp3SndData);
	LoadSoundMp3 (MP3_URANIUM_SHARK, _122701_Uranium_Shark_Mp3SndData, _122701_Uranium_Shark_Mp3SndData_length);
#endif
}


int ShooterSound::PlaySoundAsync (enum ShooterSound::eSounds eThisSound)
{
	if (! IsOn ())
		return (0);

	return (PlaySound ((int) eThisSound));
}
