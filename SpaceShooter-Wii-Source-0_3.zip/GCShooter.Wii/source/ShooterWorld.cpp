// ShooterWorld.cpp: implementation for the ShooterWorld class.
//
//////////////////////////////////////////////////////////////////////


#include "GameConstants.h"
#include "ShooterWorld.h"
#include "HeroCtrl.h"
#include "Enemy1Ctrl.h"
#include "PokeEnemyCtrl.h"
#include "SeekerEnemyCtrl.h"
#include "TurretEnemyCtrl.h"
#include "InaObCtrl.h"
#include "PowerUpCtrl.h"
#include "Intersection.h"
#include "ShooterLevelLoader.h"


#include "Sprites/ShooterBackground.sprite.h"
#include "Sprites/EnemyRadarPic.sprite.h"
#include "Sprites/HeroRadarPic.sprite.h"
#include "Sprites/InAnimRadarPic.sprite.h"

#ifdef SHOW_OVERSCAN_BOX
#include "Sprites/OverscanBox.sprite.h"
#endif



static BibWiiInputDevice::SingleAction saSplashScreenAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
											{BibWiiInputDevice::CTRL_GAMECUBE, PAD_BUTTON_A}
																};
static BibWiiInputDevice::SingleAction saButtonMinusAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_MINUS},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_MINUS},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_MINUS},
											{BibWiiInputDevice::CTRL_GAMECUBE, PAD_TRIGGER_L}
																};
static BibWiiInputDevice::SingleAction saButtonPlusAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_PLUS},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_PLUS},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_PLUS},
											{BibWiiInputDevice::CTRL_GAMECUBE, PAD_TRIGGER_Z}
																};


ShooterWorld::ShooterWorld ()
{
	szWorldMsg = "";
}

ShooterWorld::~ShooterWorld ()
{
}



void ShooterWorld::Initialize (GXRModeObj * vMode)
{
	BibWorld::Initialize (true);
	WiiInputDevice.Initialize (vMode);

	// Instantiate button actions.
	WiiSplashScreenAction= WiiInputDevice.DefineAction (saSplashScreenAction);
	WiiButtonMinusAction= WiiInputDevice.DefineAction (saButtonMinusAction);
	WiiButtonPlusAction = WiiInputDevice.DefineAction (saButtonPlusAction);

	TheMainMenu.Initialize (this);
	pSound.Initialize ();


	// Load background
	bsBackgroundPic . LoadBitmap ((u32 *)ShooterBackground_Bitmap, SHOOTERBACKGROUND_WIDTH, SHOOTERBACKGROUND_HEIGHT);

#ifdef SHOW_OVERSCAN_BOX
	bsOverscanBox . LoadBitmap ((u32 *)OverscanBox_Bitmap, OVERSCANBOX_WIDTH, OVERSCANBOX_HEIGHT);
#endif

	// Load Radar pics
	bsEnemyRadarPic . LoadBitmap ((u32 *) EnemyRadarPic_Bitmap, ENEMYRADARPIC_WIDTH, ENEMYRADARPIC_HEIGHT);
	bsHeroRadarPic . LoadBitmap ((u32 *) HeroRadarPic_Bitmap, HERORADARPIC_WIDTH, HERORADARPIC_HEIGHT);
	bsInAnimRadarPic . LoadBitmap ((u32 *) InAnimRadarPic_Bitmap, INANIMRADARPIC_WIDTH, INANIMRADARPIC_HEIGHT);

#ifdef PRODUCTION
	bDebugOn = FALSE;
#else
	bDebugOn = TRUE;
#endif


	// Set game state to playing
	eGameState = ShooterWorld::SPLASH_SCREEN;

	// Initialize the hero here.
	pHero.Initialize (this);
	BibPoint bpZero (0, 0);
	pHero.SetLocation (bpZero);

	Reset ();

}


void ShooterWorld::Reset (void)
{
	// Delete any old objects.
	DeleteAllObjects ();

	// Clear scores.
	SetScore (0);
	SetLevelScore (0);
	SetTimeLeft (STD_LEVEL_TIME_LEFT);

	pHero.Reset ();

	// Set level to 1.
	SetLevel (1);
	
	nGameOverCounter = 0;
}

void ShooterWorld::UnInitialize (void)
{
	BibWorld::UnInitialize ();
}














//!!!! Delete this after debug is complete.
int nDebugCounterL = 0;
int nDebugCounterR = 0;
//extern char szDebugMsg1 [256];
//extern char szDebugMsg2 [256];
//extern char szDebugMsg3 [256];















/*
	Main Control Loop.

	This is called every game loop.
*/
void ShooterWorld::UpdateMovement (float fSpeedFactor)
{
	WiiInputDevice.ScanInputDevice (pView->fps.fFrameTimeDelta);


	/*
		Debug button detection.
	*/
	if (WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiButtonMinusAction))
 	{
		nDebugCounterL ++;
	}
	
	if (WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiButtonPlusAction))
 	{
		WiiInputDevice.ControlMotor (BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_CHAN_0, TRUE);
		nDebugCounterR ++;
		pSound . PlaySoundAsync (ShooterSound::EXPLOSION);
		WiiInputDevice.ControlMotor (BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_CHAN_0, FALSE);
	}


	// Allow mp3 background task to process.
	pSound.UpdateMovement ();


	/*
		Set the World Message.
	*/
	szWorldMsg = "";
	switch (WiiInputDevice.GetCurActionSet ())
	{
		case 0:	// Wii Remote
		case 1:	// Wii Remote
			if (! WiiInputDevice.IsPresent (BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_CHAN_0))
				szWorldMsg = "Wii remote 1 not found!";
		break;
		
		case 2:	// Wii Remote + Nunchuk
			if (! WiiInputDevice.IsPresent (BibWiiInputDevice::CTRL_EXT_NUNCHUK, WPAD_CHAN_0))
				szWorldMsg = "Nunchuk extension on Wii remote 1 not found!";
		break;
		
		case 3:	// GameCube
			if (! WiiInputDevice.IsPresent (BibWiiInputDevice::CTRL_GAMECUBE, PAD_CHAN0))
				szWorldMsg = "GameCube controller 1 not found!";
		break;

		default:
			szWorldMsg = "Bad Action Set.";
		break;
	}


	// There are two purposes of this call.
	// (1) It checks to see if we need to switch state to MAIN_MENU state (pressed home button)
	// (2) When in MAIN_MENU state, it draws the menu.
	//  It seems one call should be here and another in the "case ShoterWorld::MAIN_MENU:" below.
	if (TheMainMenu.UpdateMovement ())
	{
		// The Menu must have swallowed some user input, don't try to process any more.
		//  For example, back key was pressed.  Don't interpret it as something else below.
		return;
	}


	// State machine:
	switch (eGameState)
	{
		case ShooterWorld::PLAYING:
			// If all the enemies are gone, we're done with this level.
			if ((lEnemyList.size () == 0) && (lDeadEnemyList.size () == 0))
			{
				eGameState = ShooterWorld::END_OF_LEVEL;
				fNextStateTime = 0;
				return;
			}

			// When there is no time left, the game is over.
			DecTimeLeft (pView->fps.fFrameTimeDelta);
			if (GetTimeLeft () <= 0)
			{
				// Time is up!
				HeroDied ();
			}

			UpdateObjectLists (fSpeedFactor);

			CheckForCollisions ();

			CheckForScroll (fSpeedFactor);
		break;

		case ShooterWorld::MAIN_MENU:
			// Don't do any processing.
			return;
		break;

		default:
		case ShooterWorld::SPLASH_SCREEN:

			if (WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiSplashScreenAction))
			{
				eGameState = ShooterWorld::START_OF_LEVEL;
				Reset ();
			}
			// Don't do any processing.
			return;
		break;

		case ShooterWorld::GAME_OVER:
			nGameOverCounter ++;
			if (nGameOverCounter > GAME_OVER_WAIT_TIME)
			{
				nGameOverCounter = 0;
				eGameState = ShooterWorld::SPLASH_SCREEN;
			}
			
			// Don't do any more processing.
			return;
		break;

		// We are finishing a level.
		case ShooterWorld::END_OF_LEVEL:
			// Make sure we've waiting long enough to start the next level.
			fNextStateTime += fSpeedFactor;
			if (fNextStateTime > NEXT_LEVEL_DELAY)
			{
				fNextStateTime = 0;
				eGameState = ShooterWorld::START_OF_LEVEL;
				IncLevel ();
				IncScore (GetLevelScore ());
				SetLevelScore (0);
				SetTimeLeft (STD_LEVEL_TIME_LEFT);
			}
			return;
		break;

		// We are starting the next level.
		case ShooterWorld::START_OF_LEVEL:
			fNextStateTime += fSpeedFactor;
			if (fNextStateTime > NEXT_LEVEL_DELAY)
			{
				fNextStateTime = 0;
				eGameState = ShooterWorld::PLAYING;
				// Play the level specific background music.
				pSound . PlaySoundAsync (ShooterSound::MP3_HILLBILLY_BREAKOUT);
#if 0				
				if (nLevel == 1) pSound . PlaySoundAsync (ShooterSound::MP3_HILLBILLY_BREAKOUT);
				else if (nLevel == 2) pSound . PlaySoundAsync (ShooterSound::MP3_SHAOLIN_TEMPLE);
				else if (nLevel == 3) pSound . PlaySoundAsync (ShooterSound::MP3_MADE_IN_PLASTIC);
				else if (nLevel == 4) pSound . PlaySoundAsync (ShooterSound::MP3_AIMLESS);
				else if (nLevel == 5) pSound . PlaySoundAsync (ShooterSound::MP3_GENERIC_FACTOR);
				else if (nLevel == 6) pSound . PlaySoundAsync (ShooterSound::MP3_URANIUM_SHARK);
#endif
			}
			return;
		break;

		// We are Re-starting the current level.
		case ShooterWorld::RESTART_OF_LEVEL:
			fNextStateTime += fSpeedFactor;
			if (fNextStateTime > NEXT_LEVEL_DELAY)
			{
				fNextStateTime = 0;
				eGameState = ShooterWorld::PLAYING;
				SetTimeLeft (STD_LEVEL_TIME_LEFT);
			}
			return;
		break;
		
		case ShooterWorld::THANK_YOU_EASTER_EGG:
			if (WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiSplashScreenAction))
			{
				eGameState = ShooterWorld::PLAYING;
			}
		break;

	}

}

void ShooterWorld::UpdateObjectLists (float fSpeedFactor)
{
BulletListIteratorType bit;
EnemyListIteratorType eit;

	// Update the Hero (shoot, animation, etc)
	pHero.UpdateMovement (fSpeedFactor);


	// Iterate over all bullets.
	// Update/Animate/Move them, and destroy them.
	for (bit = lBulletList.begin(); bit != lBulletList.end();  ++bit)
	{
		(*bit) -> UpdateMovement (fSpeedFactor);

		if ((*bit) -> SelfDestruct ())
		{
			delete (*bit);
			bit = lBulletList.erase (bit);
		}
	}

	// Iterate over all enemies.
	// Update/Animate/Move them, and 'destroy' them.
	for (eit = lEnemyList.begin(); eit != lEnemyList.end();  ++eit)
	{
		(*eit) -> UpdateMovement (fSpeedFactor);

		if ((*eit) -> SelfDestruct ())
		{
			// Add the enemy to the dead list and remove it
			//  from this list.
			lDeadEnemyList.push_back ((*eit));
			(*eit) -> ClearSelfDestruct ();
			eit = lEnemyList.erase (eit);
		}
	}


	// Iterate over all dead enemies.
	// Update/Animate/Move them, and destroy them.
	for (eit = lDeadEnemyList.begin(); eit != lDeadEnemyList.end();  ++eit)
	{
		(*eit) -> UpdateMovement (fSpeedFactor);

		if ((*eit) -> SelfDestruct ())
		{
			delete ((*eit));
			eit = lDeadEnemyList.erase (eit);
		}
	}


	// Iterate over all Power Up Objects.
	// Update/Animate/Move them, and destroy them.
	for (eit = lPowerUpsList.begin(); eit != lPowerUpsList.end();  ++eit)
	{
		(*eit) -> UpdateMovement (fSpeedFactor);

		if ((*eit) -> SelfDestruct ())
		{
			delete ((PowerUpsCtrl*)(*eit));
			eit = lPowerUpsList.erase (eit);
		}
	}


	// Iterate over all inanimate objects.
	// Update/Animate/Move them, and destroy them.
	for (eit = lInAnimList.begin(); eit != lInAnimList.end();  ++eit)
	{
		(*eit) -> UpdateMovement (fSpeedFactor);

		if ((*eit) -> SelfDestruct ())
		{
			delete ((InAnimateObjectCtrl*)(*eit));
			eit = lInAnimList.erase (eit);
		}
	}

}

void ShooterWorld::CheckForScroll (float fSpeedFactor)
{
BibPoint bpLoc;

	// Check to see if we need to scroll the map.
	bpLoc = pHero.GetLocation ();

	// X too small?
	if ((bpLoc.x < bpViewCoords.x + VIEWPORT_SCROLL_BUFFER_X) &&
		(bpViewCoords.x > 0))
	{
		bpViewCoords.x -= SCROLL_INCREMENT * fSpeedFactor;
	}

	// X too big?
	if ((bpLoc.x > bpViewCoords.x + VIEWPORT_WIDTH - VIEWPORT_SCROLL_BUFFER_X) &&
		(bpViewCoords.x < MAP_SIZE_X - VIEWPORT_WIDTH))
	{
		bpViewCoords.x += SCROLL_INCREMENT * fSpeedFactor;
	}

	// Y too small?
	if ((bpLoc.y < bpViewCoords.y + VIEWPORT_SCROLL_BUFFER_Y) &&
		(bpViewCoords.y > 0))
	{
		bpViewCoords.y -= SCROLL_INCREMENT * fSpeedFactor;
	}

	// Y too big?
	if ((bpLoc.y > bpViewCoords.y + VIEWPORT_HEIGHT - VIEWPORT_SCROLL_BUFFER_Y) &&
		(bpViewCoords.y < MAP_SIZE_Y - VIEWPORT_HEIGHT))
	{
		bpViewCoords.y += SCROLL_INCREMENT * fSpeedFactor;
	}
}



void ShooterWorld::CheckForCollisions (void)
{
BulletListIteratorType bit;
EnemyListIteratorType eit;
int nHits1, nHits2;


	// Iterate over all enemies.
	for (eit = lEnemyList.begin(); eit != lEnemyList.end();  ++eit)
	{
		// Check for enemy vs. hero.
		if (CheckIntersection (pHero, *(*eit)))
		{
			//!!! Need fancy shot rountines here.
			nHits1 = pHero.GetHitPoints ();
			nHits2 = (*eit) -> GetHitPoints ();

			// Hero was shot, was he dead?
			if (pHero.Shot (nHits2))
			{
				HeroDied ();
				return;
			}

			// Enemy was shot, was he dead?
			if ((*eit) -> Shot (nHits1))
			{
				// No points for running into an enemy.
				// But you get a nice exploding sound.
				pSound . PlaySoundAsync (ShooterSound::EXPLOSION);

				// Move the enemy to the dead enemy list.
				lDeadEnemyList.push_back ((*eit));
				(*eit) -> SetSelfDestruct ();
				eit = lEnemyList.erase (eit);
			}
			return;
		}


		// Iterate over all bullets and see if they kill any enemies or the hero.
		for (bit = lBulletList.begin(); bit != lBulletList.end();  ++bit)
		{
			// Is this an enemy bullet?
			if ((*bit) -> GetFlags () == BibControl::IS_ENEMY)
			{
				// Enemy Bullet, check for collision with Hero.

				// Check for hero vs. bullet.
				if (CheckIntersection (pHero, *(*bit)))
				{
					//!!! Need fancy shot rountines here.
					nHits1 = pHero.GetHitPoints ();
					nHits2 = (*bit) -> GetHitPoints ();

					// Hero was shot, was he dead?
					if (pHero.Shot (nHits2))
					{
						HeroDied ();
						return;
					}

					// Bullet was shot, was he dead?
					if ((*bit) -> Shot (nHits1))
					{
						pSound . PlaySoundAsync (ShooterSound::OUCH);

						// Remove the bullet.
						delete (*bit);
						bit = lBulletList.erase (bit);
					}

					return;
				}

				continue;
			}

			// Check for enemy vs. bullet.
			if (CheckIntersection (*(*bit), *(*eit)))
			{
				IncLevelScore (10);
				pSound . PlaySoundAsync (ShooterSound::EXPLOSION);

				int nSaveHits = (*eit) -> GetHitPoints ();

				// The enemy was shot.  Is he dead?
				if ((*eit) -> Shot ((*bit) -> GetHitPoints ()))
				{
					// If there is an intersection, move the
					//  enemy to the dead enemy list.
					lDeadEnemyList.push_back ((*eit));
					(*eit) -> SetSelfDestruct ();
					eit = lEnemyList.erase (eit);
				}

				// Now pretend the bullet was shot with the enemy.
				if ((*bit) -> Shot (nSaveHits))
				{
					// Remove the bullet.
					delete (*bit);
					bit = lBulletList.erase (bit);
				}

				break;
			}
		}
	}




	// Iterate over all Power Up Objects.
	for (eit = lPowerUpsList.begin(); eit != lPowerUpsList.end();  ++eit)
	{

		// Check for hero vs. Power Up.
		if (CheckIntersection (pHero, *(*eit)))
		{
			((PowerUpsCtrl *) (*eit)) -> HeroPickedUp ();
			return;
		}
	}


	// Iterate over all bullets and see if hit the environment.
	for (bit = lBulletList.begin(); bit != lBulletList.end();  ++bit)
	{
		if (EnvironmentCollision (*(*bit)))
		{
			// Remove the bullet.
			delete (*bit);
			bit = lBulletList.erase (bit);
		}
	}
}


void ShooterWorld::HeroDied (void)
{
	// Hero is dead!
	DecLives ();
	if (GetLives () <= 0)
	{
		// No lives left, end the game.
		eGameState = ShooterWorld::GAME_OVER;
	}
	else
	{
		// More lives left, restart this level.
		fNextStateTime = 0;
		eGameState = ShooterWorld::RESTART_OF_LEVEL;
		pHero.Reset ();	// Set back to normal weapons, full shields, etc.
		SetLevel (GetLevel ());
	}
}







/*
	Coordinate translations and viewport stuff.
*/


BibPoint ShooterWorld::TranslateWorldToScreenCoords (BibPoint & bpWorldCoords)
{
	BibPoint bpView ((int) bpViewCoords.x, (int) bpViewCoords.y);
	return (bpWorldCoords - bpView);
}

BibPoint ShooterWorld::TranslateWorldToRadarCoords (BibPoint & bpWorldCoords)
{
BibPoint bpTempCoords;

	bpTempCoords.x = bpWorldCoords.x * RADAR_SIZE_X / MAP_SIZE_X + RADAR_OFFSET_X;
	bpTempCoords.y = bpWorldCoords.y * RADAR_SIZE_Y / MAP_SIZE_Y + RADAR_OFFSET_Y;

	return (bpTempCoords);
}


bool ShooterWorld::IsInViewPort (BibPoint & bpWorldCoords)
{
//!!! Need a better solution to this fudge factor.
//!!! I Should take into account the size of the bitmap.
	if ((bpWorldCoords.x >= bpViewCoords.x - VIEW_GRAPHICS_FUDGE) &&
		(bpWorldCoords.x < bpViewCoords.x + VIEWPORT_WIDTH) &&
	    (bpWorldCoords.y >= bpViewCoords.y - VIEW_GRAPHICS_FUDGE) &&
		(bpWorldCoords.y < bpViewCoords.y + VIEWPORT_HEIGHT))
	{
		return (true);
	}
	else
	{
		return (false);
	}
}



/*

	Level Loader Routines.

*/

void ShooterWorld::SetHeroLocation (BibPoint & bpLoc)
{
	pHero.SetLocation (bpLoc);
}

void ShooterWorld::CreateDevilEnemy (BibPoint & bpLoc)
{
Enemy1Ctrl * newEnemy;

	newEnemy = new Enemy1Ctrl;
	newEnemy -> Initialize (this);
	newEnemy -> SetLocation (bpLoc);
	lEnemyList . push_back (newEnemy);
}

void ShooterWorld::CreatePokeEnemy (BibPoint & bpLoc)
{
PokeEnemyCtrl * newEnemy;

	newEnemy = new PokeEnemyCtrl;
	newEnemy -> Initialize (this);
	newEnemy -> SetLocation (bpLoc);
	lEnemyList . push_back (newEnemy);
}

void ShooterWorld::CreateSeekerEnemy (BibPoint & bpLoc)
{
SeekerEnemyCtrl * newEnemy;

	newEnemy = new SeekerEnemyCtrl;
	newEnemy -> Initialize (this);
	newEnemy -> SetLocation (bpLoc);
	lEnemyList . push_back (newEnemy);
}

void ShooterWorld::CreateTurretEnemy (BibPoint & bpLoc)
{
TurretEnemyCtrl * newEnemy;

	newEnemy = new TurretEnemyCtrl;
	newEnemy -> Initialize (this);
	newEnemy -> SetLocation (bpLoc);
	lEnemyList . push_back (newEnemy);
}

void ShooterWorld::CreateInanimateObject (BibPoint & bpLoc, InAnimateObjectCtrl::eInAnimType eObType)
{
InAnimateObjectCtrl * newInAOb;

	newInAOb = new InAnimateObjectCtrl;
	newInAOb -> SetObType (eObType);
	newInAOb -> Initialize (this);
	newInAOb -> SetLocation (bpLoc);
	lInAnimList . push_back (newInAOb);
}

void ShooterWorld::SetViewCoords (BibPoint & bpCoords)
{
	//!!! Note there is a loss of precision here,
	//  but as this is only used by the level loader,
	//  it's o.k.
	bpViewCoords = BibPointFP (bpCoords.x, bpCoords.y);
}




/*

	Run-time Object Creation Routines.

*/

void ShooterWorld::CreateEnemyBullet (BibPoint & bpLoc, BibPointFP & bpVelocity)
{
BulletCtrl * newBullet;

		// Create and initialize the bullet.
		newBullet = new (BulletCtrl);
		newBullet->Initialize (this);

		// Set the bullet's location.
		newBullet->SetLocation (bpLoc);

		// Set the velocity of the bullet.
		newBullet->SetVelocity (bpVelocity);

		// Set the velocity of the bullet.
		newBullet->SetFlags (BibControl::IS_ENEMY);

		// Add the bullet to the list.
		lBulletList.push_back (newBullet);
}


void ShooterWorld::CreateHeroBullet (BibPoint & bpLoc, BibPointFP & bpVel, int nFacing, int nType)
{
BulletCtrl * newBullet;

		// Create/initialize a new bullet.
		newBullet = new (BulletCtrl);
		newBullet -> Initialize (this);

		// Set the bullet's location.
		newBullet->SetLocation (bpLoc);

		// Set the velocity of the bullet.
		newBullet->SetVelocity (bpVel);

		// Set the Bullet Graphic
		newBullet->SetDirectionAndType (nFacing, nType);

		// Add the bullet to the list.
		lBulletList.push_back (newBullet);
}

void ShooterWorld::CreatePowerUp (BibPoint & bpLoc)
{
PowerUpsCtrl * newInAOb;

	// If you don't set the object type, it is random.
	newInAOb = new PowerUpsCtrl;
	newInAOb -> Initialize (this);
	newInAOb -> SetLocation (bpLoc);
	lPowerUpsList . push_back (newInAOb);
}


int ShooterWorld::SetLevel (int innLevel) 
{
ShooterLevelLoader LevelLoader;

	nLevel = innLevel;

	if (! LevelLoader . LoadLevel (nLevel, szLevelTitle, this))
	{
		nLevel = 1;
		LevelLoader . LoadLevel (nLevel, szLevelTitle, this);
	}

	return (nLevel);
}


int ShooterWorld::IncLevel (void)
{ 
ShooterLevelLoader LevelLoader;

	nLevel++;

	if (! LevelLoader . LoadLevel (nLevel, szLevelTitle, this))
	{
		// Made it to the last level!
		IncScore (1000);
		nLevel = 1;
		LevelLoader . LoadLevel (nLevel, szLevelTitle, this);
		SetGameState (ShooterWorld::THANK_YOU_EASTER_EGG);
	}

	return (nLevel);
}


void ShooterWorld::DeleteAllObjects (void)
{
EnemyListIteratorType eit;

	lBulletList.clear ();

	// Iterate over all enemies.
	for (eit = lEnemyList.begin(); eit != lEnemyList.end();  ++eit)
	{
		delete ((*eit));
	}
	lEnemyList.clear ();

	// Iterate over all dead enemies.
	for (eit = lDeadEnemyList.begin(); eit != lDeadEnemyList.end();  ++eit)
	{
		delete ((*eit));
	}
	lDeadEnemyList.clear ();

	// Iterate over all inanimate objects.
	for (eit = lInAnimList.begin(); eit != lInAnimList.end();  ++eit)
	{
		delete ((InAnimateObjectCtrl*)(*eit));
	}
	lInAnimList.clear ();

	// Iterate over all PowerUp objects.
	for (eit = lPowerUpsList.begin(); eit != lPowerUpsList.end();  ++eit)
	{
		delete ((PowerUpsCtrl*)(*eit));
	}
	lPowerUpsList.clear ();

}


/*

	Misc. Utility Routines used by Ctrl Objects.

*/

bool ShooterWorld::EnvironmentCollision (BibControl & bcOb1)
{
EnemyListIteratorType eit;

	// Iterate over all InAnimate (Environment) objects..
	for (eit = lInAnimList.begin(); eit != lInAnimList.end();  ++eit)
	{
		if (! ((*eit) -> GetFlags () & BibControl::IS_WALL))
		{
			continue;
		}

		// Check for input object vs. InAnimate.
		if (CheckIntersection (bcOb1, *(*eit)))
		{
			return (true);
		}
	}

	return (false);
}


bool ShooterWorld::FindClosestEnemy (BibPoint & bpMyLocation, BibPoint & bpEnemyLoc)
{
EnemyListIteratorType eit;
BibControl * pMinDistOb;
int nDist, nMinDist;


	// Iterate over all enemies.
	pMinDistOb = NULL;
	for (eit = lEnemyList.begin(); eit != lEnemyList.end();  ++eit)
	{
		// Calculate the distance to each one.
		nDist = CheckIntersection (bpMyLocation, (*eit)->GetLocation());

		// If this is the first one, save it as the minimum.
		// Check to see if we have a new minimum.
		if ((! pMinDistOb) || (nDist < nMinDist))
		{
			pMinDistOb = (*eit);
			nMinDist = nDist;
		}
	}

	if (pMinDistOb)
	{
		bpEnemyLoc = pMinDistOb -> GetLocation ();
		return (true);
	}

	return (false);
}


// Not a deep stack as the name implies.  The code relies on it being a shallow (1) stack.
void ShooterWorld::PushGameState (eGameStateType in_GameState)
{
	eSaveGameState = eGameState;
	eGameState = in_GameState;
}

ShooterWorld::eGameStateType ShooterWorld::PopGameState (void)
{
	eGameState = eSaveGameState;
	return (eGameState);
}
