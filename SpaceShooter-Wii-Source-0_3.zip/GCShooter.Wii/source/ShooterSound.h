/*

	ShooterSound.h

*/


#include "BibLib/BibSound2.h"

class ShooterSound : public BibSound2
{
private:

public:
	ShooterSound ();

	enum eSounds { EXPLOSION, SEEKER_LOCK, TURRET_SHOT, POWER_UP, OUCH, 
					MP3_HILLBILLY_BREAKOUT, MP3_SHAOLIN_TEMPLE, MP3_MADE_IN_PLASTIC,
					MP3_AIMLESS, MP3_GENERIC_FACTOR, MP3_URANIUM_SHARK};

	int PlaySoundAsync (eSounds eThisSound);
	

};
