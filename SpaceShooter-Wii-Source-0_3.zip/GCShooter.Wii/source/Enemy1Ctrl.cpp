/*

	Enemy1 Control Class

*/

#include "GameConstants.h"
#include "Enemy1Ctrl.h"
#include "ShooterWorld.h"

#include "Sprites/DevilEnemySmall.sprite.h"
#include "Sprites/Explosion.sprite.h"

void Enemy1Ctrl::Initialize (class BibWorld * inpWorld)
{
	// Call the base class initialize.
	BibControl::Initialize (inpWorld);

	// Add the sprites.
	basSpriteData . AddFrame (0, 100000, 0, DevilEnemySmall_Bitmap, DEVILENEMYSMALL_WIDTH, DEVILENEMYSMALL_HEIGHT);
	basSpriteData . AddSequence ();
	basSpriteData . AddFrame (1, 30, 1, Explosion_Bitmap, EXPLOSION_WIDTH, EXPLOSION_HEIGHT);
	basSpriteData . AddFrame (1, 100000, 1, NULL, 0, 0);

	bpVel.x = ((rand () % 100) - 50) / 25.0f;
	bpVel.y = ((rand () % 100) - 50) / 25.0f;

	basSpriteData.SetCurSequence (0);
	basSpriteData.SetCurFrame (0);

	bpSize.x = basSpriteData.GetCurSprite () . GetWidth ();
	bpSize.y = basSpriteData.GetCurSprite () . GetHeight ();

	// This is a Enemy1!
	nFlags = IS_ENEMY;
}

void Enemy1Ctrl::UnInitialize ()
{

}



bool Enemy1Ctrl::UpdateMovement (float fSpeedFactor)
{
BibPointFP bpTestLoc;

	// If this was set outside of this function,
	//	then something (e.g. a bullet) wants us dead.
	if (SelfDestruct ())
	{
		ClearSelfDestruct ();
		basSpriteData.SetCurSequence (1);
	}

	// Call the base class to update sprite data, etc.
	if (BibControl::UpdateMovement (fSpeedFactor))
	{
		return (true);
	}

	// If we are in the exploding state, don't move.
	if (basSpriteData.GetCurSequence () == 1)
	{
		if (basSpriteData.GetCurFrame () == 1)
		{
			// We are done exploding, self destruct object.
			SetSelfDestruct ();
		}
		return (false);
	}

	bpTestLoc = bpInternalLoc + bpVel * fSpeedFactor;

	if ((bpTestLoc.x < 0) || (bpTestLoc.x > MAP_SIZE_X - bpSize.x))
	{
		bpVel.x *= -1;
	}
	if ((bpTestLoc.y < 0) || (bpTestLoc.y > MAP_SIZE_Y - bpSize.y))
	{
		bpVel.y *= -1;
	}

	bpInternalLoc = bpInternalLoc + bpVel * fSpeedFactor;

	// Set location for external access.
	bpMyLocation.x = (int) bpInternalLoc.x;
	bpMyLocation.y = (int) bpInternalLoc.y;


	return (false);
}



void Enemy1Ctrl::SetLocation (BibPoint & inbpLoc)
{
	BibControl::SetLocation (inbpLoc);
	bpInternalLoc.x = inbpLoc.x;
	bpInternalLoc.y = inbpLoc.y;
}
