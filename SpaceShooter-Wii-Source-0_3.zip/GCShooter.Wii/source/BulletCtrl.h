/*

	BulletControl Class

*/

#pragma once

#include "BibLib/BibCtrl.h"
#include "BibLib/BibPointFP.h"


/*
//!!! Facing and Type should be enums.
//!!! These match up with the sequence numbers.

  Type:0 = Normal hero bullet.
  Type:2 = Multi-Slow hero bullet.
  Type:3 = Big Bomb hero bullet.


*/

class BulletCtrl : public BibControl
{
private:
	BibPointFP bpVel;
	BibPointFP bpInternalLoc;

	class ShooterWorld * pWorld;
public:

	void Initialize (class BibWorld * pWorld);
	void UnInitialize ();

	// This is called very often to have the object move, etc.
	bool UpdateMovement (float fSpeedFactor);

	void SetLocation (BibPoint & inbpLoc);
	void SetVelocity (BibPointFP & bpVel);

	bool Shot (int nHits);
	void SetFlags (ePieceFlags eFlags);
	void SetDirectionAndType (int nFacing, int nType);

};
