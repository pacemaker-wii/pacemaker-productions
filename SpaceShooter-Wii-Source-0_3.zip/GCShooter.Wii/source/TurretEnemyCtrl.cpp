/*

	TurretEnemy Control Class

*/

#include <math.h>

#include "GameConstants.h"
#include "TurretEnemyCtrl.h"
#include "ShooterWorld.h"

#include "Sprites/Explosion.sprite.h"
#include "Sprites/TurretEnemy.sprite.h"


void TurretEnemyCtrl::Initialize (class BibWorld * inpWorld)
{
	// Call the base class initialize.
	BibControl::Initialize (inpWorld);

	pWorld = (ShooterWorld *) inpWorld;

	// Add the sprites.
	basSpriteData . AddFrame (0, 100000, 0, TurretEnemy_Bitmap, TURRETENEMY_WIDTH, TURRETENEMY_HEIGHT);
	basSpriteData . AddSequence ();
	basSpriteData . AddFrame (1, 30, 1, Explosion_Bitmap, EXPLOSION_WIDTH, EXPLOSION_HEIGHT);
	basSpriteData . AddFrame (1, 100000, 1, NULL, 0, 0);

	basSpriteData.SetCurSequence (0);
	basSpriteData.SetCurFrame (0);

	bpSize.x = basSpriteData.GetCurSprite () . GetWidth ();
	bpSize.y = basSpriteData.GetCurSprite () . GetHeight ();

	// This is a TurretEnemy!
	nFlags = IS_ENEMY;

	fTurretShotTimer = 0;
	nHitPoints = 5 + rand () % 10;
}

void TurretEnemyCtrl::UnInitialize ()
{

}



bool TurretEnemyCtrl::UpdateMovement (float fSpeedFactor)
{
BibPoint bpHeroLoc;
BibPoint bpTurLoc;

	// If this was set outside of this function,
	//	then something (e.g. a bullet) wants us dead.
	if (SelfDestruct ())
	{
		ClearSelfDestruct ();
		basSpriteData.SetCurSequence (1);
	}

	// Call the base class to update sprite data, etc.
	if (BibControl::UpdateMovement (fSpeedFactor))
	{
		return (true);
	}

	// If we are in the exploding state, don't move.
	if (basSpriteData.GetCurSequence () == 1)
	{
		if (basSpriteData.GetCurFrame () == 1)
		{
			// We are done exploding, self destruct object.
			SetSelfDestruct ();

			// Create the powerup after the explosion.
			pWorld -> CreatePowerUp (bpMyLocation);
		}
		return (false);
	}


	/*
		Calculate the next position.
	*/

	fTurretShotTimer += fSpeedFactor;

	if (fTurretShotTimer < TURRET_SHOT_TIME)
		return (false);

	// If we aren't on the screen, don't move.
	if (! pWorld ->IsInViewPort (bpMyLocation))
	{
		return (false);
	}

	// Reset shot timer.
	fTurretShotTimer = 0;

	// Play the shooting sound.
	pWorld -> pSound . PlaySoundAsync (ShooterSound::TURRET_SHOT);

	// Create the bullet.
	bpHeroLoc = pWorld -> GetHeroCtrl () . GetLocation ();

	// Calculate the movement vector.
	bpVel.x = bpHeroLoc.x - bpMyLocation.x;
	bpVel.y = bpHeroLoc.y - bpMyLocation.y;

	// Normalize and set to the correct velocity.
	bpVel.Normalize ();
	bpVel = bpVel * TURRET_BULLET_VELOCITY;

	bpTurLoc.x = bpMyLocation.x + (int) bpVel.x;
	bpTurLoc.y = bpMyLocation.y + (int) bpVel.y;

	pWorld -> CreateEnemyBullet (bpMyLocation, bpVel);


	return (false);
}



void TurretEnemyCtrl::SetLocation (BibPoint & inbpLoc)
{
	BibControl::SetLocation (inbpLoc);
	bpInternalLoc.x = inbpLoc.x;
	bpInternalLoc.y = inbpLoc.y;
}

bool TurretEnemyCtrl::Shot (int nHits)
{
	// We are shot.
	nHitPoints -= nHits;

	if (nHitPoints <= 0)
	{
		// We are dead.
		return (true);
	}
	else
	{
		// We are not dead yet.
		return (false);
	}
}

