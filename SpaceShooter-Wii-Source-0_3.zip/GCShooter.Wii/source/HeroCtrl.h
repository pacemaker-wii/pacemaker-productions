/*

	HeroControl Class

*/

#pragma once

#include "BibLib/BibCtrl.h"
#include "BibLib/BibPointFP.h"


class HeroCtrl : public BibControl
{
public:
	enum eWeaponsSystemType { NORMAL=1, SLOW_MULTI=2, BIG_BOMB=4, SEEKER=8 };

private:
	BibPointFP bpVel;
	BibPointFP bpInternalLoc;

	class ShooterWorld * pWorld;
	float fBulletTime;		// Current counter between bullets.
	float fMinBulletTime;	// Minimum Time between bullets.

	int WiiFireAction;
	int WiiTurnAction;
	int WiiMoveUpAction;
	int WiiMoveDownAction;
	int WiiMoveLeftAction;
	int WiiMoveRightAction;
	
	int nHitCounter;		// For timing the rumble after a direct hit.

	int WeaponsSystems;		// This is a bitmask now to allow multiple types at once.

	// These are assumed to be the same constants as the sprite sequences
	enum eFacingDirection { DIR_UP = 0, DIR_RIGHT, DIR_DOWN, DIR_LEFT, DIR_END};
	eFacingDirection eFacing;

	void CheckForFiring (float fSpeedFactor);

	// Bullet Creation Routines
	void CreateNormalBullet (void);
	void CreateSlowMultiBullet (void);
	void CreateSeekerBullet (void);
	void CreateBigBombBullet (void);

	// Hints to the bullet when it's created.
	BibPoint GetBulletStart (eFacingDirection ineFacing);
	BibPoint GetBigBombBulletStart (eFacingDirection ineFacing);
	BibPointFP GetBulletVelocity (eFacingDirection ineFacing);

public:
	HeroCtrl ();
	~HeroCtrl ();


	void Initialize (class BibWorld * pWorld);
	void Reset (void);
	void UnInitialize ();

	// This is called very often to have the object move, etc.
	bool UpdateMovement (float fSpeedFactor);

	void SetLocation (BibPoint & inbpLoc);

	// I'm shot, am I dead?
	bool Shot (int nHits);

	void Turn (void);

	void SetWeaponsSystem (eWeaponsSystemType ineWeaponsSystem);
	void AddWeaponsSystem (eWeaponsSystemType ineWeaponsSystem);

};
