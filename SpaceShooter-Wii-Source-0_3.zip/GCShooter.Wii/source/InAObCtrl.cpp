/*

	InAnimateObject Control Class

*/


#include "GameConstants.h"
#include "InAObCtrl.h"
#include "ShooterWorld.h"

#include "Sprites/Moon.sprite.h"
#include "Sprites/Rock.sprite.h"
#include "Sprites/Rock2.sprite.h"
#include "Sprites/Rock3.sprite.h"
#include "Sprites/Rock4.sprite.h"
#include "Sprites/Rock5.sprite.h"
#include "Sprites/Rock6.sprite.h"
#include "Sprites/Rock7.sprite.h"
#include "Sprites/Rock8.sprite.h"
#include "Sprites/BlackHole.sprite.h"
#include "Sprites/Star.sprite.h"
#include "Sprites/PointStar.sprite.h"
#include "Sprites/RedGalaxy.sprite.h"
#include "Sprites/Earth1.sprite.h"



void InAnimateObjectCtrl::Initialize (class BibWorld * inpWorld)
{
	// Call the base class initialize.
	BibControl::Initialize (inpWorld);

	// Add the sprites.
	switch (eObType)
	{
		default:
		case MOON:
			basSpriteData . AddFrame (0, 100000, 0, Moon_Bitmap, MOON_WIDTH, MOON_HEIGHT);
			basSpriteData.SetCurSequence (0);
			basSpriteData.SetCurFrame (0);

			nFlags = IS_WALL;
		break;

		case ROCK:
			basSpriteData . AddFrame (0, 12, 1, Rock_Bitmap, ROCK_WIDTH, ROCK_HEIGHT);
			basSpriteData . AddFrame (0, 12, 2, Rock2_Bitmap, ROCK2_WIDTH, ROCK2_HEIGHT);
			basSpriteData . AddFrame (0, 12, 3, Rock3_Bitmap, ROCK3_WIDTH, ROCK3_HEIGHT);
			basSpriteData . AddFrame (0, 12, 4, Rock4_Bitmap, ROCK4_WIDTH, ROCK4_HEIGHT);
			basSpriteData . AddFrame (0, 12, 5, Rock5_Bitmap, ROCK5_WIDTH, ROCK5_HEIGHT);
			basSpriteData . AddFrame (0, 12, 6, Rock6_Bitmap, ROCK6_WIDTH, ROCK6_HEIGHT);
			basSpriteData . AddFrame (0, 12, 7, Rock7_Bitmap, ROCK7_WIDTH, ROCK7_HEIGHT);
			basSpriteData . AddFrame (0, 12, 0, Rock8_Bitmap, ROCK8_WIDTH, ROCK8_HEIGHT);
			basSpriteData.SetCurSequence (0);
			basSpriteData.SetCurFrame (rand () % 8);
			basSpriteData.IncFrameTime (rand () % 12);

			nFlags = IS_WALL;
		break;

		case BLACK_HOLE:
			basSpriteData . AddFrame (0, 100000, 0, BlackHole_Bitmap, BLACKHOLE_WIDTH, BLACKHOLE_HEIGHT);
			basSpriteData.SetCurSequence (0);
			basSpriteData.SetCurFrame (0);
		break;

		case STAR:
			basSpriteData . AddFrame (0, 100000, 0, Star_Bitmap, STAR_WIDTH, STAR_HEIGHT);
			basSpriteData.SetCurSequence (0);
			basSpriteData.SetCurFrame (0);
			nFlags = IS_WALL;
		break;

		case POINT_STAR:
			basSpriteData . AddFrame (0, 100000, 0, PointStar_Bitmap, POINTSTAR_WIDTH, POINTSTAR_HEIGHT);
			basSpriteData.SetCurSequence (0);
			basSpriteData.SetCurFrame (0);
		break;

		case RED_GALAXY:
			basSpriteData . AddFrame (0, 100000, 0, RedGalaxy_Bitmap, REDGALAXY_WIDTH, REDGALAXY_HEIGHT);
			basSpriteData.SetCurSequence (0);
			basSpriteData.SetCurFrame (0);
			nFlags = IS_WALL;
		break;

		case EARTH:
			basSpriteData . AddFrame (0, 100000, 0, Earth1_Bitmap, EARTH1_WIDTH, EARTH1_HEIGHT);
			basSpriteData.SetCurSequence (0);
			basSpriteData.SetCurFrame (0);

			nFlags = IS_WALL;
		break;
	}

	bpSize.x = basSpriteData.GetCurSprite () . GetWidth ();
	bpSize.y = basSpriteData.GetCurSprite () . GetHeight ();

}

void InAnimateObjectCtrl::UnInitialize ()
{

}



bool InAnimateObjectCtrl::UpdateMovement (float fSpeedFactor)
{

	// Call the base class to update sprite data, etc.
	if (BibControl::UpdateMovement (fSpeedFactor))
	{
		return (true);
	}

	return (false);
}


bool InAnimateObjectCtrl::OnRadar (void)
{
	if (eObType == POINT_STAR)
		return (false);
	return (true);
}
