// ShooterWorld.h: interface for the ShooterWorld class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <list>
#include "BibLib/BibWorld.h"
#include "GameConstants.h"
#include "BibLib/BibCtrl.h"
#include "BibLib/BibWiiInputDevice.h"

#include "HeroCtrl.h"
#include "BulletCtrl.h"
#include "InAObCtrl.h"
#include "ShooterSound.h"
#include "ShooterMainMenu.h"



class ShooterWorld : public BibWorld
{
public:	
	enum eGameStateType { SPLASH_SCREEN, PLAYING, END_OF_LEVEL, START_OF_LEVEL, 
						  RESTART_OF_LEVEL, GAME_OVER, MAIN_MENU,
						  THANK_YOU_EASTER_EGG, SPLASH_SCREEN_1_WARN,
						  SPLASH_SCREEN_2_SIDEWAYS,
						  SPLASH_SCREEN_PACEMAKER
						};

	BibWiiInputDevice WiiInputDevice;

	MainMenu	TheMainMenu;
	bool bDebugOn;

	// Sounds object
	ShooterSound pSound;

	typedef std::list<BibControl *> CtrlObListType;
	typedef std::list<BibControl *>::iterator CtrlObListIteratorType;

	typedef CtrlObListType BulletListType;
	typedef CtrlObListIteratorType BulletListIteratorType;

	typedef CtrlObListType EnemyListType;
	typedef CtrlObListIteratorType EnemyListIteratorType;

private:
	HeroCtrl pHero;
	BibSprite bsHeroRadarPic;

	int nGameOverCounter;

	// From WiiInputDevice ActionMap
	//   To skip splash screen.
	int WiiSplashScreenAction;
	//   For Debug Button.
	int WiiButtonMinusAction;
	int WiiButtonPlusAction;
	

	/*
		The bullet list contains all bullets.  
		It has friendly and enemy bullets.
		Bullets can have sprite animations.
		Bullets can be destroyed.
		Bullets are checked for collisions.
	*/
	BulletListType lBulletList;
	float BulletTime;

	/*
		Enemies are checked for collisions.
		Enemies can have sprite animation.
		Enemies can be destroyed.
	*/
	EnemyListType lEnemyList;
	BibSprite bsEnemyRadarPic;

	/*
		When an enemy dies, he goes onto the dead enemy list.
		This is a way to let the enemy explosions not interact 
			with the other objects.
		DeadEnemies are not checked for collisions.
		DeadEnemies can have sprite animations.
		DeadEnemies can be destroyed (by themselves).
	*/
	EnemyListType lDeadEnemyList;

	/*
		InAnimates are objects that are not checked for collisions.
		They can not have sprite animation.
		They can not be destroyed.
	*/
	EnemyListType lInAnimList;
	BibSprite bsInAnimRadarPic;

	/*
		Powerups are objects that are only checked for collisions with the hero.
		They can have sprite animation.
		They can be destroyed.
	*/
	EnemyListType lPowerUpsList;




	void CheckForCollisions (void);
	void CheckForScroll (float fSpeedFactor);
	void UpdateObjectLists (float fSpeedFactor);
	void HeroDied (void);

	eGameStateType eGameState;
	eGameStateType eSaveGameState;
	float fNextStateTime;

	BibPointFP bpViewCoords;		// Upper left coord of view.

	void Reset (void);

	const char * szWorldMsg;

public:
	ShooterWorld();
	virtual ~ShooterWorld();

	void Initialize (GXRModeObj * vMode);
	void UnInitialize (void);

	void UpdateMovement (float fSpeedFactor);

	bool IsDebugOn() { return (bDebugOn); }

	// Game State methods.
	eGameStateType GetGameState (void) { return (eGameState); }
	void SetGameState (eGameStateType ineGameState) { eGameState = ineGameState; }
	void PushGameState (eGameStateType GameState);
	eGameStateType PopGameState (void);
	
	HeroCtrl & GetHeroCtrl (void) { return (pHero); }
	BulletListType * GetBulletList (void) { return (& lBulletList); }
	EnemyListType * GetEnemyList (void) { return (& lEnemyList); }
	EnemyListType * GetDeadEnemyList (void) { return (& lDeadEnemyList); }
	EnemyListType * GetInAnimatesList (void) { return (& lInAnimList); }
	EnemyListType * GetPowerUpsList (void) { return (& lPowerUpsList); }
	BibPoint TranslateWorldToScreenCoords (BibPoint & bpWorldCoords);
	BibPoint TranslateWorldToRadarCoords (BibPoint & bpWorldCoords);
	bool IsInViewPort (BibPoint & bpWorldCoords);

	// Level methods.
	int SetLevel (int innLevel);
	int IncLevel (void);

	// Radar Sprite accessor methods.
	BibSprite & GetEnemyRadarSprite (void) { return bsEnemyRadarPic; }
	BibSprite & GetHeroRadarSprite (void) { return bsHeroRadarPic; }
	BibSprite & GetInAnimRadarSprite (void) { return bsInAnimRadarPic; }

	bool EnvironmentCollision (BibControl & bcOb1);
	bool FindClosestEnemy (BibPoint & bpMyLocation, BibPoint & bpEnemyLoc);


	const char * GetWorldMsg (void) { return szWorldMsg; }


public:
	//	Level loading functions:

	void DeleteAllObjects (void);
	void SetHeroLocation (BibPoint & bpLoc);
	void CreateDevilEnemy (BibPoint & bpLoc);
	void CreatePokeEnemy (BibPoint & bpLoc);
	void CreateSeekerEnemy (BibPoint & bpLoc);
	void CreateTurretEnemy (BibPoint & bpLoc);
	void CreateInanimateObject (BibPoint & bpLoc, InAnimateObjectCtrl::eInAnimType eObType);
	void SetViewCoords (BibPoint & bpCoords);

	void CreateEnemyBullet (BibPoint & bpLoc, BibPointFP & bpVelocity);
	void CreateHeroBullet (BibPoint & bpLoc, BibPointFP & bpVelocity, int nFacing, int nType);
	void CreatePowerUp (BibPoint & bpLoc);

#ifdef SHOW_OVERSCAN_BOX
	BibSprite bsOverscanBox;
#endif


};
