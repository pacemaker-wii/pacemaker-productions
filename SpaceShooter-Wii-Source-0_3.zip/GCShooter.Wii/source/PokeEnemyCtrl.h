/*

	PokeEnemyControl Class

*/

#include "BibLib/BibCtrl.h"
#include "BibLib/BibPointFP.h"


class PokeEnemyCtrl : public BibControl
{
private:
	BibPointFP bpVel;
	BibPointFP bpInternalLoc;

	BibPointFP bpCenter;
	float	fRadius;
	float	fMoveTimer;
	bool	bDirection;

public:
	void Initialize (class BibWorld * pWorld);
	void UnInitialize ();

	// This is called very often to have the object move, etc.
	bool UpdateMovement (float fSpeedFactor);

	void SetLocation (BibPoint & inbpLoc);

	bool Shot (int nHits) { return (true); }
};
