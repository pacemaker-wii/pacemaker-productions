
// Shooter Main Menu


#include "ShooterWorld.h"
//#include "ShooterMainMenu.h"


// Menu data for Main Menu.
enum { MENU_TOGGLE_DEBUG_MSGS = 0, MENU_JUMP_LEVEL, MENU_CHANGE_CTRLS, MENU_QUIT_GAME, MENU_RETURN_TO_LOADER, MENU_BACK };
static const char * szMainMenuItems  [] = {"Toggle Debug Messages", 
#ifdef PRODUCTION
	"-----",
#else
	"Jump to Next Level", 
#endif
									"Change Controls", "Quit Game", "Return to Loader", "Back"};


// Menu data for controls.
enum { MENU_WII_REMOTE = 0, MENUC_WII_REMOTE_TILT, MENUC_NUNCHUK, MENUC_GAMECUBE, MENUC_BACK };
static const char * szControlMenuItems  [] = {"  Wii Remote (btns)", "  Wii Remote (tilt)", "  Nunchuk", "  GameCube", "  Back"};


static BibWiiInputDevice::SingleAction saMainMenuAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_HOME},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_HOME},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_HOME},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_HOME}
																};
static BibWiiInputDevice::SingleAction saMainMenuUpAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_RIGHT},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_RIGHT},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_UP},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_RIGHT}
																};
static BibWiiInputDevice::SingleAction saMainMenuDownAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_LEFT},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_LEFT},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_DOWN},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_LEFT}
																};
static BibWiiInputDevice::SingleAction saMainMenuSelectAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2}
																};
static BibWiiInputDevice::SingleAction saMainMenuBackAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_1},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_1},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_B},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_1}
																};

void MainMenu::Initialize (ShooterWorld * _pWorld)
{
	pWorld = _pWorld;

	eMenuState = MENU_STATE_MAIN;

	WiiMainMenuAction= pWorld->WiiInputDevice.DefineAction (saMainMenuAction);
	WiiMainMenuUpAction= pWorld->WiiInputDevice.DefineAction (saMainMenuUpAction);
	WiiMainMenuDownAction= pWorld->WiiInputDevice.DefineAction (saMainMenuDownAction);
	WiiMainMenuSelectAction= pWorld->WiiInputDevice.DefineAction (saMainMenuSelectAction);
	WiiMainMenuBackAction= pWorld->WiiInputDevice.DefineAction (saMainMenuBackAction);
}


/*
	This is called every game loop.
*/
bool MainMenu::UpdateMovement (void)
{
ShooterWorld::eGameStateType eGameState;

	eGameState = pWorld->GetGameState ();

	
	if (eGameState == ShooterWorld::MAIN_MENU)
	{

		if (eMenuState ==  MENU_STATE_MAIN)
		{
			DoMainMenu ();
			return (true);
		}
		else if (eMenuState == MENU_STATE_CONTROLS)
		{
			DoControlMenu ();
			return (true);
		}

		return (false);
	}
	else if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuAction))
	{
		if (eGameState != ShooterWorld::MAIN_MENU)
		{
			pWorld->pSound . PlaySoundAsync (ShooterSound::EXPLOSION);
			bmMainMenu.Initialize ();
			bmMainMenu.SetupListBox("Main Menu", szMainMenuItems, sizeof (szMainMenuItems) / sizeof (char *));
			pWorld->PushGameState (ShooterWorld::MAIN_MENU);
		}
		return (true);
	}


	return (false);
}


void MainMenu::DoMainMenu (void)
{
int nMenuChoice;

	if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuDownAction))
	{
		pWorld->pSound . PlaySoundAsync (ShooterSound::SEEKER_LOCK);
		bmMainMenu.ProcessInput(BibMenus::INPUT_DOWN);
	}
	else if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuUpAction))
	{
		pWorld->pSound . PlaySoundAsync (ShooterSound::SEEKER_LOCK);
		bmMainMenu.ProcessInput(BibMenus::INPUT_UP);
	}
	else if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuSelectAction))
	{
		pWorld->pSound . PlaySoundAsync (ShooterSound::EXPLOSION);
		nMenuChoice = bmMainMenu.ProcessInput(BibMenus::INPUT_SELECT);
		if (nMenuChoice >= 0)
		{
			if (nMenuChoice == MENU_TOGGLE_DEBUG_MSGS)	// Toggle Debug Info.
			{
				if (pWorld->bDebugOn)
					pWorld->bDebugOn = FALSE;
				else
					pWorld->bDebugOn = TRUE;
				pWorld->PopGameState ();
			}
			else if (nMenuChoice == MENU_JUMP_LEVEL)	// Jump to next level.
			{
#ifndef PRODUCTION				
				pWorld->IncLevel ();
				pWorld->PopGameState ();
#endif
			}
			else if (nMenuChoice == MENU_CHANGE_CTRLS)	// Submenu for changing control scheme
			{
				eMenuState = MENU_STATE_CONTROLS;
				bmMainMenu.Initialize ();
				// Mark which one we think is active.
				MarkActiveControlOption ();
				bmMainMenu.SetupListBox("Control Options", szControlMenuItems, sizeof (szControlMenuItems) / sizeof (char *));
				return;
			}
			else if (nMenuChoice == MENU_QUIT_GAME)	// Quit Game
			{
				pWorld->SetGameState (ShooterWorld::GAME_OVER);
			}
			else if (nMenuChoice == MENU_RETURN_TO_LOADER)	// Return to Loader
			{
				exit (0);
			}
			else if (nMenuChoice == MENU_BACK)	// Back
			{
				// Don't do anything, just exit the menu.
				pWorld->PopGameState ();
			}
			pWorld-> GetView () -> fps . ReInit ();
		}
		
	}
	else if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuBackAction))
	{
		pWorld->pSound . PlaySoundAsync (ShooterSound::EXPLOSION);
		if (bmMainMenu.ProcessInput(BibMenus::INPUT_BACK) == -2)
		{
			pWorld->PopGameState ();
		}
	}
}

void MainMenu::MarkActiveControlOption (void)
{
	// Mark which one we think is active.
	for (int i = 0; i < (int) (sizeof (szControlMenuItems) / sizeof (char *)); i ++)
	{
		if (i == pWorld->WiiInputDevice.GetCurActionSet ())
			((char *) szControlMenuItems [i]) [0] = '*';
		else
			((char *) szControlMenuItems [i]) [0] = ' ';
	}
}

void MainMenu::DoControlMenu (void)
{
int nMenuChoice;

	if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuDownAction))
	{
		pWorld->pSound . PlaySoundAsync (ShooterSound::SEEKER_LOCK);
		bmMainMenu.ProcessInput(BibMenus::INPUT_DOWN);
	}
	else if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuUpAction))
	{
		pWorld->pSound . PlaySoundAsync (ShooterSound::SEEKER_LOCK);
		bmMainMenu.ProcessInput(BibMenus::INPUT_UP);
	}
	else if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuSelectAction))
	{
		pWorld->pSound . PlaySoundAsync (ShooterSound::EXPLOSION);
		nMenuChoice = bmMainMenu.ProcessInput(BibMenus::INPUT_SELECT);
		if (nMenuChoice >= 0)
		{
			switch (nMenuChoice)
			{
				case MENU_WII_REMOTE:
					pWorld->WiiInputDevice.SetCurActionSet (0);
				break;
				case MENUC_WII_REMOTE_TILT:
					pWorld->WiiInputDevice.SetCurActionSet (1);
				break;
				case MENUC_NUNCHUK:
					pWorld->WiiInputDevice.SetCurActionSet (2);
				break;
				case MENUC_GAMECUBE:
					pWorld->WiiInputDevice.SetCurActionSet (3);
				break;
				
				case MENUC_BACK:
				default:
					eMenuState = MENU_STATE_MAIN;
					bmMainMenu.Initialize ();
					bmMainMenu.SetupListBox("Main Menu", szMainMenuItems, sizeof (szMainMenuItems) / sizeof (char *));
				break;
			}
			
			MarkActiveControlOption ();
		}
		
	}
	else if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuBackAction))
	{
		pWorld->pSound . PlaySoundAsync (ShooterSound::EXPLOSION);
		if (bmMainMenu.ProcessInput(BibMenus::INPUT_BACK) == -2)
		{
			eMenuState = MENU_STATE_MAIN;
			bmMainMenu.Initialize ();
			bmMainMenu.SetupListBox("Main Menu", szMainMenuItems, sizeof (szMainMenuItems) / sizeof (char *));
		}
	}

	return;
}
