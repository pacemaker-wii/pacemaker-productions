// BibView.h: interface for the BibView class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _BIBVIEW_H_
#define _BIBVIEW_H_

#include "BibGraphicsDevice.h"
#include "BibPoint.h"
#include "BibFrameRate.h"
#include "BibScreenFont.h"




class BibView  
{
protected:
	BibScreenFont ScreenFont;

	class BibWorld * pWorld;

public:
	BibFrameRate fps;

public:
	BibView();
	virtual ~BibView();

	void SetWorld (BibWorld * pinWorld);
	void Render (BibGraphicsDevice & GD);


	void TranslateBoardXYToScreenXY (BibPoint bpBoardLoc, BibPoint & bpScreenLoc);
	bool TranslateMouseXYToBoardXY (BibPoint bpMouseLoc, BibPoint & bpBoardLoc);

};

#endif
