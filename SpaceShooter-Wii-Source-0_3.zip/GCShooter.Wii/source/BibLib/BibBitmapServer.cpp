/*

	BibBitmapServer


	This class holds all of the bitmap information.

	It keeps a list of BibSprite objects, and makes duplicates as
	necessary so we don't reload the same graphics all of the time.
	
	
	//!!! Since I'm not loaded sprites from secondary storage (e.g. Disk)
	//    this class isn't useful right now.
	//    The purpose was to save memory if a sprite is needed to be used twice.
	//    I'm not sure this is required because of the way I'm storing the files in memory.
*/

#include "BibBitmapServer.h"


BibSprite * BibBitmapServer::LoadBitmap (const u32 * pBMData, int nWidth, int nHeight)
{
#if 0
BibSprite * p, * pNew;

	// If the entry doesn't exist, it will create one with
	//  the value of NULL
	p = sBitmapList [insFileName];
	if (p)
	{
		// It already exists, copy it, then return the copy.
		pNew = new BibSprite (*p);
		return (pNew);
	}

	// It doesn't exist.  Load it.
	p = new (BibSprite);
	p->LoadBitmap (insFileName);

	// Save it in the list.
	sBitmapList [insFileName] = p;

	// Then return a copy.
	pNew = new BibSprite (*p);
	return (pNew);
#endif

BibSprite * pNew;

	// Then return a copy.
	pNew = new BibSprite ();
	pNew->LoadBitmap (pBMData, nWidth, nHeight);
	return (pNew);
}


void BibBitmapServer::UnLoadBitmap (BibSprite * pSprite)
{
	// Could do some fancy reference counting stuff here.
	delete (pSprite);
}


