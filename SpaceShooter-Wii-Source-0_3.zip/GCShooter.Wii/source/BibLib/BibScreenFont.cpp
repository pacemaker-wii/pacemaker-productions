/*

	BibScreenFont.h

*/

#include "BibScreenFont.h"


void BibScreenFont::Initialize (const u32 * pBMData, int nWidth, int nHeight, int innXLetterWidth, int innYLetterHeight, 
								int * innCharWidths, int innCharsPerLine)
{
	AlphabetBitmap.LoadBitmap (pBMData, nWidth, nHeight);
	nXLetterWidth = innXLetterWidth;
	nYLetterHeight = innYLetterHeight;
	nCharWidths = innCharWidths;
	nCharsPerLine = innCharsPerLine;
}


void BibScreenFont::DisplayText (BibGraphicsDevice & GD, int nXScreenLoc, int nYScreenLoc, const char * szText)
{
char cChar;
int i;
int nXBitOffset, nYBitOffset;
BibPoint bpScreen, bpTopLeft, bpSrcSize;

	// Loop for every character.
	for (i = 0; szText [i]; i++)
	{
		cChar = szText [i];
		if (cChar > 128)
			cChar &= 0xEF;


		// Compute the offset.
		nXBitOffset = (cChar % nCharsPerLine) * nXLetterWidth;
		nYBitOffset = (cChar / nCharsPerLine) * nYLetterHeight;

		// Render each letter.
		bpScreen = BibPoint (nXScreenLoc, nYScreenLoc);
		bpTopLeft = BibPoint (nXBitOffset, nYBitOffset);
		bpSrcSize = BibPoint (nXLetterWidth - CHAR_PIXEL_MARGIN, nYLetterHeight - CHAR_PIXEL_MARGIN);
		GD.RenderBitmap (AlphabetBitmap, bpScreen, bpTopLeft, bpSrcSize);

		// Every time we blit a letter we need to move to the right 
		// for the start of the next blit
		nXScreenLoc += nCharWidths [cChar];
	}

}


