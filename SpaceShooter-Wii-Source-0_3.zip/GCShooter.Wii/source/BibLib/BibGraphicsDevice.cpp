// GraphicsDevice.cpp

#include <gccore.h>
#include <ogcsys.h>


#include "BibGraphicsDevice.h"

// This is two pixels of pink RGB(255, 0, 255)
#define TRANSPARENT_COLOR 0x69D469EA

//!!!! There are too many hard coded numbers in here.  320x480...is that always correct?

BibGraphicsDevice::BibGraphicsDevice ()
{
	whichfb = 0;
	xfb[0] = NULL;
	xfb[1] = NULL;
	nFBSize = 0;
	nError = 0;
	nBadX = 0;
	nBadY = 0;

}

BibGraphicsDevice::~BibGraphicsDevice ()
{
}


/****************************************************************************
* CvtRGB
*
* This function simply returns two RGB pixels as one Y1CbY2Cr.
*****************************************************************************/
u32 BibGraphicsDevice::RGBtoGC (u8 r1, u8 g1, u8 b1, u8 r2, u8 g2, u8 b2)
{
  int y1, cb1, cr1, y2, cb2, cr2, cb, cr;

  y1 = (299 * r1 + 587 * g1 + 114 * b1) / 1000;
  cb1 = (-16874 * r1 - 33126 * g1 + 50000 * b1 + 12800000) / 100000;
  cr1 = (50000 * r1 - 41869 * g1 - 8131 * b1 + 12800000) / 100000;

  y2 = (299 * r2 + 587 * g2 + 114 * b2) / 1000;
  cb2 = (-16874 * r2 - 33126 * g2 + 50000 * b2 + 12800000) / 100000;
  cr2 = (50000 * r2 - 41869 * g2 - 8131 * b2 + 12800000) / 100000;

  cb = (cb1 + cb2) >> 1;
  cr = (cr1 + cr2) >> 1;

  return (y1 << 24) | (cb << 16) | (y2 << 8) | cr;
}

// y is normal y.
// x is (x >> 1) since data is 32 bit words equal to two pixels
int BibGraphicsDevice::fb (int x, int y, int d)
{
unsigned int v;

	if ((x < 0) || (x > 320) ||
		(y < 0) || (y > 480))
	{
		nBadX = x;
		nBadY = y;
		nError++;
		return (0);
	}

	// Calculate index into linear frame buffer.
	v = (y * 320) + x ;

	if ((v < 0) || (v >= nFBSize))
	{
		nBadX = x;
		nBadY = y;
		nError++;
		return (0);
	}

	fb() [v] = d;
	return (1);
}


/****************************************************************************
* Initialize Video
*
****************************************************************************/
void BibGraphicsDevice::Initialize (void)
{
  VIDEO_Init ();		/*** ALWAYS CALL FIRST IN ANY LIBOGC PROJECT!
							Not only does it initialise the video 
							subsystem, but also sets up the ogc os
						***/

	/*** 
		Detect the current preferred video mode.
	***/
	vmode = VIDEO_GetPreferredMode(NULL);
   
	/*** Let libogc configure the mode ***/
	VIDEO_Configure (vmode);

	/*** Now configure the framebuffer. 
	     Really a framebuffer is just a chunk of memory
	     to hold the display line by line.
	***/
	xfb[0] = (u32 *) MEM_K0_TO_K1 (SYS_AllocateFramebuffer (vmode));

	/*** I prefer also to have a second buffer for double-buffering.
	     This is not needed for the console demo.
	***/
	xfb[1] = (u32 *) MEM_K0_TO_K1 (SYS_AllocateFramebuffer (vmode));

	// The framebuffer appears to be allocated to 720x480, but I'm assuming 640x480 is visible/usable.
	//nFBSize = 720 * 480 * 2 / 4;
	nFBSize = 640 * 480 * 2 / 4;

	/*** Define a console ***/
	console_init (xfb[0], 20, 64, vmode->fbWidth, vmode->xfbHeight, vmode->fbWidth * 2);

	/*** Clear framebuffer to black ***/
	VIDEO_ClearFrameBuffer (vmode, xfb[0], COLOR_BLACK);
	VIDEO_ClearFrameBuffer (vmode, xfb[1], COLOR_BLACK);

	/*** Set the framebuffer to be displayed at next VBlank ***/
	VIDEO_SetNextFramebuffer (xfb[0]);

	VIDEO_SetBlack (0);

	/*** Update the video for next vblank ***/
	VIDEO_Flush ();

	VIDEO_WaitVSync ();		/*** Wait for VBL ***/
	if (vmode->viTVMode & VI_NON_INTERLACE)
		VIDEO_WaitVSync ();

}


void BibGraphicsDevice::SwapMemToScreen (void)
{
#if 0
	// Update for any potential screen effects that were registered.
	UpdateScreenEffects ();
#endif

	/*** Set this as next frame to display ***/
	VIDEO_SetNextFramebuffer (xfb[whichfb]);
	VIDEO_Flush ();
	VIDEO_WaitVSync ();
	
	/*** Flip to off screen xfb ***/
	whichfb ^= 1;

	// Useful for debugging graphics drawing issues.
	//	VIDEO_ClearFrameBuffer (vmode, xfb[whichfb], COLOR_WHITE);
}


//!!!! There is a minor graphics glitch where images on the right 
//      bleed a few pixels on the the next line on the left.
void BibGraphicsDevice::RenderBitmap (BibSprite & pSprite, BibPoint & bpScreenLoc)
{
unsigned int w, bitmap_rows, bitmap_cols;
	
	w = 0;
	
	for (bitmap_rows = 0; bitmap_rows < pSprite.GetHeight(); bitmap_rows++)
	{
		// Remember two pixels per u32 word.
		for (bitmap_cols = 0; bitmap_cols < pSprite.GetWidth() >> 1; bitmap_cols++)
		{
			if (pSprite.GetBMHandle() [w] != TRANSPARENT_COLOR)
				fb((bpScreenLoc.x >> 1) + bitmap_cols, bpScreenLoc.y + bitmap_rows, pSprite.GetBMHandle() [w]);
			w ++;
		}
	}

}


void BibGraphicsDevice::RenderBitmap (BibSprite & pSprite, BibPoint & bpScreenLoc, BibPoint & bpSrcTopLeft, BibPoint & bpSrcSize)
{
unsigned int v, w, bitmap_rows, bitmap_cols;
	
	// Calculate index into Sprite buffer
	
	// Calculate index into linear frame buffer.
	//!!! This probably shouldn't be a hard coded 320.
	v = (bpScreenLoc.y * 320) + (bpScreenLoc.x >> 1);

	if (v < 0)
	{
		nError ++;
		nBadX = bpScreenLoc.x;
		nBadY = bpScreenLoc.y;
		return;
	}

	for (bitmap_rows = 0; bitmap_rows < (unsigned int) bpSrcSize.y; bitmap_rows++)
	{
		// Error check.
		if ((v + (bpSrcSize.x >> 1)) > nFBSize)
		{
			nError++;
			nBadX = bpScreenLoc.x;
			nBadY = bpScreenLoc.y;
			break;
		}
		
		// Remember two pixels per u32 word.
		for (bitmap_cols = 0; bitmap_cols < (unsigned int) bpSrcSize.x >> 1; bitmap_cols++)
		{
			w = ((bpSrcTopLeft.y + bitmap_rows) * (pSprite.GetWidth()/2)) + ((bpSrcTopLeft.x / 2) + bitmap_cols);

			if (pSprite.GetBMHandle() [w] != TRANSPARENT_COLOR)
				fb() [v + bitmap_cols] = pSprite.GetBMHandle() [w];
		}
		v += 320;
	}

}


#define FONT_XSIZE 8
#define FONT_YSIZE 16
void BibGraphicsDevice::ConsoleDrawString (int xpos, int ypos, const char * szStr, bool bUseTransparency)
{
int i;

	for (i = 0; szStr[i]; i ++)
	{
		ConsoleDrawChar (xpos + FONT_XSIZE * i, ypos, szStr [i]);
	}

}


/*
	Borrowed and modified this code from libogc.
	It uses the built in font in libogc.
	The coordinates input to this function are in screen coords (0,0) is upper left
	down to (640,480) to lower right.
*/
#if 0
void BibGraphicsDevice::ConsoleDrawChar (int xpos, int ypos, int c, bool bUseTransparency)
{
extern unsigned char console_font_8x16[];
unsigned int v;	// Index into frame buffer - fb()


	int ax, ay;
	for (ay = 0; ay < FONT_YSIZE; ay++)
	{
		for (ax = 0; ax < 4; ax ++)
		{
			unsigned int color[2];
			int bits = (console_font_8x16[c * FONT_YSIZE + ay] << (ax*2));
			if (bits & 0x80)
				color[0] = COLOR_WHITE;
			else
				color[0] = COLOR_BLACK;
			if (bits & 0x40)
				color[1] = COLOR_WHITE;
			else
				color[1] = COLOR_BLACK;


			v = ((ypos + ay) * 320) + (xpos / 2) + ax;
			if ((v >= 0) && (v <= nFBSize))
				fb() [v] = (color[0] & 0xFFFF00FF) | (color[1] & 0x0000FF00);
		}
	}
}
#endif

void BibGraphicsDevice::ConsoleDrawChar (int xpos, int ypos, int c, bool bUseTransparency)
{
extern unsigned char console_font_8x16[];
unsigned int v;	// Index into frame buffer - fb()

	int ax, ay;
	for (ay = 0; ay < FONT_YSIZE; ay++)
	{
		for (ax = 0; ax < 4; ax ++)
		{
			int bits = (console_font_8x16[c * FONT_YSIZE + ay] << (ax*2));
			v = ((ypos + ay) * 320) + (xpos / 2) + ax;
			switch (bits & 0xC0)
			{
				case 0x00:	fb() [v] = COLOR_BLACK; break;
				case 0x80:  fb() [v] = 0xFF800080;  break;
				case 0x40:  fb() [v] = 0x0080FF80;  break;
				case 0xC0:	fb() [v] = COLOR_WHITE; break;
			}
		}
	}
}


#if 0
/*
	This was the original code taken from libogc.
	There is an issue with this.  When using 'ptr' here
	and 'fb()' in other routines, the graphics don't stack properly.
*/
void BibGraphicsDevice::ConsoleDrawChar (int xpos, int ypos, int c)
{
extern unsigned char console_font_8x16[];

	// Change xy positions from pixels into character locations.
	xpos /= FONT_XSIZE;		// Convert from pixels to characters.
	//ypos /= FONT_YSIZE;	// Keep in pixels.

	int ax, ay;
	unsigned int *ptr = (unsigned int*)(fb () + 320 * ypos + xpos * 4);
	for (ay = 0; ay < FONT_YSIZE; ay++)
	{
		for (ax = 0; ax < 4; ax ++)
		{
			unsigned int color[2];
			int bits = (console_font_8x16[c * FONT_YSIZE + ay] << (ax*2));
			if (bits & 0x80)
				color[0] = COLOR_WHITE;
			else
				color[0] = COLOR_BLACK;
			if (bits & 0x40)
				color[1] = COLOR_WHITE;
			else
				color[1] = COLOR_BLACK;

			if ((ptr[ay * 320 + ax] - ptr [0]) <= nFBSize)
				ptr[ay * 320 + ax] = (color[0] & 0xFFFF00FF) | (color[1] & 0x0000FF00);
		}
	}
}
#endif


/*
	Minimize Luma color component to make the screen look dimmer.
	And black out every other pair of pixels.
*/
void BibGraphicsDevice::DimAndCheckerBoardFB (void)
{
int v;
u32 d, d1;

	for (v = 0; v < 320*480; v ++)
	{
		if (v % 2)
		{
			fb()[v] = COLOR_BLACK;
		}
		else
		{
			d = fb()[v];
			d1 = d;
			
			d = d & 0x00FF00FF;		// Clear Y1 and Y2 (luma).
			d1 = d1 & 0xFF00FF00;	// Save Y1 and Y2;
			d1 = d1 >> 2;			// Divide Y1 and Y2 by 4.
			d1 = d1 & 0xFF00FF00;	// Mask off.
			d = d | d1;
			
			fb()[v] = d;
		}
	}
}

/*
	Minimize Luma color component to make the screen look dimmer.
*/
void BibGraphicsDevice::DimFB (void)
{
int v;
u32 d, d1;

	for (v = 0; v < 320*480; v ++)
	{
		d = fb()[v];
		d1 = d;
		
		d = d & 0x00FF00FF;		// Clear Y1 and Y2 (luma).
		d1 = d1 & 0xFF00FF00;	// Save Y1 and Y2;
		d1 = d1 >> 2;			// Divide Y1 and Y2 by 4.
		d1 = d1 & 0xFF00FF00;	// Mask off.
		d = d | d1;
		
		fb()[v] = d;
		
	}
}

// Every other pixel is black.
void BibGraphicsDevice::CheckerBoardFB (void)
{
int v;

	for (v = 0; v < 320*480; v += 2)
	{
		fb()[v] = COLOR_BLACK;
	}
}


#if 0
void BibGraphicsDevice::UpdateScreenEffects (void)
{


}

void BibGraphicsDevice::RegisterScreenEffect (eEffectTypes eEffect, int nValue1, int nValue2, BibPoint & bpScreenLoc, BibPoint & bpSrcSize)
{
SingleEffect * se;

	se = new SingleEffect ();
	se->eEffect = eEffect;
	se->nValue1 = nValue1; 
	se->nValue2 = nValue2;
	se->bpScreenLoc = bpScreenLoc;
	se->bpSrcSize = bpSrcSize;
	
	EffectList.push_back (*se);
}
#endif
