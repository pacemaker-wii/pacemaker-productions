// GraphicsDevice.h

#include <vector>
#include "BibPoint.h"
#include "BibSprite.h"


#ifndef _BIBGRAPHICSDEVICE_H_
#define _BIBGRAPHICSDEVICE_H_


/*
	Framebuffer is allocated with: 
		VIDEO_PadFramebufferWidth(rmode->fbWidth)*rmode->xfbHeight*VI_DISPLAY_PIX_SZ)
	For NTSC this is:  720 * 480 * 2  = 691200 in bytes
						              = 172800 (32 bit integers)
	one 32 bit integer holds two pixels in Y1CbY2Cr format.
*/

class BibGraphicsDevice
{
private:

	GXRModeObj *vmode;	/*** Graphics Mode Object ***/
	u32 *xfb[2];		/*** Framebuffers ***/
	unsigned int nFBSize;		/*** Size of frame buffer in words (for error checking) ***/
	int whichfb;		/*** Frame buffer toggle ***/

	int nError;			/*** If we detect errors ***/
	int nBadX, nBadY;
	
	// FrameBuffer
	inline u32 * fb () { return xfb[whichfb]; }
	int fb (int x, int y, int d);

public:
	BibGraphicsDevice ();
	~BibGraphicsDevice ();

	GXRModeObj * GetVMode (void) { return (vmode); }

	int GetError (void) { return nError; }
	int GetBadX (void) { return nBadX; }
	int GetBadY (void) { return nBadY; }
	
	static u32 RGBtoGC (u8 r1, u8 g1, u8 b1, u8 r2, u8 g2, u8 b2);
	
	void Initialize (void);
	void SwapMemToScreen (void);

	int getHeight (void) { return vmode->xfbHeight; }
	int getWidth (void) { return vmode->fbWidth; }

	void RenderBitmap (BibSprite & pSprite, BibPoint & bpScreenLoc);
	// Used to render part of a bitmap.
	void RenderBitmap (BibSprite & pSprite, BibPoint & bpScreenLoc, BibPoint & bpSrcTopLeft, BibPoint & bpSrcSize);

	void ConsoleDrawChar(int xpos, int ypos, int c, bool bUseTransparency = FALSE);
	void ConsoleDrawString (int xpos, int ypos, const char * szStr, bool bUseTransparency = FALSE);


	void DimFB (void);
	void CheckerBoardFB (void);
	void DimAndCheckerBoardFB (void);

#if 0
	// Experimental Screen Effect stuff.
	enum eEffectTypes { effFadeBlack, effFadeWhite };
	struct SingleEffect
	{
		eEffectTypes eEffect;
		int nValue1; 
		int nValue2;
		BibPoint bpScreenLoc;
		BibPoint bpSrcSize;
	};
	
	// Define a list of single frames to be a single animation sequence.
	typedef std::vector<SingleEffect> EffectListType;
	EffectListType EffectList;

	void UpdateScreenEffects (void);
	void RegisterScreenEffect (eEffectTypes eEffect, int nValue1, int nValue2, BibPoint & bpScreenLoc, BibPoint & bpSrcSize);
#endif

};

#endif
