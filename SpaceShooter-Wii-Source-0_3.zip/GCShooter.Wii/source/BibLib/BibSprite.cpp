
#include "BibSprite.h"


BibSprite::BibSprite ()
{
	nWidth = 0;
	nHeight = 0;
}


BibSprite::~BibSprite ()
{
}



bool BibSprite::LoadBitmap (const u32 * in_pBMData, int in_nWidth, int in_nHeight)
{
	nWidth = in_nWidth;
	nHeight = in_nHeight;
	pBMData = (u32 *) in_pBMData;

	if (pBMData)
		return (true);
	else
		return (false);
}

