// BibMenus.h

/*


Selection from list dialog box.:
	+------------+
	|   Title    |
	|============|
	|  apples    |
	|* oranges   |
	|  bananas   |
	+------------+
 - Initialize
 - DisplayListBox
 - Up/Down to move between.
 - (A) to select



*/

#ifndef _BIBMENUS_H_
#define _BIBMENUS_H_

#include "BibGraphicsDevice.h"


class BibMenus
{
private:
	
	BibSprite bsBoxHeader;
	BibSprite bsBoxMid;
	BibSprite bsBoxFooter;

	// Saved data from the someone set us up the menu.
	const char * szTitle;
	const char * * szItemNames;
	int nItems;
	int nCurSel;

public:

	enum eInputTypes { INPUT_UP, INPUT_DOWN, INPUT_SELECT, INPUT_BACK };

	BibMenus ();
	~BibMenus ();
	void Initialize ();
	void SetupListBox (const char * szTitle, const char * szItemNames [], const int nItems);
	void DisplayListBox (BibGraphicsDevice & GD);
	int ProcessInput (eInputTypes eInput);


};
#endif
