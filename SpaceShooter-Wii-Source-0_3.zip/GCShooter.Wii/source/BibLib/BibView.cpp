// BibView.cpp: implementation of the BibView class.
//
//////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <math.h>

#include "BibView.h"
#include "BibWorld.h"


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

BibView::BibView()
{
	pWorld = NULL;
}

BibView::~BibView()
{

}



void BibView::SetWorld (BibWorld * pinWorld)
{
	pWorld = pinWorld;
}







void BibView::Render (BibGraphicsDevice & GD)
{
BibPoint bpLoc, bpBoardLoc;


	// Check to see if we have been initialized.
	if (! pWorld)
		return;


	/*
		Put background bitmap in here.
	*/
	bpLoc . x = 0;
	bpLoc . y = 0;
	GD . RenderBitmap (pWorld -> GetBackgroundSprite (), bpLoc);

}


