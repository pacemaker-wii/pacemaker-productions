/*
	BibAnimSeq Class (Animation Sequence)

*/

#include "BibAnimSeq.h"
#include "BibBitmapServer.h"


BibAnimationSequences::BibAnimationSequences ()
{
	nCurSequence = 0;
	nCurFrame = 0;
	nFrameTime = 0;
	bbsBitmapServer = NULL;
}

void BibAnimationSequences::Initialize (BibBitmapServer * inbbsBitmapServer)
{
	bbsBitmapServer = inbbsBitmapServer;
	
	// You get one sequence for free.
	AddSequence ();
}


BibAnimationSequences::~BibAnimationSequences ()
{
unsigned int i;
SingleFrame * sfDel;

	// Delete stuff here.

	// For every Frame Sequence
	for (i = 0; i < FrameSequences.size(); i ++)
	{
		// Delete the sprite in each frame.
		// !!! This doesn't seem optimal yet.
		while (FrameSequences [i] . size ())
		{
			sfDel = & (FrameSequences [i] [FrameSequences [i] . size () - 1]);
			delete (sfDel->pSprite);
			FrameSequences [i] . pop_back ();
		}
	}

}


int BibAnimationSequences::AddSequence (void)
{
FrameSequenceType fsTemp;

	FrameSequences . push_back (fsTemp);

	return (FrameSequences . size () - 1);
}




void BibAnimationSequences::AddFrame (int innSequenceNumber, int innFrameDuration, int innNextFrame, const u32 * pBMData, int nWidth, int nHeight)
{
struct SingleFrame Frame;

	if (! bbsBitmapServer)
		return;

	Frame . nFrameDuration = innFrameDuration;
	Frame . nNextFrame = innNextFrame;
	Frame . pSprite = bbsBitmapServer->LoadBitmap (pBMData, nWidth, nHeight);

	FrameSequences [innSequenceNumber] . push_back (Frame);
}


void BibAnimationSequences::SetCurFrame (unsigned int innCurFrame)
{
	nCurFrame = innCurFrame;
	nFrameTime = 0;
}

void BibAnimationSequences::SetCurSequence (int innCurSequence)
{
	nCurSequence = innCurSequence;
	nCurFrame = 0;
	nFrameTime = 0;
}


void BibAnimationSequences::IncFrameTime (float nDeltaFrameTime)
{
	nFrameTime += nDeltaFrameTime;
	
	// This code does not jump more than one frame per update.
	if (nFrameTime >= (FrameSequences [nCurSequence]) [nCurFrame] . nFrameDuration)
	{
		nFrameTime -= FrameSequences [nCurSequence] [nCurFrame] . nFrameDuration;
		nCurFrame = FrameSequences [nCurSequence] [nCurFrame] . nNextFrame;
	}
}


BibSprite & BibAnimationSequences::GetCurSprite (void) 
{
	return *(FrameSequences [nCurSequence] [nCurFrame] . pSprite);

}

bool BibAnimationSequences::IsLastFrame (void)
{
	return (nCurFrame == (FrameSequences [nCurSequence] . size () - 1));
}
