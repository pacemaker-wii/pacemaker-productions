/*
	BibAnimSeq Class (Animation Sequence)


	A Single Frame is a single still bitmap with a duration.
		The units of duration are 'frames'.  Typically it's 60 frames-per-sec.
	A Frame Sequence is a list of Single Frames that comprise a single
		animation.  E.g. a punching move for a character.
	This class holds many Frame Sequences.

*/

#pragma once

#include <vector>
#include "BibSprite.h"

class BibAnimationSequences
{
private:

	// This is a single frame, a single sprite picture.
	struct SingleFrame
	{
		int nFrameDuration;
		int nNextFrame;
		BibSprite * pSprite;	// Keep this a pointer so we can copy the structures easier.
	};

	// Define a list of single frames to be a single animation sequence.
	typedef std::vector<SingleFrame> FrameSequenceType;
	// Create a list of animation sequences.
	std::vector<FrameSequenceType> FrameSequences;

	int nCurSequence;
	unsigned int nCurFrame;
	float nFrameTime;
	
	class BibBitmapServer * bbsBitmapServer;

public:


	BibAnimationSequences ();
	~BibAnimationSequences ();

	void Initialize (BibBitmapServer * inbbsBitmapServer);


	void SetCurSequence (int innCurSequence);
	int GetCurSequence (void) { return nCurSequence; }
	void SetCurFrame (unsigned int innCurFrame);
	unsigned int GetCurFrame (void) { return nCurFrame; }
	bool IsLastFrame (void);
	BibSprite & GetCurSprite (void);

	int AddSequence (void);
	void AddFrame (int nSequenceNumber, int nFrameDuration, int nNextFrame, const u32 * pBMData, int nWidth, int nHeight);
	void IncFrameTime (float nFrameTime);

};

