/*

	BibControl Class

	This is the base class to control a single game object,
	e.g. hero or enemy.

*/

#pragma once

#include "BibPoint.h"
#include "BibSprite.h"
#include "BibAnimSeq.h"


class BibControl
{
public:
	enum ePieceFlags { NONE = 0, IS_HERO = 1, IS_WALL = 2, IS_GOAL = 4, IS_BOMB = 8, IS_ENEMY = 16, IS_BULLET = 32 };


protected:
	int nFlags;	//!!! Kludgy, Is there a better way to do this?
	BibAnimationSequences basSpriteData;
	class BibWorld * pWorld;

	bool bMoveToNextLoc;
	BibPoint bpNextLocation;
	bool bSelfDestruct;

	BibPoint bpMyLocation;
	BibPoint bpSize;

	int nHitPoints;
public:

	virtual void Initialize (class BibWorld * pWorld);
	virtual void UnInitialize ();

	BibSprite & GetCurSprite (void);
	BibPoint GetCenter (void);
	BibPoint & GetSize (void) { return (bpSize); }
	BibPoint & GetLocation (void) { return (bpMyLocation); }
	virtual void SetLocation (BibPoint & inbpLoc) { bpMyLocation = inbpLoc; }

	int GetFlags (void) { return (nFlags); }
	virtual void SetFlags (ePieceFlags eFlags) { nFlags = eFlags; }
	bool MoveToNextLoc (void) { return (bMoveToNextLoc); }
	bool SelfDestruct (void) { return (bSelfDestruct); }
	void SetSelfDestruct (void) { bSelfDestruct = true; }
	void ClearSelfDestruct (void) { bSelfDestruct = false; }
	BibPoint & GetNextLoc (void) { return (bpNextLocation); }

	int GetHitPoints (void) { return (nHitPoints); }
	void SetHitPoints (int innHitPoints) { nHitPoints = innHitPoints; }
	void DecHitPoints (int nDelta) { nHitPoints -= nDelta; }
	void IncHitPoints (int nDelta) { nHitPoints += nDelta; }
	

	// This is called very often to have the object move, etc.
	virtual bool UpdateMovement (float fSpeedFactor);

	virtual bool Shot (int nHits) = 0;
	virtual bool OnRadar (void) { return (true); }
};
