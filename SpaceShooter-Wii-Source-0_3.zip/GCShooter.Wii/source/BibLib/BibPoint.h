// BibPoint.h: interface for the BibPoint class.
//	!!! this is the integer version
//
//////////////////////////////////////////////////////////////////////

#ifndef _BIBPOINT_H_
#define _BIBPOINT_H_

class BibPoint  
{
private:


public:
	BibPoint (int x = 0, int y = 0, int z = 0);
	virtual ~BibPoint();

	int x, y, z;


	void SetSize (int x, int y);
	void SetSize (int x, int y, int z);

	bool operator== (BibPoint &other);

	// Vector operations.
	//BibPoint operator+ (BibPoint &other);
	BibPoint operator+ (BibPoint other);
	BibPoint operator- (BibPoint &other);
	BibPoint operator+ (int fScalar);
	BibPoint operator- (int fScalar);
	BibPoint operator/ (int nDenominator);
	BibPoint operator* (int fScalar);
	int Dot (BibPoint & other);
	int Magnitude (void);
	void Normalize (void);

	int DistanceSquared (BibPoint & other);
	int Distance (BibPoint & other);
};

#endif
