// BibWorld.cpp: implementation of the BibWorld class.
//
//////////////////////////////////////////////////////////////////////

#define BIB_WORLD_CPP
#include "BibWorld.h"


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

BibWorld::BibWorld()
{
}

BibWorld::~BibWorld()
{
}


void BibWorld::Initialize (bool bLoadSavedData)
{
	SetLives (3);
	SetScore (0);
	SetLevelScore (0);

}

void BibWorld::UnInitialize (void)
{
/*
BibPersistentData EPD;

	EPD . SetData (GetLevel (), GetScore ());
	EPD . SaveData ();
*/
}

int BibWorld::SetSize (BibPoint bpinWorldSize)
{
	bpWorldSize = bpinWorldSize;
	return (1);
}


BibPoint BibWorld::GetSize (void)
{
	return (bpWorldSize);
}





void BibWorld::UpdateMovement (float fSpeedFactor)
{
/*
	if (eGameState == eGameStateType::GAME_OVER)
		return;
*/
	// For all objects, call their controller to update.
}



void BibWorld::SetLastClick (BibPoint & bpBoardLoc, bool bDest)
{

}


int BibWorld::SetLevel (int innLevel) 
{
	return (0);
}


int BibWorld::IncLevel (void)
{ 

	return (0);
}

int BibWorld::RestartLevel (void)
{ 
	return (0);
}



int BibWorld::SetScore (int innScore)
{
	return (nScore = innScore);
}

int BibWorld::SetLevelScore (int innScore)
{
	return (nLevelScore = innScore);
}


int BibWorld::IncScore (int nInc)
{
	return (nScore += nInc);
}

int BibWorld::IncLevelScore (int nInc)
{
	return (nLevelScore += nInc);
}


float BibWorld::SetTimeLeft (float infTimeLeft)
{
	return (fTimeLeft = infTimeLeft);
}

float BibWorld::IncTimeLeft (float fInc)
{
	return (fTimeLeft += fInc);
}

float BibWorld::DecTimeLeft (float fDec)
{
	return (fTimeLeft -= fDec);
}

