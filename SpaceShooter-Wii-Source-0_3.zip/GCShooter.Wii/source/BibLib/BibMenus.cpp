// BibMenus.cpp

#define _BIBMENUS_CPP_

#include "BibMenus.h"
#include "BibWiiInputDevice.h"

// Shouldn't mix BibLib sprites with Game sprites.
#include "../Sprites/DialogBoxHeader.sprite.h"
#include "../Sprites/DialogBoxMid.sprite.h"
#include "../Sprites/DialogBoxFooter.sprite.h"

//  This is the width of the console font from LIBOGC.
//  It shouldn't have to be here, but it's not exported from the LIBOGC internals.
#define FONT_WIDTH	8

BibMenus::BibMenus ()
{

}

BibMenus::~BibMenus ()
{

}

void BibMenus::Initialize ()
{
	// Load box pictures
	bsBoxHeader . LoadBitmap ((u32 *)DialogBoxHeader_Bitmap, DIALOGBOXHEADER_WIDTH, DIALOGBOXHEADER_HEIGHT);
	bsBoxMid . LoadBitmap ((u32 *)DialogBoxMid_Bitmap, DIALOGBOXMID_WIDTH, DIALOGBOXMID_HEIGHT);
	bsBoxFooter . LoadBitmap ((u32 *)DialogBoxFooter_Bitmap, DIALOGBOXFOOTER_WIDTH, DIALOGBOXFOOTER_HEIGHT);
	nCurSel = 0;
}


void BibMenus::SetupListBox (const char * _szTitle, const char * _szItemNames [], const int _nItems)
{
	szTitle = _szTitle;
	szItemNames = _szItemNames;
	nItems = _nItems;
	nCurSel = 0;
}


void BibMenus::DisplayListBox (BibGraphicsDevice & GD)
{
int i, xMidPoint;
BibPoint bpScreenLoc;


	// Make existing frame buffer dimmer (lower luma, Y`) and fill every other two pixels with black.
	GD.DimAndCheckerBoardFB ();
	
	/*
		Display Graphic background.
	*/

	// Display Header of list box.
	bpScreenLoc.x = (640 / 2) - (DIALOGBOXHEADER_WIDTH / 2);	// Center horizontally.
	bpScreenLoc.y = (480 / 2) - ((DIALOGBOXHEADER_HEIGHT + (DIALOGBOXMID_HEIGHT * nItems) + DIALOGBOXFOOTER_HEIGHT) / 2);
	GD.RenderBitmap (BibMenus::bsBoxHeader, bpScreenLoc);
	
	// Adjust Y location for first mid section.
	bpScreenLoc.y += DIALOGBOXHEADER_HEIGHT;

	// Do all mid sections except last one.
	for (i = 0; i < nItems - 1; i ++)
	{
		GD.RenderBitmap (bsBoxMid, bpScreenLoc);
		bpScreenLoc.y += DIALOGBOXMID_HEIGHT;
	}
	// Display last mid section.
	GD.RenderBitmap (bsBoxMid, bpScreenLoc);
	
	// Display footer section.
	bpScreenLoc.y += DIALOGBOXMID_HEIGHT;
	GD.RenderBitmap (bsBoxFooter, bpScreenLoc);




	/*
		Display Text on top of graphic background.
	*/
	xMidPoint = (bpScreenLoc.x + (DIALOGBOXHEADER_WIDTH / 2));
	bpScreenLoc.x =  xMidPoint - ((strlen (szTitle) * FONT_WIDTH) / 2);
	if (bpScreenLoc.x < 0)
		bpScreenLoc.x = xMidPoint - (DIALOGBOXHEADER_WIDTH / 2) + FONT_WIDTH;
	bpScreenLoc.y = (480 / 2) - ((DIALOGBOXHEADER_HEIGHT + (DIALOGBOXMID_HEIGHT * nItems) + DIALOGBOXFOOTER_HEIGHT) / 2) + 8; // 8 is a fudge factor
	GD.ConsoleDrawString (bpScreenLoc.x, bpScreenLoc.y, szTitle, TRUE);

	// Adjust Y location for first mid section.
	bpScreenLoc.y += DIALOGBOXHEADER_HEIGHT - 8;	// Subtract the fudge factor above.

	// Left justified text for each menu item.
	bpScreenLoc.x =  xMidPoint - (DIALOGBOXHEADER_WIDTH / 2) + (FONT_WIDTH * 3);

	// Do all menu items except last one.
	for (i = 0; i < nItems - 1; i ++)
	{
		GD.ConsoleDrawString (bpScreenLoc.x, bpScreenLoc.y, szItemNames [i], TRUE);
		if (nCurSel == i)
			GD.ConsoleDrawString (bpScreenLoc.x - (FONT_WIDTH * 3) + 2, bpScreenLoc.y, "->", TRUE);
		bpScreenLoc.y += DIALOGBOXMID_HEIGHT;
	}
	// Display last menu item section.
	GD.ConsoleDrawString (bpScreenLoc.x, bpScreenLoc.y, szItemNames [i], TRUE);
	if (nCurSel == i)
		GD.ConsoleDrawString (bpScreenLoc.x - (FONT_WIDTH * 3) + 2, bpScreenLoc.y, "->", TRUE);


}


/*
	This function returns:
		-2 = Abort/back.
		-1 = No selection yet.
		0..(nItems-1) = selection made.
*/
int BibMenus::ProcessInput (eInputTypes eInput)
{
	switch (eInput)
	{
		case INPUT_DOWN:
			if (nCurSel < (nItems - 1))
				nCurSel ++;
			else
				nCurSel = 0;
		break;
	
		case INPUT_UP:
			if (nCurSel > 0)
				nCurSel --;
			else
				nCurSel = nItems - 1;
		break;

		case INPUT_SELECT:
			return (nCurSel);
		break;
		
		case INPUT_BACK:
			return (-2);
		break;
		
		default:
		break;
	}
	
	return (-1);
}


