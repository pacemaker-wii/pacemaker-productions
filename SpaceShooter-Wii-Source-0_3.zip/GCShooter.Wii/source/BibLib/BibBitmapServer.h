/*

	BibBitmapServer


	This class holds all of the GDI specific bitmap information.

	It keeps a list of BibSprite objects, and makes duplicates as
	necessary so we don't reload the same graphics all of the time.
*/

#pragma once

#include <map>
#include <string>
#include "BibSprite.h"



class BibBitmapServer
{
private:

	// This is for loading by filename.
	typedef std::map<std::string, class BibSprite *> sBitmapListType;
	typedef std::map<std::string, class BibSprite *>::iterator sBitmapListIteratorType;

	// This is for loading by resource id.
	typedef std::map<int, class BibSprite *> iBitmapListType;
	typedef std::map<int, class BibSprite *>::iterator iBitmapListIteratorType;

	sBitmapListType sBitmapList;
	iBitmapListType iBitmapList;

public:


	BibSprite * LoadBitmap (const u32 * pBMData, int nWidth, int nHeight);
	void UnLoadBitmap (BibSprite * pSprite);

};

