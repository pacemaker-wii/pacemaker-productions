
/*
	Sprite.h
*/

#ifndef _SPRITE_H_
#define _SPRITE_H_

#include <gccore.h>


class BibSprite
{
private:
	unsigned int nWidth;
	unsigned int nHeight;
	u32 * pBMData;

public:

	BibSprite ();
	~BibSprite ();

	bool LoadBitmap (const u32 * pBMData, int nWidth, int nHeight);
	u32 * GetBMHandle (void) { return pBMData; }
	unsigned int GetWidth (void) { return (nWidth); };
	unsigned int GetHeight (void) { return (nHeight); }
};
#endif
