/*

	BibSound2.cpp

*/


#include <gccore.h>
#include "BibCriticalSection.h"
#include "BibSound2.h"



// This class is really a singleton.
static BibSound2 * bs2c = NULL;	// BibSound2 Class


//!!!! Debug Use
extern int nDebugCounterR;
extern char szDebugMsg1 [256];
extern char szDebugMsg2 [256];
int nDebugBits;
extern int nDebugCounterR;


// 2 second buffer at 48KHz.
#define MAX_SAMPLES 96000


BibSound2::BibSound2 ()
{
	if (bs2c != NULL)
		printf ("  BibSound2 is a singleton, found more than one instance!\n");
	bSoundOn = true;
	bs2c = this;
	aMutex = LWP_MUTEX_NULL;
	which_sb = 0;
}

BibSound2::~BibSound2 ()
{
	iLoadedSampleList.clear();  //!!!! This needs to free memory.
	iPlayList.clear();	//!!!! This needs to free memory.
}

// Called when the DMA'ed buffer runs out.
static void AudioDMAComplete()
{
	if (bs2c)
		bs2c->NextBuffer ();
}


// Move to next buffer.
void BibSound2::NextBuffer ()
{
//if (nDebugCounterR)	 //!!!!	
	BibCriticalSection CS (aMutex);
	
	// Stop DMA (it's done anyway)
    AUDIO_StopDMA ();

	// Clear all Data from the buffer just played.
	memset (CurSB (), 0, MAX_SAMPLES * 4);
	
	// Switch to other buffer
	which_sb ^= 1;

	// If there are any incompletely copied samples,
	//  copy them to the new buffer.
	MoveSamplesToNewBuffer ();

	// Flush data out of cache.
    DCFlushRange(CurSB (), MAX_SAMPLES * 4);

	// Always play the buffer, even if it's empty to simplify the logic.
    AUDIO_InitDMA ((u32) CurSB (), MAX_SAMPLES * 4);
    AUDIO_StartDMA ();

	sprintf (szAudioLastMsg, "AudioDMAComplete()");
	AudioStatus ++;
}

void BibSound2::Initialize (void)
{
	BibCriticalSection::Initialize (& aMutex);
//if (nDebugCounterR)	 //!!!!	
	BibCriticalSection CS (aMutex);
	
	// Rounding up to next 32 byte boundary.
	SoundBuffers[0] = (u32 *) malloc ((MAX_SAMPLES+32) * sizeof (u32));
	SoundBuffers[0] = (SoundBuffers[0]) + ((32 - (((int) (SoundBuffers[0]) % 32))) / 4);
	SoundBuffers[1] = (u32 *) malloc ((MAX_SAMPLES+32) * sizeof (u32));
	SoundBuffers[1] = (SoundBuffers[1]) + ((32 - (((int) (SoundBuffers[1]) % 32))) / 4);

	AudioStatus = 0;
	which_sb = 0;

	// Clear all Data.
	memset (SoundBuffers[0], 0, MAX_SAMPLES * 4);
	memset (SoundBuffers[1], 0, MAX_SAMPLES * 4);

	AUDIO_Init (NULL);
	AUDIO_SetDSPSampleRate (AI_SAMPLERATE_48KHZ);
	AUDIO_RegisterDMACallback (AudioDMAComplete);

	// Always play the buffer, even if it's empty to simplify the logic.
    AUDIO_InitDMA ((u32) CurSB (), MAX_SAMPLES * 4);
    AUDIO_StartDMA ();

	sprintf (szAudioLastMsg, "Initialized.");
	AudioStatus ++;
}


int BibSound2::PlaySound (int nIndex)
{
BibCriticalSection CS (aMutex);

LoadedSample * ls;
int nSamples;
int nDestPos;
int i;
int nResult;


	if (! bSoundOn)
		return (0);


	ls = iLoadedSampleList [nIndex];

	if (ls->eSampleType == LoadedSample::BS_MP3)
	{
		nResult = Mp3Mixer.Initialize (this, nIndex, ls->pData, ls->nLength);
		sprintf (szAudioLastMsg, "Initialized Mp3 Object (%d), Result = %d", nIndex, nResult);
		return (ls->nLength);
	}

	// pData points to the real sound sample data.
	u32 * pData = (u32 *) ls->pData;
	
	// nSamples is the number of bytes (# bytes = Samples * 4)
	nSamples = ls->nLength;
	if ((! pData) || (! nSamples))
	{
		printf ("Bad Data to PlaySound(%d)\n", nIndex);
		sprintf (szAudioLastMsg, "Bad Data to PlaySound(%d)", nIndex);
		return (0);
	}


	/*
		Take the data from pData and add (mathematical addition) to the sound buffer
		where it's currently playing.  If this over-runs the buffer, save the state.
		Do a DCFlushRange on the SoundBuffer
		and let the DMA transfer in progress continue.
	*/

	/*
		This is the index into the Sound Buffer, where we want to add the new sound sample.
		(Queue size - bytes left to DMA).
	*/
	nDestPos = (MAX_SAMPLES * 4) - AUDIO_GetDMABytesLeft ();
	nDestPos /= 4;	// Change to index by 32 bit words
	
	if ((nDestPos < 0) || (nDestPos > MAX_SAMPLES))
	{
		sprintf (szAudioLastMsg, "ERROR: nDestPos = %d", nDestPos);
		return (0);
	}


	/*
		Loop for each 32bit word up to the point where we run out of sample data or
		until we hit the end of the buffer.
	*/
	for (i = 0; (i < (nSamples / 4)) && (nDestPos < MAX_SAMPLES); i ++, nDestPos ++)
	{
		CurSB () [nDestPos] += pData [i];
	}
	
	// Now add data to other buffer if there is extra data.
	if (i != nSamples / 4)
	{
		nDestPos = 0;
		/*
			Loop for each 32bit word up to the point where we run out of sample data or
			until we hit the end of the buffer.
		*/
		for (/* initial condition from above */; (i < (nSamples / 4)) && (nDestPos < MAX_SAMPLES); i ++, nDestPos ++)
		{
			OthSB () [nDestPos] += pData [i];
		}
		
		sprintf (szDebugMsg1, "BS2: Other Buffer used up to: %d", nDestPos);
	}
	

	// Still more data, but no more SoundBuffer room.
	// Save the sample location for when the DMA ends.
	if (i != nSamples / 4)
	{
		CurPlayingSample * cps = new CurPlayingSample ();
		cps->nSampleIndex = nIndex;			// Which Sample?
		cps->nSampleBufferIndex = i;	// Where did we leave off?

		sprintf (szDebugMsg1, "BS2: Saving ob: (0x%x)", (unsigned int) cps);

		iPlayList.push_back (cps);

		sprintf (szAudioLastMsg, "OK-Saved: Samples=%d, BufIndex=%d", nSamples, i);
	}
	else
	{
		sprintf (szAudioLastMsg, "OK: Samples=%d, nDestPos=%d", nSamples, nDestPos);
	}

	// Force data out of cache.
	DCFlushRange (CurSB (), MAX_SAMPLES * 4);

	return (nSamples);
}



void BibSound2::MoveSamplesToNewBuffer (void)
{
//if (nDebugCounterR)	 //!!!!	
	BibCriticalSection CS (aMutex);
	
int i;
int nDestPos;
int nSamples;
u32 * pData;
iPlayListIteratorType plit;
LoadedSample * ls;


	// Iterate through saved samples and put them into the new buffer.
	for (plit = iPlayList.begin(); plit != iPlayList.end(); /* Increment is below */)
	{
		sprintf (szDebugMsg2, "BS2: Found ob: (0x%x)", (unsigned int) (*plit));


		ls = iLoadedSampleList [(*plit)->nSampleIndex];
		nSamples = ls->nLength;
		nDestPos = 0;	// New buffer, destination starts at zero.

		// pData points to the real sound sample data.
		pData = (u32 *) ls->pData;


		/*
			Loop for each 32bit word up to the point where we run out of sample data or
			until we hit the end of the buffer.
			Start from where we left off before.
			
			Write data to the OtherBuffer since the original PlaySound would have used the
				CurSB() plus OthSB() at the time and this is called after the buffers
				are switched.
		*/
		for (i = (*plit)->nSampleBufferIndex; (i < (nSamples / 4)) && (nDestPos < MAX_SAMPLES); i ++, nDestPos ++)
		{
			OthSB () [nDestPos] += pData [i];
		}


		// Remove from list now.
		if (nDestPos < MAX_SAMPLES)
		{
			delete (*plit);
			plit = iPlayList.erase (plit);
		}
		else
		{
			// Save where we left off before.
			(*plit)->nSampleBufferIndex = i;
			plit++;
		}

	}

}


/*
	This returns true if the samples were added or false if there wasn't room.
	// nSamples' units is bytes.
	// nStartDestPos is in samples (4 bytes each)
*/
bool BibSound2::AddToPlayBuffer (unsigned int * pSndBuf, int nSamples, int * nStartDestBuf, int * nStartDestPos)
{
//if (nDebugCounterR)	 //!!!!	
	BibCriticalSection CS (aMutex);
u32 * UseSB;
int nSpaceLeft;	// In bytes.
int nDestPos;
int i;

	if (! bSoundOn)
		return (0);


	// Check to see if there is enough room starting from destbuf/destpos
	// If there isn't enough room, reject the Add.
	if (*nStartDestBuf == which_sb)
	{
		nSpaceLeft = MAX_SAMPLES * 4 + AUDIO_GetDMABytesLeft () - (*nStartDestPos * 4);
		UseSB = CurSB ();
	}
	else
	{
		nSpaceLeft = MAX_SAMPLES * 4 - (*nStartDestPos * 4);
		UseSB = OthSB ();
	}


	// If there is no room, try again later.
	//  Since this class is double-buffered, we don't need partials
	//  unless the incoming samples are larger than a single buffer (~2 seconds).
	if (nSamples > nSpaceLeft)
		return (false);
	

	/*
		This is the index into the Sound Buffer, where we want to add the new sound sample.
	*/
	nDestPos = * nStartDestPos;

	if ((nDestPos < 0) || (nDestPos > MAX_SAMPLES))
	{
		sprintf (szAudioLastMsg, "ERROR: nDestPos = %d", nDestPos);
		return (false);
	}


	/*
		Loop for each 32bit word up to the point where we run out of sample data or
		until we hit the end of the buffer.
	*/
	for (i = 0; (i < (nSamples / 4)) && (nDestPos < MAX_SAMPLES); i ++, nDestPos ++)
	{
		UseSB [nDestPos] += pSndBuf [i];
	}

	// Handle wrap to next buffer.
	if (i != (nSamples / 4))
	{
		nDebugBits |= 0x10;
		(* nStartDestBuf) ^= 1;

		if (*nStartDestBuf == which_sb)
			nDebugBits |= 0x100;	// This should never happen!

		// Since we'll only be here if there is room in all buffers
		//  and we overflowed, then we must be on the 'other' buffer right now.
		UseSB = OthSB ();

		/*
			Loop for each 32bit word up to the point where we run out of sample data or
			until we hit the end of the buffer.
		*/
		nDestPos = 0;
		for (/* Initial condition from above */; (i < (nSamples / 4)) && (nDestPos < MAX_SAMPLES); i ++, nDestPos ++)
		{
			UseSB [nDestPos] += pSndBuf [i];
		}
	}

	*nStartDestPos = nDestPos;

	// Force data out of cache.
	DCFlushRange (CurSB (), MAX_SAMPLES * 4);

	sprintf (szAudioLastMsg, "AddToBuf: DebugBits=0x%x, DestBuf=%d, DestPos=%d, CurBuf=%d", nDebugBits, *nStartDestBuf, *nStartDestPos, which_sb);


	return (true);
}


void BibSound2::UpdateMovement(void)
{
	Mp3Mixer.ThreadRun ();
}



/****************************************************************************
* FLIP16 - Switch from LE to BE
****************************************************************************/
static u16 FLIP16 (u16 value)
{
  return ((value & 0xff) << 8) | ((value & 0xff00) >> 8);
}

/****************************************************************************
* FLIP32 - Switch from LE to BE
****************************************************************************/
static u32 FLIP32 (u32 value)
{
  u32 b;

  b = (value & 0xff) << 24;
  b |= (value & 0xff00) << 8;
  b |= (value & 0xff0000) >> 8;
  b |= (value & 0xff000000) >> 24;

  return b;
}

/****************************************************************************
* Windows WAV file header stuff
****************************************************************************/
typedef struct
{
  u32 RIFF;
  u32 riSize;
  u32 WAVE;
  u32 waFmt;
  u32 fmtSize;
  u16 fmtType;
  u16 fmtChannels;
  u32 fmtRate;
  u32 fmtSamplesPerSecond;
  u16 fmtBlockAlign;
  u16 fmtBitsPerSample;
  u16 fmtExtensionSize;
} __attribute__ ((__packed__)) WAVEHDR;

typedef struct
{
  u32 WAVEDATA;
  u32 waSize;
} __attribute__ ((__packed__)) WAVEDATAHDR;

/****************************************************************************
* CvtWave
*
* Convert PC (x86) WAVE to GC Raw Audio
*
* This returns the number of bytes converted and available for Audio DMA.
****************************************************************************/
int BibSound2::ConvertWave (unsigned char * wavebuffer)
{
WAVEHDR wavhdr;
WAVEDATAHDR datahdr;
int samples;
int i;
u16 *src, *dst;
int samplerate;

	/*** Capture the WAV file header ***/
  memcpy (&wavhdr, wavebuffer, sizeof (WAVEHDR));

	/*** Do some basic checking ***/
  if (memcmp (&wavhdr.RIFF, "RIFF", 4))
    return 0;

  if (memcmp (&wavhdr.WAVE, "WAVE", 4))
    return 0;

  if (memcmp (&wavhdr.waFmt, "fmt ", 4))
    return 0;

	/*** Important!
	 * Wave file must be type 1 == Uncompressed PCM
	 */
  if (FLIP16 (wavhdr.fmtType) != 1)
    return 0;

	/*** Looking good! - So capture the sample rate ***/
  samplerate = FLIP32 (wavhdr.fmtRate);
  if ((samplerate != 32000) && (samplerate != 48000))
    return 0;

	/*** Also need 2 channels ***/
  if (FLIP16 (wavhdr.fmtChannels) != 2)
    return 0;

	/*** Pickup the data header ***/
  memcpy (&datahdr, wavebuffer + 20 + FLIP32 (wavhdr.fmtSize), 8);

  if (memcmp (&datahdr.WAVEDATA, "data", 4))
    return 0;

  samples = FLIP32 (datahdr.waSize);
  samples >>= 1;

	/***
	 * NB: Sound data MUST be aligned to 32 bytes.
	 */
  src = (u16 *) wavebuffer + 28 + FLIP32 (wavhdr.fmtSize);
  dst = (u16 *) wavebuffer;

  for (i = 0; i < samples; i++)
    dst[i] = FLIP16 (src[i]);

  return samples << 1;
}


bool BibSound2::LoadSoundWav (int nIndex, unsigned char * pData)
{
//if (nDebugCounterR)	 //!!!!	
	BibCriticalSection CS (aMutex);
	
int samples;
	
	samples = ConvertWave (pData);

	if (samples == 0)
	{
		printf ("Can't Load Sound (%d)\n", nIndex);
		return (false);
	}
	else
	{
		LoadedSample * ls;
	
		ls = new LoadedSample ();
		ls->pData = pData;
		ls->nLength = samples;
		ls->eSampleType = LoadedSample::BS_WAV;
	
		iLoadedSampleList [nIndex] = ls;

		return (true);
	}
}



// Load MP3 data and convert.
bool BibSound2::LoadSoundMp3 (int nIndex, unsigned char * pData, int nLength)
{
//if (nDebugCounterR)	 //!!!!	
	BibCriticalSection CS (aMutex);
	
	LoadedSample * ls;
	
	ls = new LoadedSample ();
	ls->pData = pData;
	ls->nLength = nLength;
	ls->eSampleType = LoadedSample::BS_MP3;
	
	iLoadedSampleList [nIndex] = ls;
	
	return (true);
}

