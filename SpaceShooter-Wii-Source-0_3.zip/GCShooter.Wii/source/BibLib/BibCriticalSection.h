// BibCriticalSection.h


// LWP_MUTEX_NULL

class BibCriticalSection
{
	private:
		u32 aMutex;

	public:
		BibCriticalSection (u32 inaMutex)
			{ aMutex = inaMutex; if (aMutex != LWP_MUTEX_NULL) while (LWP_MutexLock (aMutex) != 0); }
		~BibCriticalSection ()
			{ LWP_MutexUnlock (aMutex); }
			

	static void Initialize (u32 * pMutex) { LWP_MutexInit (pMutex, true); }

};
