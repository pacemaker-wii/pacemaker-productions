// BibWorld.h: interface for the BibWorld class.
//
//////////////////////////////////////////////////////////////////////


#pragma once

#include "BibPoint.h"
#include "BibSprite.h"
#include "BibAnimSeq.h"
#include "BibView.h"
#include "BibCtrl.h"
#include "BibBitmapServer.h"

class BibWorld  
{
public:	
//	enum eGameStateType { GAME_OVER };

protected:
	class BibView * pView;

	BibPoint bpWorldSize;
	BibSprite bsBackgroundPic;
	BibSprite bsEmptySprite;

//	eGameStateType eGameState;
	int nLives;
	int nLevel;
	int nScore;				// Total Score
	int nLevelScore;	// Score from this level, if completed
	float fTimeLeft;	// Time left before level expires.
	char szLevelTitle [256];

public:
	BibWorld();
	virtual ~BibWorld();

	virtual void Initialize (bool bLoadSavedData);
	virtual void UnInitialize (void);


	void SetView (BibView * inpView) { pView = inpView; }
	BibView * GetView (void) { return (pView); }

	// World Size methods
	int SetSize (BibPoint bpWorldSize);
	BibPoint GetSize (void);

	// Background Sprite accessor method.
	BibSprite & GetBackgroundSprite (void) { return bsBackgroundPic; }

	virtual void UpdateMovement (float fSpeedFactor);
	virtual void SetLastClick (BibPoint & bpLoc, bool bLeft);

	virtual int GetLevel (void) { return (nLevel); }
	virtual int SetLevel (int nLevel);
	virtual int IncLevel (void);
	virtual int RestartLevel (void);

	virtual int GetLives (void) { return (nLives); }
	virtual void SetLives (int innLives) { nLives = innLives; }
	virtual void IncLives (void) { nLives ++; }
	virtual void DecLives (void) { nLives --; }

	int GetScore (void) { return (nScore); }
	int GetLevelScore (void) { return (nLevelScore); }
	int SetScore (int nScore);
	int SetLevelScore (int nLevelScore);
	int IncScore (int nInc);
	int IncLevelScore (int nInc);

	float GetTimeLeft (void) { return (fTimeLeft); }
	float SetTimeLeft (float fTimeLeft);
	float IncTimeLeft (float fInc);
	float DecTimeLeft (float fDec);


	// Game State methods.
	//virtual eGameStateType GetGameState (void) { return (eGameState); }

	char * GetLevelTitle (void) { return szLevelTitle; }


	class BibBitmapServer  bbsBitmapServer;	// This shouldn't be here, but oh well.


};



