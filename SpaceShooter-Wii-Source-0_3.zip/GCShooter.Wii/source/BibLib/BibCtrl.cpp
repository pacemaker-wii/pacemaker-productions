/*

	BibControl Class

	This is the base class to control a single game object,
	e.g. hero or enemy.


*/

#include "BibWorld.h"
#include "BibCtrl.h"


void BibControl::Initialize (class BibWorld * inpWorld)
{
	nFlags = 0;
	pWorld = inpWorld;
	bMoveToNextLoc = false;
	bSelfDestruct = false;
	nHitPoints = 1;
	basSpriteData.Initialize(& inpWorld->bbsBitmapServer);
}

void BibControl::UnInitialize ()
{

}

		
bool BibControl::UpdateMovement (float fSpeedFactor)
{
	// If we get here, then someone else wants us to self destruct.
	//  If that's the case, then we shouldn't do anything.
	if (bSelfDestruct)
	{
		return (true);
	}

	bMoveToNextLoc = false;
	basSpriteData . IncFrameTime (fSpeedFactor);
	return (false);
}

BibSprite & BibControl::GetCurSprite (void)
{
	return (basSpriteData . GetCurSprite ());
}


BibPoint BibControl::GetCenter (void)
{
BibPoint bpTemp;
	bpTemp = bpSize / 2;
	return (bpMyLocation + bpTemp);
}

