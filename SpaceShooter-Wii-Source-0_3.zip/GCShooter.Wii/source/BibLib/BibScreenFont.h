/*

	BibScreenFont.h

*/

#ifndef _BIBSCREENFONT_H_
#define _BIBSCREENFONT_H_

#include "BibGraphicsDevice.h"
#include "BibSprite.h"

#define CHAR_PIXEL_MARGIN	3		// How many pixels margin do I have?

class BibScreenFont
{
private:
	BibSprite AlphabetBitmap;
	int nXLetterWidth;
	int nYLetterHeight;
	int * nCharWidths;	// Array of [128]
	int nCharsPerLine;

public:

	void Initialize (const u32 * pBMData, int nWidth, int nHeight, int nXLetterWidth, int nYLetterHeight, 
					int * nCharWidths, int nCharsPerLine);
	void DisplayText (BibGraphicsDevice & GD, int nXScreenLoc, int nYScreenLoc, const char * szText);


};
#endif
