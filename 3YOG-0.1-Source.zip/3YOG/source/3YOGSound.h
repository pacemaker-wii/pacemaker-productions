/*

	YOGSound.h

*/

#include "BibLib/BibSound.h"

class YOGSound : public BibSound
{
private:

public:
	YOGSound ();

	enum eSounds { SND_OUCH, SND_CLICK, MP3_TEA_AND_CRUMPETS };

	int PlaySound (eSounds eThisSound);

};
