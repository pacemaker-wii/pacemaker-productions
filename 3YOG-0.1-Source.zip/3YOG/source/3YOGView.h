// YOGView.h: interface for the YOGView class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <wiisprite.h>
#include "BibLib/BibScreenFont.h"
#include "BibLib/BibFrameRate.h"
#include "SliderOb.h"
#include "wsp_Console.h"

class YOGView
{
private:
	BibScreenFont Tahoma_ScreenFont;
	BibScreenFont Perpetua_ScreenFont;
	class YOGWorld * pWorld;
	wsp_Console wspConsole;

	wsp::Sprite SplashScreenSprite;
	wsp::Sprite PaceMakerSplashScreenSprite;
	wsp::Sprite RedPixelSprite;
	wsp::Sprite BackgroundStarsSprite;

	int nBackgroundRotation;

	SliderOb XSlider;
	SliderOb YSlider;
	SliderOb ZSlider;
	SliderOb CPUSlider;
	
public:
	BibFrameRate fps;

public:
	YOGView();
	~YOGView();

	void Initialize (void);
	void Render (void);
	void SetWorld (class YOGWorld * pinWorld) { pWorld = pinWorld; }

};

