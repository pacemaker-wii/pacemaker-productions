// DynamicWorld


#include <Box2d.h>


class DynamicWorld
{
private:
	class MyContactListener : public b2ContactListener 
	{
	private:
		class DynamicWorld * pDWorld;
	public:
		MyContactListener(class DynamicWorld * pDWorld);
		void Add(const b2ContactPoint* point);
		void Persist(const b2ContactPoint* point);
		void Remove(const b2ContactPoint* point);
		void Result(const b2ContactResult* point);
	};


	enum eObjectTypes { OBJ_WALL, // Static outside wall/ground objects.  Do not remove.
						OBJ_INTERNAL_WALL, // Static internal wall
						OBJ_DYNAMIC, // Generic dynamic object
						OBJ_BALL, OBJ_TARGET, // Ball and target
						OBJ_PUSHER, OBJ_BURST, 	// Pushers and Bursts
						OBJ_JOINT
						};
	struct UserDataStruct
	{
		wsp::Sprite * pSprite;
		eObjectTypes eObjectType;
		int nObjectNumber;
	};

private:
	b2AABB worldAABB;
	b2World * dynamic_world;
	b2Body * pSpriteBodyIterator;
	b2Joint * pLineJointIterator;
	b2Body * pBallBody;
	b2Body * pTargetBody;
	MyContactListener * pMyContactListener;

	int nObjectCounter;
	bool bBallHitTarget;
	int nBallContactCounter;


	// In these creation routines, the xyLoc are centers of the objects.
	//!!!! This needs to be generic.
	void CreateDynamicBallBody (int xLoc, int yLoc);

	// Create Generic Static bodies
	void CreateStaticBoxBody (int xLoc, int yLoc, int nWidth, int nHeight, int nAngle, eObjectTypes eType, wsp::Image * pImage);
	void CreateStaticCircularBody (int xLoc, int yLoc, int nRadius, eObjectTypes eType, wsp::Image * pImage);

	// Create Generic Dynamic bodies
	void CreateDynamicBody (int xLoc, int yLoc, int nWidth, int nHeight, int nAngle, eObjectTypes eType, wsp::Image * pImage);
	void CreateDynamicBarbellBody (int xLoc, int yLoc, int nRadius, int nAngle, eObjectTypes eType, wsp::Image * pImage);
	void CreateDynamicBoxBody (int xForce, int yForce, int xLoc, int yLoc, int nWidth, int nHeight, int nAngle, eObjectTypes eType, wsp::Image * pSprite);


	void CleanLevel (void);
	
	// Level Creation Routines
	void CreateTowerLevel (void);
	void CreateBarBlockedLevel (void);
	void CreateComplicated1Level (void);
	void CreatePic1Level (void);
	void CreateRandomLevel (void);
	void ChooseRandomCenter (int xTargetCenter, int yTargetCenter, int & xCenter, int & yCenter);
	void CreateRain(void);



	wsp::Sprite * SetupSprite (b2Body * pBody);
	wsp::Sprite * SetupLine (b2Joint * pJoint, int & xLoc1, int & yLoc1, int & xLoc2, int & yLoc2);

public:
	DynamicWorld ();

	void InitializeDynamics (void);
	bool StepDynamicWorld (float fSpeedFactor);
	
	
	wsp::Sprite * GetFirstSprite (void);
	wsp::Sprite * GetNextSprite (void);
	wsp::Sprite * GetFirstLine (int & xLoc1, int & yLoc1, int & xLoc2, int & yLoc2);
	wsp::Sprite * GetNextLine (int & xLoc1, int & yLoc1, int & xLoc2, int & yLoc2);
	wsp::Sprite * GetBallBodySprite (void);
	wsp::Sprite * GetTargetBodySprite (void);

	int GetBallContactCounter (void) { return nBallContactCounter; }

	// External object creation methods
	void CreateBurst (int xLoc, int yLoc, int nAngle);
	void CreatePusher (int xForce, int yForce, int xLoc, int yLoc, int nAngle);


	void ApplyForce (int xLoc, int yLoc);

	void CreateLevel (int nLevel);

	void TranslateDWorldToScreen (int dwX, int dwY, int & sX, int & sY);

};
