/*

	HeroControl Class

*/

#pragma once

#include "CtrlOb.h"


class HeroCtrl : public ControlOb
{

private:
	int MyHeroNum;
	int MyAngle;
	int MyDistance;
	bool bInfoValid;
	class YOGWorld * pWorld;

	int WiiFireAction;
	int WiiForceAction;
	int WiiBombAction;
	void CheckForFiring (float fSpeedFactor);

	bool bDrawLine;

	int nScore;
	int nPushersLeft;
	int nBurstsLeft;

public:
	HeroCtrl ();
	~HeroCtrl ();


	void Initialize (class YOGWorld * pWorld, int nHeroNum);
	void Reset (void);
	void ResetForNewLevel (void);
	void UnInitialize ();

	// This is called very often to have the object move, etc.
	bool UpdateMovement (float fSpeedFactor);

	wsp::Sprite * GetCurSprite (void);
	void GetLocation (int & x, int & y, int & z, int & angle);
	
	bool IsActive (void);
	bool DrawLine (void) { return bDrawLine; }
	
	
	int GetPushersLeft (void) { return nPushersLeft; }
	int GetBurstsLeft (void) { return nBurstsLeft; }
	
	int GetScore (void) { return nScore; }
	void IncScore (int nAddScore) { nScore += nAddScore; }
};


