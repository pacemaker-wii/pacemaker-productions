// GameConstants.h

/*
	Version Number to display
*/
#define GAME_VERSION "Version: 0.1, " __DATE__

/*
	PRODUCTION switch (i.e. no debugging stuff)
*/
#define PRODUCTION
//#undef PRODUCTION	// Not in production mode...in debug/development mode.



// These are constants/ranges for the time-independent movement
// stuff.
#define EXPECT_FRAMES_PER_SECOND		60		// Keep at 60 for sprite animation



#define GAME_OVER_WAIT_TIME 12
#define START_OF_LEVEL_WAIT_TIME (6 * 60)
#define END_OF_LEVEL_WAIT_TIME (6 * 60)
#define PACEMAKER_SPLASHSCREEN_WAIT_TIME (60 * 60)


#define END_OF_LEVEL_SCORE_BONUS 100
