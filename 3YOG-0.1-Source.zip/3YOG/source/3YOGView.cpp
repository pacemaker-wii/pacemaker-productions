// YOGView.h: interface for the YOGView class.
//
//////////////////////////////////////////////////////////////////////

#include "3YOGView.h"
#include "3YOGWorld.h"
#include "BibLib/BibGraphicsHelper.h"
#include "ImageServer.h"

#include "sprites/TahomaFont_16_White_metrics.sprite.h" 
#include "sprites/TahomaFont_16_Black_metrics.sprite.h" 
#include "sprites/Perpetua_48_Blue_metrics.sprite.h" 


extern int nDebugCounterR;
extern int nDebugCounterL;

YOGView::YOGView()
{
}

YOGView::~YOGView()
{
}


static int nFrameCounter = 0;



void YOGView::Initialize (void)
{
	Tahoma_ScreenFont . Initialize (isImageServer.GetTahomaBlackFontImage (), 
									isImageServer.GetTahomaBlackFontImage ()->GetWidth() / 16, 
									isImageServer.GetTahomaBlackFontImage ()->GetHeight() / 16, 
									TahomaFont_16_Black_metrics);

	Perpetua_ScreenFont . Initialize (isImageServer.GetPerpetuaFont_48_BlueImage (), 
									isImageServer.GetPerpetuaFont_48_BlueImage ()->GetWidth() / 16, 
									isImageServer.GetPerpetuaFont_48_BlueImage ()->GetHeight() / 16, 
									Perpetua_48_Blue_metrics);

	PaceMakerSplashScreenSprite.SetImage (isImageServer.GetPaceMakerSplashScreenImage ());
	SplashScreenSprite.SetImage (isImageServer.GetSplashScreenImage ());
	RedPixelSprite.SetImage (isImageServer.GetRedPixelImage ());
	BackgroundStarsSprite.SetImage (isImageServer.GetBackgroundStarsImage ());
	BackgroundStarsSprite.SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);
	nBackgroundRotation = 0;
	
	XSlider.Initialize (SliderOb::SLIDER_HORIZONTAL);
	YSlider.Initialize (SliderOb::SLIDER_HORIZONTAL);
	ZSlider.Initialize (SliderOb::SLIDER_HORIZONTAL);
	CPUSlider.Initialize (SliderOb::SLIDER_VERTICAL);

	XSlider.SetRange (0, 255);
	XSlider.SetPosition (0);
	XSlider.SetTransparency (32);
	YSlider.SetRange (0, 255);
	YSlider.SetPosition (50);
	YSlider.SetTransparency (32);
	ZSlider.SetRange (0, 255);
	ZSlider.SetPosition (200);
	ZSlider.SetTransparency (32);
	
	CPUSlider.SetRange (0, 100);
	CPUSlider.SetPosition (100);
	CPUSlider.SetTransparency (32);

}


/*
	Render the view (to the screen)
*/
void YOGView::Render (void)
{
int xLoc1, yLoc1, xLoc2, yLoc2;
int x, y;
char szBuf [1024];
const char * pMsg;
wsp::Sprite * s;

#ifndef PRODUCTION
	if (nFrameCounter == 0)
	{
		wspConsole.InitConsole ();
		nFrameCounter ++;
	}
#endif


	// Check to see if we have been initialized.
	if (! pWorld)
		return;

	

	/*
		Set background based on game state.
	*/
	switch (pWorld -> GetGameState ())
	{
		default:
		case YOGWorld::SPLASH_SCREEN_1_WARN:
		case YOGWorld::SPLASH_SCREEN_2_SIDEWAYS:
		case YOGWorld::SPLASH_SCREEN_PACEMAKER:
			PaceMakerSplashScreenSprite.Draw();
			return;	// Don't display anything else, to preserve the purity of the PaceMaker splash screen.
		break;



		case YOGWorld::SPLASH_SCREEN:
			SplashScreenSprite.Draw();
			Tahoma_ScreenFont.DisplayText (34, 432, GAME_VERSION);
		break;



		case YOGWorld::PLAYING:
		case YOGWorld::START_OF_LEVEL:
		case YOGWorld::END_OF_LEVEL:
		case YOGWorld::GAME_OVER:
		case YOGWorld::MAIN_MENU:
			/*
				Put background bitmaps in here.
			*/
			pWorld -> GetBackgroundSprite ().Draw ();
			
			BackgroundStarsSprite.SetPosition (320,240);
			nBackgroundRotation ++;
			BackgroundStarsSprite.SetRotation ((nBackgroundRotation / 100) % 180);
			BackgroundStarsSprite.SetTransparency ((nBackgroundRotation % 20) + 64);
			BackgroundStarsSprite.Draw ();
		break;
	}
	
	
	
	/*
		Main 'playing' rendering.
	*/
	switch (pWorld -> GetGameState ())
	{
		default:
		case YOGWorld::SPLASH_SCREEN_1_WARN:
		case YOGWorld::SPLASH_SCREEN_2_SIDEWAYS:
		case YOGWorld::SPLASH_SCREEN_PACEMAKER:
		case YOGWorld::SPLASH_SCREEN:
		
		break;


		case YOGWorld::PLAYING:
		case YOGWorld::START_OF_LEVEL:
		case YOGWorld::END_OF_LEVEL:
		case YOGWorld::GAME_OVER:
		case YOGWorld::MAIN_MENU:
			if (pWorld -> GetGameState () != YOGWorld::SPLASH_SCREEN)
			{
				int ax, ay, az, angle;
				bool bStatus;
				
				
				/*
					Update and Draw Sliders
				*/
				bStatus = pWorld->WiiInputDevice.Wii_Acceleration (WPAD_CHAN_0, ax, ay, az);
				if (bStatus)
				{
					XSlider.SetPosition (ax);
					YSlider.SetPosition (ay);
					ZSlider.SetPosition (az);
				}

				// Display CPU Busy graph.
				int nPercent = fps.GetFlushMicroSecs() / 167;
				if (nPercent < 0)
					nPercent = 0;
				if (nPercent > 100)
					nPercent = 100;
				CPUSlider.SetPosition (100 - nPercent);

				XSlider.Render (Tahoma_ScreenFont, 20, 200);
				YSlider.Render (Tahoma_ScreenFont, 20, 260);
				ZSlider.Render (Tahoma_ScreenFont, 20, 320);

				CPUSlider.Render (Tahoma_ScreenFont, 300, 30);


				/*
					Draw Ghost Balls.
				*/
				if (pWorld->GetBallBodySprite ())
				{
					YOGWorld::GhostBallQueueIteratorType it;
					YOGWorld::GhostBallQueueType * q = pWorld->GetGhostBallQueue();
					
					int nTrans = 4;
					for(it = q->begin(); it != q->end(); it++)
					{
						wsp::Sprite * s = pWorld->GetBallBodySprite ();
						s->SetPosition ((*it)->x, (*it)->y);
						s->SetTransparency (nTrans += 4);
						s->Draw ();
						s->SetTransparency (255);// Set back to fully opaque for Good luck.
					}
				}

				/*
					Draw all world sprites (Dynamic world)
				*/
				s = pWorld->DWorld.GetFirstSprite();
				while (s)
				{
					s->Draw ();
					s = pWorld->DWorld.GetNextSprite();
				}

				/*
					Draw all world lines (Dynamic world)
				*/
				s = pWorld->DWorld.GetFirstLine(xLoc1, yLoc1, xLoc2, yLoc2);
				while (s)
				{
					BibGraphicsHelper::DrawLine (xLoc1, yLoc1, xLoc2, yLoc2, &RedPixelSprite);
					s = pWorld->DWorld.GetNextLine(xLoc1, yLoc1, xLoc2, yLoc2);
				}




				/*
					Draw all Hero (cursor) data
				*/
				for (int i = 0; i < NUM_HEROES; i ++)
				{
					// Don't draw for a Hero if it's controller is not active.
					if (! pWorld->GetHeroCtrl(i)->IsActive())
						continue;
					
					// Draw a cursor for the Hero.
					pWorld->GetHeroCtrl(i)->GetLocation (ax, ay, az, angle);
					wsp::Sprite * s = pWorld->GetHeroCtrl(i)->GetCurSprite ();
					s->Draw();

					// Draw a line from the cursor to the ball body.
					if (pWorld->GetHeroCtrl(i)->DrawLine())
					{
						s = pWorld->DWorld.GetBallBodySprite ();
						if (s)
						{
							BibGraphicsHelper::DrawLine (s->GetX(), s->GetY(), ax, ay, &RedPixelSprite);
						}
					}
				
				}
				
				for (int i = 0; i < NUM_HEROES; i ++)
				{
					if (! pWorld->GetHeroCtrl(i)->IsActive())
						continue;

					sprintf (szBuf, "P%d: Score: %d, Pushers: %d, Bursts: %d", i + 1, 
						pWorld->GetHeroCtrl(i)->GetScore(), pWorld->GetHeroCtrl(i)->GetPushersLeft(),
						pWorld->GetHeroCtrl(i)->GetBurstsLeft ());
					Tahoma_ScreenFont.DisplayText (40, 400 - (20 * i), szBuf);
				}

				sprintf (szBuf, "Time Elapsed %0.2f", pWorld->GetLevelTimeElapsed ());
				Tahoma_ScreenFont.DisplayText (40, 420, szBuf);
			}

			/*
				Display the level number.
			*/
			
			sprintf (szBuf, "%0 d", pWorld -> GetLevel ());
			Perpetua_ScreenFont.DisplayText (550, 25, szBuf);

		break;
	}



	
	/*
		Display a Banner text if found.
	*/
	pMsg = pWorld -> GetLevelBannerText ();
	if (pMsg)
	{
		pWorld -> GetLevelBannerPosition (x, y);
		Perpetua_ScreenFont.DisplayText (x, y, pMsg);
	}



	/*
		Display debug text.
	*/
	if (pWorld->IsDebugOn())
	{
		/*
			Show PAD Inputs and frame numbers.
		*/

		sprintf (szBuf, "(%d)", nFrameCounter ++);
		Tahoma_ScreenFont.DisplayText (40, 50, szBuf);


		sprintf (szBuf, "nDCL(%d) nDCR(%d)", nDebugCounterL, nDebugCounterR);
		Tahoma_ScreenFont.DisplayText (40, 340, szBuf);


		extern char szDynamicWorldMsg1 [256];
		extern char szDynamicWorldMsg2 [256];
		if (szDynamicWorldMsg1 [0])
				Tahoma_ScreenFont.DisplayText (40, 35, szDynamicWorldMsg1);
		if (szDynamicWorldMsg2 [0])
				Tahoma_ScreenFont.DisplayText (40, 65, szDynamicWorldMsg2);

		extern char szHeroMsg [256];
		if (szHeroMsg [0])
				Tahoma_ScreenFont.DisplayText (40, 122, szHeroMsg);

		extern char szWiiInputDeviceMsg2 [128];
		extern char szWiiInputDeviceMsg4 [128];
		Tahoma_ScreenFont.DisplayText (40, 82, szWiiInputDeviceMsg2);
		Tahoma_ScreenFont.DisplayText (40, 98, szWiiInputDeviceMsg4);
	}	// End if (bDebugOn)




	
	/*
		Main Menu Display
	*/
	if (pWorld -> GetGameState () == YOGWorld::MAIN_MENU)
	{
		pWorld -> TheMainMenu.DisplayListBox ();
	}


	/*
		Put fps information at the bottom of this function
		so it won't be greyed out when the menu is active.
	*/
	if (pWorld->IsDebugOn())
	{
		/*
			Put the fps at the bottom.
		*/
		sprintf (szBuf, "fps %02.2f, min fps %02.2f (Extra Time: %04d us (%02d %%))", fps.fps, fps.fMinFPS, fps.GetFlushMicroSecs(), fps.GetFlushMicroSecs() / 167);
		Tahoma_ScreenFont.DisplayText (40, 380, szBuf);
	}


#ifdef DEBUG_BIBSOUND
	extern char szDebugMsg3 [256];
	extern char szDebugMsg2 [256];
	extern char szDebugMsg1 [256];
	Tahoma_ScreenFont.DisplayText (40, 200, szDebugMsg1);
	Tahoma_ScreenFont.DisplayText (40, 220, szDebugMsg2);
	Tahoma_ScreenFont.DisplayText (40, 240, szDebugMsg3);
#endif



#ifndef PRODUCTION
	wspConsole.RenderConsole ();
#endif

}



