/*

	Control Object Class

	This is the base class to control a single game object,
	e.g. hero or enemy.

*/

#pragma once

#include "BibLib/BibPoint.h"


class ControlOb
{
protected:
	wsp::Sprite sSpriteData;
	class YOGWorld * pWorld;

	bool bSelfDestruct;

	BibPoint bpMyLocation;

public:

	virtual void Initialize (class YOGWorld * pWorld);
	virtual void UnInitialize (void);

	wsp::Sprite * GetCurSprite (void);

	// This is called very often to have the object move, etc.
	virtual bool UpdateMovement (float fSpeedFactor);

};

