// YOGWorld.h: interface for the YOGWorld class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <queue>
#include <list>

#include "GameConstants.h"
#include "BibLib/BibWiiInputDevice.h"
#include "BibLib/BibPoint.h"

#include "3YOGView.h"
#include "3YOGSound.h"
#include "3YOGMainMenu.h"
#include "HeroCtrl.h"
#include "DynamicWorld.h"

#define NUM_HEROES 4
#define MAX_GHOST_BALLS	20

class YOGWorld
{
public:	
	enum eGameStateType { SPLASH_SCREEN_1_WARN, SPLASH_SCREEN_2_SIDEWAYS, SPLASH_SCREEN_PACEMAKER, 
	                      SPLASH_SCREEN, PLAYING, START_OF_LEVEL, END_OF_LEVEL, GAME_OVER, MAIN_MENU
						};

	typedef std::deque<BibPoint *> GhostBallQueueType;
	typedef std::deque<BibPoint *>::iterator GhostBallQueueIteratorType;

	BibWiiInputDevice WiiInputDevice;

	MainMenu	TheMainMenu;
	bool bDebugOn;

	// Sounds object
	YOGSound pSound;


private:
	class YOGView * pView;
	wsp::Sprite bsBackgroundPic;

	HeroCtrl Heroes [NUM_HEROES];

	GhostBallQueueType qGhostBalls;

	// From WiiInputDevice ActionMap
	//   To skip splash screen.
	int WiiSplashScreenAction;
	//   !!!! For Debug.
	int WiiButtonMinusAction;
	int WiiButtonPlusAction;
	
	float fLevelTimeElapsed;

	eGameStateType eGameState;
	eGameStateType eSaveGameState;
	float fNextStateTime;
	int nGameStateCounter;
	int nLevel;

	void Reset (void);
	void CreateLevel (int nLevel);
	void IncrementHeroScoresAtEndOfLevel (void);



public:
	YOGWorld();
	virtual ~YOGWorld();

	void Initialize (int nWidth, int nHeight);
	void UnInitialize (void);


	void SetView (YOGView * inpView) { pView = inpView; }
	YOGView * GetView (void) { return (pView); }

	// Background Sprite accessor method.
	wsp::Sprite & GetBackgroundSprite (void) { return bsBackgroundPic; }


	DynamicWorld DWorld;


	void UpdateMovement (float fSpeedFactor);

	bool IsDebugOn() { return (bDebugOn); }

	// Game State methods.
	eGameStateType GetGameState (void) { return (eGameState); }
	void SetGameState (eGameStateType ineGameState) { eGameState = ineGameState; }
	void PushGameState (eGameStateType GameState);
	eGameStateType PopGameState (void);
	
	HeroCtrl * GetHeroCtrl (int nHero);
	float GetLevelTimeElapsed (void) { return (fLevelTimeElapsed); }

	int GetLevel (void) { return nLevel; }
	const char * GetLevelBannerText (void);
	void GetLevelBannerPosition (int & x, int & y);

	GhostBallQueueType * GetGhostBallQueue (void) { return & qGhostBalls; }
	wsp::Sprite * GetBallBodySprite (void) { return DWorld.GetBallBodySprite (); }


	// Debug Function.
	void SkipLevel (void);


public:
	//	Level loading functions:

	void DeleteAllObjects (void);

};
