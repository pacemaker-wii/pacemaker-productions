/*

	ControlOb Class

	This is the base class to control a single game object,
	e.g. hero or enemy.


*/

#include "3YOGWorld.h"
#include "CtrlOb.h"


void ControlOb::Initialize (class YOGWorld * inpWorld)
{
	pWorld = inpWorld;
	bSelfDestruct = false;
}

void ControlOb::UnInitialize ()
{

}

		
bool ControlOb::UpdateMovement (float fSpeedFactor)
{
	// If we get here, then someone else wants us to self destruct.
	//  If that's the case, then we shouldn't do anything.
	if (bSelfDestruct)
	{
		return (false);
	}

	// If there is a standard sprite animation, we could
	//  update the sprite data with fSpeedFactor.

	return (true);
}

wsp::Sprite * ControlOb::GetCurSprite (void)
{
	return (& sSpriteData);
}

