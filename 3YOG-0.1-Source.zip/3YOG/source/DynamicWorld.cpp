// DynamicWorld



#include <wiisprite.h>
#include "ImageServer.h"
#include "DynamicWorld.h"

//!!!! For Debug
char szDynamicWorldMsg1 [256] = {0};
char szDynamicWorldMsg2 [256] = {0};

/*
	Basic world and body defines.
*/

#define WORLD_EDGE_BUFFER	100
#define WORLD_WIDTH	640
#define WORLD_HEIGHT 480

#define GROUND_WIDTH (WORLD_WIDTH)
#define GROUND_HEIGHT (20)

#define WALL_WIDTH (20)
#define WALL_HEIGHT (480)




/*

	MyContactListener object.




*/
DynamicWorld::MyContactListener::MyContactListener(DynamicWorld * _pDWorld)
{
	pDWorld = _pDWorld;
}


void DynamicWorld::MyContactListener::Add(const b2ContactPoint* point)
{
	if (! pDWorld)
		return;
	
	if (! pDWorld->pBallBody)
		return;
	
	if (! point->shape1)
		return;

	if (! point->shape2)
		return;


	if ((point->shape1->GetBody() == pDWorld->pBallBody) &&
		(point->shape2->GetBody() == pDWorld->pTargetBody))
	{
		sprintf (szDynamicWorldMsg1, "Ball-Target Contact!");
		pDWorld->bBallHitTarget = true;
	}

	if ((point->shape2->GetBody() == pDWorld->pBallBody) &&
		(point->shape1->GetBody() == pDWorld->pTargetBody))
	{
		sprintf (szDynamicWorldMsg1, "Target-Ball Contact!");
		pDWorld->bBallHitTarget = true;
	}

	if ((point->shape1->GetBody() == pDWorld->pBallBody) ||
		(point->shape2->GetBody() == pDWorld->pBallBody))
	{
		pDWorld->nBallContactCounter ++;
	}

}

void DynamicWorld::MyContactListener::Persist(const b2ContactPoint* point)
{

}

void DynamicWorld::MyContactListener::Remove(const b2ContactPoint* point)
{

}

void DynamicWorld::MyContactListener::Result(const b2ContactResult* point)
{

}






DynamicWorld::DynamicWorld ()
{
	pBallBody = NULL;
	pTargetBody = NULL;
	bBallHitTarget = false;
	nObjectCounter = 0;
	nBallContactCounter = 0;
}


void DynamicWorld::InitializeDynamics (void)
{
	
	// World Bounding Box
	worldAABB.lowerBound.Set((0 - WORLD_EDGE_BUFFER), (0 - WORLD_EDGE_BUFFER));
	worldAABB.upperBound.Set((WORLD_WIDTH + WORLD_EDGE_BUFFER), (WORLD_HEIGHT + WORLD_EDGE_BUFFER));

	// Gravity Vector
	b2Vec2 gravity(0.0f, 0.0f);

	// Create Box2d World object.
	dynamic_world = new  b2World(worldAABB, gravity, true);

	// Create contact listener to determine ball-to-target collisions.
	pMyContactListener = new MyContactListener (this);
	dynamic_world->SetContactListener(pMyContactListener);


	// Define the left wall body.
	CreateStaticBoxBody (10,				WALL_HEIGHT / 2,	WALL_WIDTH, WALL_HEIGHT, 0, OBJ_WALL, isImageServer.GetBar4x4Image());

	// Define the right wall body.
	CreateStaticBoxBody (WORLD_WIDTH - 10, WALL_HEIGHT / 2,	WALL_WIDTH,	WALL_HEIGHT, 0, OBJ_WALL, isImageServer.GetBar4x4Image());

	// Define the ground body.
	CreateStaticBoxBody (WORLD_WIDTH / 2, 	0, 					GROUND_WIDTH, GROUND_HEIGHT, 0, OBJ_WALL, isImageServer.GetBar4x4Image());

	// Define the ceiling body.
	CreateStaticBoxBody (WORLD_WIDTH / 2, 	WORLD_HEIGHT - 10, 	GROUND_WIDTH, GROUND_HEIGHT, 0, OBJ_WALL, isImageServer.GetBar4x4Image());
}


// XY Location is the center of the body.
// Width and Height is the full width/height of the body.
// Angle is in degrees.
void DynamicWorld::CreateStaticBoxBody (int xLoc, int yLoc, int nWidth, int nHeight, int nAngle, eObjectTypes eType, wsp::Image * pImage)
{
b2BodyDef groundBodyDef;
b2PolygonDef groundShapeDef;
b2Body* groundBody;
wsp::Sprite * BodySprite;

	/*
		Define the right wall body.
	*/
	groundBodyDef.position.Set(xLoc, yLoc);
	groundBodyDef.angle = nAngle * 3.14159 / 180;

	// Call the body factory which allocates memory for the ground body
	// from a pool and creates the ground box shape (also from a pool).
	// The body is also added to the world.
	groundBody = dynamic_world->CreateBody(&groundBodyDef);

	// Define the ground box shape.
	// The extents are the half-widths of the box.
	groundShapeDef.SetAsBox(nWidth / 2.0, nHeight / 2.0);
	groundShapeDef.restitution = 1.0f;

	// Add the ground shape to the ground body.
	groundBody->CreateShape(&groundShapeDef);

	// Create the sprite to represent the ground.
	BodySprite = new wsp::Sprite;
	BodySprite->SetImage (pImage);
	BodySprite->SetStretchWidth (((float) nWidth) / BodySprite->GetImage()->GetWidth());
	BodySprite->SetStretchHeight (((float) nHeight) / BodySprite->GetImage()->GetHeight());
	BodySprite->SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);

	
	UserDataStruct * pUds = new UserDataStruct ();
	pUds->pSprite = BodySprite;
	pUds->eObjectType = eType;
	pUds->nObjectNumber = nObjectCounter ++;
	groundBody->SetUserData (pUds);
	
}


void DynamicWorld::CreateStaticCircularBody (int xLoc, int yLoc, int nRadius, eObjectTypes eType, wsp::Image * pImage)
{
b2BodyDef groundBodyDef;
b2CircleDef targetShapeDef;
wsp::Sprite * BodySprite;
b2Body * pBody;

	/*
		Define the right wall body.
	*/
	groundBodyDef.position.Set(xLoc, yLoc);

	// Call the body factory which allocates memory for the ground body
	// from a pool and creates the ground box shape (also from a pool).
	// The body is also added to the world.
	pBody = dynamic_world->CreateBody(&groundBodyDef);

	// Define the ground box shape.
	// The extents are the half-widths of the box.
	targetShapeDef.radius = nRadius;
	targetShapeDef.restitution = 1.0f;
	
	// Add the ground shape to the ground body.
	pBody->CreateShape(&targetShapeDef);

	// Create the sprite to represent the shape.
	BodySprite = new wsp::Sprite;
	BodySprite->SetImage (pImage);
	BodySprite->SetStretchWidth (nRadius * 2.0f / BodySprite->GetImage()->GetWidth());
	BodySprite->SetStretchHeight (nRadius * 2.0f / BodySprite->GetImage()->GetHeight());
	BodySprite->SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);

	// Setup User Data.
	UserDataStruct * pUds = new UserDataStruct ();
	pUds->pSprite = BodySprite;
	pUds->eObjectType = eType;
	pUds->nObjectNumber = nObjectCounter ++;
	pBody->SetUserData (pUds);
	
	if (eType == OBJ_TARGET)
		pTargetBody = pBody;

}



void DynamicWorld::CreateDynamicBallBody (int xLoc, int yLoc)
{
b2BodyDef bodyDef;
b2PolygonDef shapeDef;
b2Body * body;
b2Vec2 center(5, 5);


	bodyDef.position.Set(xLoc, yLoc);
	bodyDef.isBullet = true;
	body = dynamic_world->CreateBody(&bodyDef);


	shapeDef.SetAsBox(10 / 2, 10 / 2);
	shapeDef.density = 1.0f;
	shapeDef.friction = 0.1f;
	shapeDef.restitution = 1.0f;
	body->CreateShape(&shapeDef);
	body->SetMassFromShapes();
	

	wsp::Sprite * BodySprite = new wsp::Sprite;
	BodySprite->SetImage (isImageServer.GetBallImage ());
	BodySprite->SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);

	UserDataStruct * pUds = new UserDataStruct ();
	pUds->pSprite = BodySprite;
	pUds->eObjectType = OBJ_BALL;
	pUds->nObjectNumber = nObjectCounter ++;
	body->SetUserData (pUds);

	pBallBody = body;
}



void DynamicWorld::CreatePusher (int xForce, int yForce, int xLoc, int yLoc, int nAngle)
{
	CreateDynamicBoxBody (xForce, yForce, xLoc, yLoc, 20, 10, nAngle, OBJ_PUSHER, isImageServer.GetDotImage ());
}

/*
	Create pusher object.
*/
void DynamicWorld::CreateDynamicBoxBody (int xForce, int yForce, int xLoc, int yLoc, int nWidth, int nHeight, int nAngle, eObjectTypes eType, wsp::Image * pSprite)
{
b2BodyDef bodyDef;
b2PolygonDef shapeDef;
b2Body * body;


	bodyDef.position.Set(xLoc, yLoc);
	bodyDef.angle = nAngle * 3.14159 / 180;
	body = dynamic_world->CreateBody(&bodyDef);


	shapeDef.SetAsBox(nWidth / 2, nHeight / 2);
	shapeDef.density = 1.0f;
	shapeDef.friction = 0.1f;
	shapeDef.restitution = 1.0f;
	body->CreateShape(&shapeDef);
	body->SetMassFromShapes();
	
	
	wsp::Sprite * BodySprite = new wsp::Sprite;
	BodySprite->SetImage (pSprite);
	BodySprite->SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);
	BodySprite->SetStretchWidth ((float) nWidth / BodySprite->GetImage()->GetWidth());
	BodySprite->SetStretchHeight ((float) nHeight / BodySprite->GetImage()->GetHeight());

	UserDataStruct * pUds = new UserDataStruct ();
	pUds->pSprite = BodySprite;
	pUds->eObjectType = eType;
	pUds->nObjectNumber = nObjectCounter ++;
	body->SetUserData (pUds);
	
	b2Vec2 force(xForce, yForce);
		
	body->ApplyImpulse(force, body->GetWorldCenter());

}



void DynamicWorld::CreateBurst (int xLoc, int yLoc, int nAngle)
{
	CreateDynamicBoxBody (0, 0, xLoc, yLoc, 4, 4, nAngle, OBJ_BURST, isImageServer.GetBlueDotImage ());
}



void DynamicWorld::CreateDynamicBarbellBody (int xLoc, int yLoc, int nRadius, int nAngle, eObjectTypes eType, wsp::Image * pImage)
{
b2BodyDef bodyDef;
b2PolygonDef shapeDef;
b2Body * body1;
b2Body * body2;
wsp::Sprite * BodySprite;
UserDataStruct * pUds;


	// Create two identical bodies.
	bodyDef.position.Set(xLoc, yLoc);
	bodyDef.angle = nAngle * 3.14159 / 180;
	body1 = dynamic_world->CreateBody(&bodyDef);
	bodyDef.position.Set(xLoc + nRadius * 2, yLoc);
	body2 = dynamic_world->CreateBody(&bodyDef);


	// Attach two identical shapes.
	shapeDef.SetAsBox(20 / 2.0f, 10 / 2.0f);
	shapeDef.density = 1.0f;
	shapeDef.friction = 0.1f;
	shapeDef.restitution = 1.0f;
	body1->CreateShape(&shapeDef);
	body1->SetMassFromShapes();
	body2->CreateShape(&shapeDef);
	body2->SetMassFromShapes();
	
	
	// Add the sprite to the body1
	BodySprite = new wsp::Sprite;
	BodySprite->SetImage (isImageServer.GetDotImage ());
	BodySprite->SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);
	BodySprite->SetStretchWidth (nRadius / BodySprite->GetImage()->GetWidth());
	BodySprite->SetStretchHeight (nRadius / BodySprite->GetImage()->GetHeight());

	pUds = new UserDataStruct ();
	pUds->pSprite = BodySprite;
	pUds->eObjectType = OBJ_PUSHER;
	pUds->nObjectNumber = nObjectCounter ++;
	body1->SetUserData (pUds);
	
	
	
	// Add the sprite to the body2
	BodySprite = new wsp::Sprite;
	BodySprite->SetImage (isImageServer.GetDotImage ());
	BodySprite->SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);
	BodySprite->SetStretchWidth (nRadius / BodySprite->GetImage()->GetWidth());
	BodySprite->SetStretchHeight (nRadius / BodySprite->GetImage()->GetHeight());

	pUds = new UserDataStruct ();
	pUds->pSprite = BodySprite;
	pUds->eObjectType = OBJ_PUSHER;
	pUds->nObjectNumber = nObjectCounter ++;
	body2->SetUserData (pUds);



	b2DistanceJointDef djd;
	djd.body1 = body1;
	djd.body2 = body2;
	djd.localAnchor1.Set(0.0f, 0.0f);
	djd.localAnchor2.Set(0.0f, 0.0f);
	b2Vec2 d = djd.body2->GetWorldPoint(djd.localAnchor2) - djd.body1->GetWorldPoint(djd.localAnchor1);
	djd.length = d.Length();
	b2Joint * pJoint = dynamic_world->CreateJoint(&djd);






	// Add the sprite to the joint
	BodySprite = new wsp::Sprite;
	BodySprite->SetImage (isImageServer.GetRedPixelImage ());
	BodySprite->SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);
	BodySprite->SetStretchWidth (100 / BodySprite->GetImage()->GetWidth());
	BodySprite->SetStretchHeight (100 / BodySprite->GetImage()->GetHeight());

	pUds = new UserDataStruct ();
	pUds->pSprite = BodySprite;
	pUds->eObjectType = OBJ_JOINT;
	pUds->nObjectNumber = nObjectCounter ++;
	pJoint->SetUserData (pUds);

	//!!!! Temp
	body2->ApplyImpulse(b2Vec2 (0, 10000.0f), body2->GetWorldCenter());

}


void DynamicWorld::ApplyForce (int xLoc, int yLoc)
{
	if (! pBallBody)
		return;

	b2Vec2 force((xLoc - pBallBody->GetWorldCenter().x) * 500.0f, (yLoc - pBallBody->GetWorldCenter().y) * 500.0f);
	b2Vec2 loc(xLoc, yLoc);
	
	pBallBody->ApplyForce(force, loc);
}


bool DynamicWorld::StepDynamicWorld (float fFrameTimeDelta)
{
	if (fFrameTimeDelta > 0.1f)
		fFrameTimeDelta = 0.1f;
	dynamic_world->Step((1.0f / 60.0f) /*fFrameTimeDelta*/, 50);
	
	return (bBallHitTarget);
}



wsp::Sprite * DynamicWorld::SetupSprite (b2Body * pBody)
{
int sx, sy;
UserDataStruct * pUds;

	pUds = (UserDataStruct *) pSpriteBodyIterator->GetUserData ();

	// This happens for one object, but I can't figure out what it is.
	if (! pUds)
	{
//		printf ("Found body with no UserData Structure! (0x%x)\n", pBody);
		return (NULL);
	}

	if (! pUds->pSprite)
	{
//		printf ("Found body with no sprite data!\n");
		return (NULL);
	}


	TranslateDWorldToScreen (pBody->GetWorldCenter().x, 
							 pBody->GetWorldCenter().y, 
							 sx, sy);
	pUds->pSprite->SetPosition(sx, sy);
	pUds->pSprite->SetRotation (pBody->GetAngle() * (180 / 3.14159) / 2);
	return (pUds->pSprite);
}


// Would be faster to have this do a render (Draw()),
// but that's not the function of this class.
wsp::Sprite * DynamicWorld::GetFirstSprite (void)
{
	pSpriteBodyIterator = dynamic_world->GetBodyList();
	if (pSpriteBodyIterator)
	{
		return (SetupSprite (pSpriteBodyIterator));
	}

	return (NULL);
}	
	
wsp::Sprite * DynamicWorld::GetNextSprite (void)
{
	if (pSpriteBodyIterator)
	{
		pSpriteBodyIterator = pSpriteBodyIterator -> GetNext ();
		if (pSpriteBodyIterator)
		{
			return (SetupSprite (pSpriteBodyIterator));
		}
	}

	return (NULL);
}


wsp::Sprite * DynamicWorld::SetupLine (b2Joint * pJoint, int & xLoc1, int & yLoc1, int & xLoc2, int & yLoc2)
{
UserDataStruct * pUds;

	pUds = (UserDataStruct *) pLineJointIterator->GetUserData ();

	// This happens for one object, but I can't figure out what it is.
	if (! pUds)
	{
//		printf ("Found joint with no UserData Structure! (0x%x)\n", pBody);
		return (NULL);
	}

	if (! pUds->pSprite)
	{
//		printf ("Found joint with no sprite data!\n");
		return (NULL);
	}

	TranslateDWorldToScreen (pJoint->GetBody1()->GetWorldCenter().x, 
							 pJoint->GetBody1()->GetWorldCenter().y, 
							 xLoc1, yLoc1);
	TranslateDWorldToScreen (pJoint->GetBody2()->GetWorldCenter().x, 
							 pJoint->GetBody2()->GetWorldCenter().y, 
							 xLoc2, yLoc2);
	return (pUds->pSprite);

}

wsp::Sprite * DynamicWorld::GetFirstLine (int & xLoc1, int & yLoc1, int & xLoc2, int & yLoc2)
{
	pLineJointIterator = dynamic_world->GetJointList();
	if (pLineJointIterator)
	{
		return (SetupLine (pLineJointIterator, xLoc1, yLoc1, xLoc2, yLoc2));
	}

	return (NULL);
}

wsp::Sprite * DynamicWorld::GetNextLine (int & xLoc1, int & yLoc1, int & xLoc2, int & yLoc2)
{
	if (pLineJointIterator)
	{
		pLineJointIterator = pLineJointIterator -> GetNext ();
		if (pLineJointIterator)
		{
			return (SetupLine (pLineJointIterator, xLoc1, yLoc1, xLoc2, yLoc2));
		}
	}

	return (NULL);
}


wsp::Sprite * DynamicWorld::GetBallBodySprite (void)
{
wsp::Sprite * s;
int sx, sy;

	if (! pBallBody)
		return (NULL);
		
	UserDataStruct * pUds = (UserDataStruct *) pBallBody->GetUserData ();
	if (pUds->eObjectType != OBJ_BALL)
	{
		printf ("Invalid pBallBody pointer!\n");
		return (NULL);
	}	
	
	s = pUds->pSprite;
	if (s)
	{
		TranslateDWorldToScreen (pBallBody->GetWorldCenter().x, 
								 pBallBody->GetWorldCenter().y, 
								 sx, sy);
		s->SetPosition(sx, sy);
		s->SetRotation (pBallBody->GetAngle() * (180 / 3.14159) / 2);
	}
	return (s);
}



void DynamicWorld::TranslateDWorldToScreen (int dwX, int dwY, int & sX, int & sY)
{
	sX = dwX;
	sY = dwY;
}



// Delete all non-wall/ground objects.
void DynamicWorld::CleanLevel (void)
{
b2Body* node;

	node = dynamic_world->GetBodyList();
	while (node)
	{
		b2Body* b = node;
		node = node->GetNext();
		
		UserDataStruct * pUds = (UserDataStruct *) b->GetUserData ();
		if (pUds && pUds->eObjectType != OBJ_WALL)
		{
			dynamic_world->DestroyBody(b);
			if (pUds->pSprite)
				delete (pUds->pSprite);
			delete (pUds);
		}
	}

	pTargetBody = NULL;
	pBallBody = NULL;
}


void DynamicWorld::CreateLevel (int nLevel)
{
	CleanLevel ();

	// Reset to false, and contact callbacks will set it.
	nBallContactCounter = 0;
	bBallHitTarget = false;
	sprintf (szDynamicWorldMsg1, "Reset");


	switch (nLevel)
	{
		default:
			CreateRandomLevel ();
		break;


		case -1:
			// Create Target Object.
			CreateStaticCircularBody (100, 350, 10, OBJ_TARGET, isImageServer.GetTargetImage ());

			// Create Ball Object.
			CreateDynamicBallBody (100, 300);
		break;
		
		case -2:
			// Create Target Object.
			CreateStaticCircularBody (100, 400, 10, OBJ_TARGET, isImageServer.GetTargetImage ());

			// Create Ball Object.
			CreateDynamicBallBody (100, 200);

			// Internal Walls
			CreateStaticBoxBody (320, 240, 50, 200, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
			CreateStaticBoxBody (175, 300, 240, 10, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());

			// Internal Circular Walls
			CreateStaticCircularBody (400, 100, 75, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());
			CreateStaticCircularBody (475, 175, 25, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());
			CreateStaticCircularBody (550, 300, 25, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());

		break;

		case 1:
			CreateTowerLevel ();
		break;

		case 2:
			CreateBarBlockedLevel ();
		break;

		case 3:
			CreateComplicated1Level ();
		break;

		case 4:
			CreatePic1Level ();
		break;
		
		
		
	}
}



void DynamicWorld::CreateTowerLevel (void)
{
	/*		
	0	25	50	75	100	125	150	175	200	225	250	275	300	325	350	375	400	425	450	475	500	525	550	575	600	625	650
	0											W						W										
	25											W						W										
	50											W						W										
	75											W			B			W										
	100											W						W										
	125											W						W										
	425											W			T			W										
	450											W						W										
	475											W	W	W	W	W	W	W										
	500																											
	*/
	
	// Create Target Object.
	CreateStaticCircularBody (325, 75, 10, OBJ_TARGET, isImageServer.GetTargetImage ());

	// Create Ball Object.
	CreateDynamicBallBody (325, 400);

	// Internal Walls
	CreateStaticBoxBody (250, 240, 15, 475, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	CreateStaticBoxBody (400, 240, 15, 475, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	CreateStaticBoxBody (325, 470, 150, 15, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	
	
	CreateDynamicBarbellBody (100, 100, 25, 0, OBJ_DYNAMIC, isImageServer.GetGreenCircleImage ());

}

void DynamicWorld::CreateBarBlockedLevel (void)
{
/*		
0	25	50	75	100	125	150	175	200	225	250	275	300	325	350	375	400	425	450	475	500	525	550	575	600	625	650
0																											
25																											
50																											
75																											
100																			W								
125																			W								
150																		W									
175																		W									
200																	W										
225				B													W					T					
250																W											
275																W											
300															W												
325															W												
350																											
375																											
400																											
425																											
450															C												
475														C	C	C											
500													C	C	C	C	C										
*/
		
	// Create Target Object.
	CreateStaticCircularBody (525, 225, 10, OBJ_TARGET, isImageServer.GetTargetImage ());

	// Create Ball Object.
	CreateDynamicBallBody (75, 225);

	// Internal Circular Walls
	CreateStaticCircularBody (350, 480, 75, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());
	
	// Internal Walls
	CreateStaticBoxBody (400, 225, 15, 250, 45, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
}

void DynamicWorld::CreateComplicated1Level (void)
{
		/*
			0	50	100	150	200	250	300	350	400	450	500	550	600	650
		0														
		50														
		100		W		W		W		W		W				
		150		W		W		W		W		W				
		200		W		W		W		W		W				
		250														
		300														
		350	W	W	W	W	W			C						
		400		T					C	C	C			B		
		450	W	W	W	W	W			C						
		500														
		*/

	// Create Target Object.
	CreateStaticCircularBody (50, 400, 10, OBJ_TARGET, isImageServer.GetTargetImage ());

	// Create Ball Object.
	CreateDynamicBallBody (550, 400);

	// Internal Walls
	CreateStaticBoxBody (50, 150, 50, 150, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	CreateStaticBoxBody (150, 150, 50, 150, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	CreateStaticBoxBody (250, 150, 50, 150, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	CreateStaticBoxBody (350, 150, 50, 150, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	CreateStaticBoxBody (450, 150, 50, 150, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());

	CreateStaticBoxBody (100, 350, 250, 50, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	CreateStaticBoxBody (100, 450, 250, 50, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());

	// Internal Circular Walls
	CreateStaticCircularBody (350, 400, 50, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());

}

void DynamicWorld::CreateRain(void)
{
	// Little particles that have a strong downward force.
	for (int i = 10; i < 620; i += 10)
	{
		CreateDynamicBoxBody (0, 10000, i, 20, 4, 4, 0, OBJ_DYNAMIC, isImageServer.GetBlueDotImage ());
	}
}


void DynamicWorld::CreatePic1Level (void)
{
/*
0	25	50	75	100	125	150	175	200	225	250	275	300	325	350	375	400	425	450	475	500	525	550	575	600	625	650
0																											
25																											
50		B																									
75																											
100								C		C																	
125																											
150									W																		
175							C				C																
200								C	C	C																	
225									C																		
250																											
275									W																		
300								W	W	W																	
325									W														W				
350									W													W					
375									W												W						
400								W		W										W							
425							W				W													T			
450																											
475																											
500																											
*/

	// Create Target Object.
	CreateStaticCircularBody (600, 425, 5, OBJ_TARGET, isImageServer.GetTargetImage ());

	// Create Ball Object.
	CreateDynamicBallBody (50, 50);

	// Internal Walls
	CreateStaticBoxBody (225, 150, 25, 25, 45, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	//CreateStaticBoxBody (225, 312, 25, 150, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	CreateStaticBoxBody (200, 300, 50, 25, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	CreateStaticBoxBody (250, 300, 50, 25, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	CreateStaticBoxBody (175, 425, 25, 25, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	CreateStaticBoxBody (200, 400, 25, 25, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	CreateStaticBoxBody (250, 400, 25, 25, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	CreateStaticBoxBody (275, 425, 25, 25, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());

	// Slash on the right.
	CreateStaticBoxBody (575, 375, 5, 100, 45, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());

	// Internal Circular Walls
	// Eyes
	CreateStaticCircularBody (200, 100, 25, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());
	CreateStaticCircularBody (250, 100, 25, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());
	
	CreateStaticCircularBody (175, 175, 15, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());
	CreateStaticCircularBody (200, 200, 15, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());
	CreateStaticCircularBody (225, 200, 15, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());
	CreateStaticCircularBody (250, 200, 15, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());
	CreateStaticCircularBody (275, 175, 15, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());
	CreateStaticCircularBody (225, 225, 15, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());

	CreateRain();

}


// Cheap, simple way to try to ensure we aren't creating objects overlaping the target.
void DynamicWorld::ChooseRandomCenter (int xTargetCenter, int yTargetCenter, int & xCenter, int & yCenter)
{
int nDistanceSquared;

	for (int i = 0; i < 100; i ++)
	{
		xCenter = (rand () % 600) + 25;
		yCenter = (rand () % 400) + 25;
		
		nDistanceSquared = 	(xTargetCenter - xCenter) * (xTargetCenter - xCenter) +
							(yTargetCenter - yCenter) * (yTargetCenter - yCenter);
		if (nDistanceSquared > 400)
			return;
	}
}


void DynamicWorld::CreateRandomLevel (void)
{
int xCenter, yCenter;
int nRadius, nWidth, nHeight;
int nNumObjects;
int xTargetCenter, yTargetCenter;

	// Create Target Object.
	xTargetCenter = (rand () % 600) + 25;
	yTargetCenter = (rand () % 400) + 25;
	nRadius = (rand () % 5) + 5;
	CreateStaticCircularBody (xTargetCenter, yTargetCenter, nRadius, OBJ_TARGET, isImageServer.GetTargetImage ());

	// Create Ball Object.
	ChooseRandomCenter (xTargetCenter, yTargetCenter, xCenter, yCenter);
	CreateDynamicBallBody (xCenter, yCenter);

	// Internal Walls
	nNumObjects = rand () % 15;
	for (int i = 0; i < nNumObjects; i ++)
	{
		ChooseRandomCenter (xTargetCenter, yTargetCenter, xCenter, yCenter);
		nWidth = 20;
		nHeight = 20;
		CreateStaticBoxBody (xCenter, yCenter, nWidth, nHeight, 0, OBJ_INTERNAL_WALL, isImageServer.GetLightBar4x4Image ());
	}
	
	
	// Internal Circular Walls
	nNumObjects = rand () % 15;
	for (int i = 0; i < nNumObjects; i ++)
	{
		ChooseRandomCenter (xTargetCenter, yTargetCenter, xCenter, yCenter);
		nRadius = (rand () % 10) + 15;
		CreateStaticCircularBody (xCenter, yCenter, nRadius, OBJ_INTERNAL_WALL, isImageServer.GetGreenCircleImage ());
	}

	if (rand () % 100 < 5)
		CreateRain();

}
