
// ImageServer to share image data.

/*
	To add a new image:
	
	1.  Add a new private Image pointer.
	2.  Add a Getter function.
	3.  Add DoImageLoad to Initialize function.
	4.  Add appropriate include file.

*/

#define DefineImage(name) private: wsp::Image * p ##name## Image; \
		public:  inline wsp::Image * Get ##name## Image (void) { return p ##name## Image; }


class ImageServer
{
private:
	wsp::Image * pHeroImage;
	wsp::Image * pYOGBackgroundImage;
	wsp::Image * pSliderImage;
	wsp::Image * pSliderStickImage;
	wsp::Image * pSplashScreenImage;
	wsp::Image * pDotImage;
	wsp::Image * pBlueDotImage;
	wsp::Image * pDialogBoxHeaderImage;
	wsp::Image * pDialogBoxMidImage;
	wsp::Image * pDialogBoxFooterImage;
	wsp::Image * pTahomaWhiteFontImage;
	wsp::Image * pTahomaBlackFontImage;
	wsp::Image * pDimmerImage;
	wsp::Image * pBar4x4Image;
	wsp::Image * pRedPixelImage;
	wsp::Image * pTargetImage;
	wsp::Image * pBallImage;

public:
	ImageServer ();
	~ImageServer ();

	bool Initialize (void);
	char szLastError [128];
	int nLastError;

	inline wsp::Image * GetHeroImage (void) { return pHeroImage; }
	inline wsp::Image * GetYOGBackgroundImage (void) { return pYOGBackgroundImage; }
	inline wsp::Image * GetSliderImage (void) { return pSliderImage; }
	inline wsp::Image * GetSliderStickImage (void) { return pSliderStickImage; }
	inline wsp::Image * GetSplashScreenImage (void) { return pSplashScreenImage; }
	inline wsp::Image * GetDotImage (void) { return pDotImage; }
	inline wsp::Image * GetBlueDotImage (void) { return pBlueDotImage; }
	inline wsp::Image * GetDialogBoxHeaderImage (void) { return pDialogBoxHeaderImage; }
	inline wsp::Image * GetDialogBoxMidImage (void) { return pDialogBoxMidImage; }
	inline wsp::Image * GetDialogBoxFooterImage (void) { return pDialogBoxFooterImage; }
	inline wsp::Image * GetTahomaWhiteFontImage (void) { return pTahomaWhiteFontImage; }
	inline wsp::Image * GetTahomaBlackFontImage (void) { return pTahomaBlackFontImage; }
	inline wsp::Image * GetDimmerImage (void) { return pDimmerImage; }
	inline wsp::Image * GetBar4x4Image (void) { return pBar4x4Image; }
	inline wsp::Image * GetRedPixelImage (void) { return pRedPixelImage; }
	inline wsp::Image * GetTargetImage (void) { return pTargetImage; }
	inline wsp::Image * GetBallImage (void) { return pBallImage; }


	DefineImage(ArrowCursor1);
	DefineImage(ArrowCursor2);
	DefineImage(ArrowCursor3);
	DefineImage(ArrowCursor4);
	DefineImage(PerpetuaFont_48_Blue);
	DefineImage(PaceMakerSplashScreen);
	DefineImage(CourierNew_16_WhiteOnBlack);
	DefineImage(Slider_Vertical);
	DefineImage(BackgroundStars);
	DefineImage(GreenCircle);
	DefineImage(LightBar4x4);
	
};


extern ImageServer isImageServer;
