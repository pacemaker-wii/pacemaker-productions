
// Main Menu

#pragma once

#include "BibLib\BibMenus.h"

class MainMenu
{
private:
	BibMenus bmMainMenu;
	class YOGWorld * pWorld;

	// From WiiInputDevice ActionMap
	//   For Menus
	int WiiMainMenuAction;
	int WiiMainMenuUpAction;
	int WiiMainMenuDownAction;
	int WiiMainMenuSelectAction;
	int WiiMainMenuBackAction;

	// Static so I can initialize it statically
	static const char * szMenuItems  [];// = {"Menu Choice 1", "ABC", "Menus are Fun"};

public:
	void Initialize (YOGWorld * pWorld);
	// This is called every game loop.
	//  It returns true if it swallowed some user input, false if not.
	bool UpdateMovement (void);
	void DisplayListBox (void) { bmMainMenu.DisplayListBox (); }


};

