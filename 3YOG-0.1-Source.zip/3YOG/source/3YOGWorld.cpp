// YOGWorld.cpp: implementation for the YOGWorld class.
//
//////////////////////////////////////////////////////////////////////

#include "GameConstants.h"
#include "3YOGWorld.h"
#include "ImageServer.h"



static BibWiiInputDevice::SingleAction saSplashScreenAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2},
											{BibWiiInputDevice::CTRL_GAMECUBE, PAD_BUTTON_A}
																};
static BibWiiInputDevice::SingleAction saButtonMinusAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_MINUS},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_MINUS},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_MINUS},
											{BibWiiInputDevice::CTRL_GAMECUBE, PAD_TRIGGER_L}
																};
static BibWiiInputDevice::SingleAction saButtonPlusAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_PLUS},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_PLUS},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_PLUS},
											{BibWiiInputDevice::CTRL_GAMECUBE, PAD_TRIGGER_Z}
																};














//!!!! Delete this after debug is complete.
int nDebugCounterL = 0;
int nDebugCounterR = 0;

#ifdef GCUBE_EMU
int nGCubeEmuCounter1 = 0;
extern bool bEmuForceButton;
#endif











YOGWorld::YOGWorld ()
{
}

YOGWorld::~YOGWorld ()
{
}



void YOGWorld::Initialize (int nWidth, int nHeight)
{
	WiiInputDevice.Initialize (nWidth, nHeight);

	// Instantiate button actions.
	WiiSplashScreenAction= WiiInputDevice.DefineAction (saSplashScreenAction);
	WiiButtonMinusAction= WiiInputDevice.DefineAction (saButtonMinusAction);
	WiiButtonPlusAction = WiiInputDevice.DefineAction (saButtonPlusAction);

	TheMainMenu.Initialize (this);
	pSound.Initialize ();


	// Load background
	bsBackgroundPic.SetImage (isImageServer.GetYOGBackgroundImage ());
	bsBackgroundPic.SetPosition(0, 0);

	// Initialize Box2D World.
	DWorld.InitializeDynamics ();


#ifdef PRODUCTION
	bDebugOn = FALSE;
#else
	bDebugOn = TRUE;
#endif


	// Set game state to playing
	eGameState = YOGWorld::SPLASH_SCREEN_PACEMAKER;


	for (int i = 0; i < NUM_HEROES; i ++)
		Heroes[i].Initialize (this, i);
	
	Reset ();
}


void YOGWorld::Reset (void)
{
	nGameStateCounter = 0;
	fLevelTimeElapsed = 0;
	nLevel = 0;

	for (int i = 0; i < NUM_HEROES; i ++)
		Heroes[i].Reset ();
}



HeroCtrl * YOGWorld::GetHeroCtrl (int nHero)
{
	if ((nHero >= 0) && (nHero < NUM_HEROES))
	{
		return (& (Heroes [nHero]));
	}
	else
	{
		return (NULL);
	}
}


/*
	Main Control Loop.

	This is called every game loop.
*/
void YOGWorld::UpdateMovement (float fSpeedFactor)
{
bool bBallHitTarget;

	WiiInputDevice.ScanInputDevice ();
	pSound.UpdateMovement ();

	if (eGameState != YOGWorld::SPLASH_SCREEN_PACEMAKER)
	{
#ifdef GCUBE_EMU
			nGCubeEmuCounter1 ++;
			if (nGCubeEmuCounter1 > 300)
			{
				nGCubeEmuCounter1 = 0;
				nDebugCounterL ++;
			}

			if (nGCubeEmuCounter1 > 10)
				nDebugCounterR ++;

#endif	

		if (WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiButtonMinusAction))
		{
			pSound.PlaySound(YOGSound::SND_CLICK);
		}

		if (WiiInputDevice.ActionHeld (WPAD_CHAN_0, WiiButtonMinusAction))
		{
			nDebugCounterL ++;
		}
		if (WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiButtonPlusAction))
		{
			nDebugCounterR ++;
		}


		// There are two purposes of this call.
		// (1) It checks to see if we need to switch state to MAIN_MENU state (pressed home button)
		// (2) When in MAIN_MENU state, it draws the menu.
		//  It seems one call should be here and another in the "case ShoterWorld::MAIN_MENU:" below.
		if (TheMainMenu.UpdateMovement ())
		{
			// The Menu must have swallowed some user input, don't try to process any more.
			//  For example, back key was pressed.  Don't interpret it as something else below.
			return;
		}


		for (int i = 0; i < NUM_HEROES; i ++)
			Heroes[i].UpdateMovement (fSpeedFactor);
	}

	// State machine:
	switch (eGameState)
	{
		case YOGWorld::PLAYING:
			nGameStateCounter ++;
		
			fLevelTimeElapsed += pView->fps.fFrameTimeDelta;

			bBallHitTarget = DWorld.StepDynamicWorld (pView->fps.fFrameTimeDelta);
			if (bBallHitTarget)
			{
				IncrementHeroScoresAtEndOfLevel ();
			
				// Achieved end of level...do something.
				nGameStateCounter = 0;
				fLevelTimeElapsed = 0;
				eGameState = YOGWorld::END_OF_LEVEL;
			}
			else
			{
				if ((nGameStateCounter % 5) == 0)
				{
					BibPoint * pLoc = new (BibPoint);
					pLoc->x = DWorld.GetBallBodySprite()->GetX();
					pLoc->y = DWorld.GetBallBodySprite()->GetY();
					qGhostBalls.push_back(pLoc);
					if (qGhostBalls.size() > MAX_GHOST_BALLS)
					{
						delete (qGhostBalls.front());
						qGhostBalls.pop_front();
					}
				}
			}
		break;

		case YOGWorld::MAIN_MENU:
			// Don't do any processing.
			return;
		break;

		default:

		case YOGWorld::SPLASH_SCREEN:

#ifdef GCUBE_EMU
			bEmuForceButton = false;
			nGameStateCounter ++;
			if (nGameStateCounter > 10)
			{
				bEmuForceButton = true;
			}
#endif
			if (WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiSplashScreenAction))
			{
				eGameState = YOGWorld::START_OF_LEVEL;
				nGameStateCounter = 0;
				Reset ();
			}

#ifdef GCUBE_EMU
			bEmuForceButton = false;
#endif

			// Don't do any processing.
			return;
		break;

		case YOGWorld::SPLASH_SCREEN_PACEMAKER:

			nGameStateCounter ++;
#ifdef GCUBE_EMU
			nGameStateCounter += 10;
#endif

			if (WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiSplashScreenAction) ||
			    (nGameStateCounter > PACEMAKER_SPLASHSCREEN_WAIT_TIME))
			{
				pSound.PlaySound(YOGSound::MP3_TEA_AND_CRUMPETS);
				nGameStateCounter = 0;
				eGameState = YOGWorld::SPLASH_SCREEN;
				Reset ();
			}

			// Don't do any processing.
			return;
		break;

		case YOGWorld::START_OF_LEVEL:
			if (nGameStateCounter == 0)
			{
				// Load new level
				nLevel ++;
				CreateLevel(nLevel);
			}
			
			nGameStateCounter ++;
#ifdef GCUBE_EMU
			nGameStateCounter += 10;
#endif
			if (nGameStateCounter > START_OF_LEVEL_WAIT_TIME)
			{
				nGameStateCounter = 0;
				eGameState = YOGWorld::PLAYING;
			}
			
			// Don't do any more processing.
			return;

		case YOGWorld::END_OF_LEVEL:
			nGameStateCounter ++;
#ifdef GCUBE_EMU
			nGameStateCounter += 10;
#endif
			if (nGameStateCounter > END_OF_LEVEL_WAIT_TIME)
			{
				nGameStateCounter = 0;
				eGameState = YOGWorld::START_OF_LEVEL;
			}
			
			// Don't do any more processing.
			return;

		case YOGWorld::GAME_OVER:
			nGameStateCounter ++;
			if (nGameStateCounter > GAME_OVER_WAIT_TIME)
			{
				nGameStateCounter = 0;
				eGameState = YOGWorld::SPLASH_SCREEN;
			}
			
			// Don't do any more processing.
			return;
		break;
	}

}


void YOGWorld::IncrementHeroScoresAtEndOfLevel (void)
{
int nIncScore;

	for (int i = 0; i < NUM_HEROES; i ++)
	{
		nIncScore = END_OF_LEVEL_SCORE_BONUS;
		nIncScore += 10 * Heroes[i].GetPushersLeft() + 5 * Heroes[i].GetBurstsLeft();
		if (60 - GetLevelTimeElapsed() > 0)
		{
			nIncScore += 60 - GetLevelTimeElapsed();
		}
		nIncScore += DWorld.GetBallContactCounter();
		Heroes[i].IncScore (nIncScore);
	}
}


// Not a deep stack as the name implies.  The code relies on it being a shallow (1) stack.
void YOGWorld::PushGameState (eGameStateType in_GameState)
{
	eSaveGameState = eGameState;
	eGameState = in_GameState;
}

YOGWorld::eGameStateType YOGWorld::PopGameState (void)
{
	eGameState = eSaveGameState;
	return (eGameState);
}


const char * YOGWorld::GetLevelBannerText (void)
{
	switch (eGameState)
	{
		default:
		case SPLASH_SCREEN_1_WARN:
		case SPLASH_SCREEN_2_SIDEWAYS:
		case SPLASH_SCREEN_PACEMAKER:
		case SPLASH_SCREEN:
		case PLAYING:
			return (NULL);
		break;
		
		case START_OF_LEVEL:
			return ("START OF LEVEL");
		break;
		
		case END_OF_LEVEL:
			return ("END OF LEVEL");
		break;
		
		case GAME_OVER:
			return ("GAME OVER");
		break;
		
		case MAIN_MENU:
			return ("PAUSED");
		break;
	}

	return (NULL);
}

void YOGWorld::GetLevelBannerPosition (int & x, int & y)
{
	if (eGameState == MAIN_MENU)
	{
		x = 245;
		y = 25;
		return;
	}
	
	x = (20 + nGameStateCounter / 1) % 640;
	y = 240 + (sin(nGameStateCounter / 25) * 20);
}


// Debug Function
void YOGWorld::SkipLevel (void)
{
	nGameStateCounter = 0;
	fLevelTimeElapsed = 0;
	eGameState = YOGWorld::END_OF_LEVEL;
}


void YOGWorld::CreateLevel (int nLevel)
{
	for (int i = 0; i < NUM_HEROES; i ++)
		Heroes[i].ResetForNewLevel ();

	DWorld.CreateLevel(nLevel);
}
