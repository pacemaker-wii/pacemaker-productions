/*

	BibSound.h

*/

#pragma once

#include <map>
#include <vector>
#include <gccore.h>

//#define DEBUG_BIBSOUND

#include "BibMp3.h"


//!!!! Need to clarify all uses of 'samples'  Is this 32 byte words or bytes?

/*
	Limitations of this class:
	
	* Mp3's are intended to be background music.
	* Mp3's loop by default.
	* Only one Mp3 can be active at a time.
	* Mp3's must be in a specific format (see below).
	* Sound effects must be in WAV format (see below).
*/


/*
 * Pre-requisites for LoadSoundWav()
 *	The wave file must be 48Khz stereo format.
 *	To convert for GC, use sox
 *		sox yourfile.wav -r 48000 -c 2 -w gcfile.wav
*/


/*
 * Pre-requisites for LoadSoundMp3()
 * Need to remove ID3 tags from mp3's since libmad doesn't read them.
 * Need to resample to 48000 Hz and ensure two channels (stereo)
 * Audacity works well for conversion with the lame DLL, if you don't mind recoding the mp3.
 *		(http://audacity.sourceforge.net/)
 * Kid3 can be used to delete the ID3 tags. (http://kid3.sourceforge.net/)
*/



class BibSound
{
private:
	bool bSoundOn;
	u32 aMutex;


	/*
		Loaded sample information.
	*/
	struct LoadedSample
	{
		unsigned char * pData;
		int nLength;
	
		enum SampleType_t { BS_WAV, BS_MP3 };
		SampleType_t eSampleType;
	};
	
	typedef std::map<int, LoadedSample *> iSampleListType;
	iSampleListType iLoadedSampleList;



	/*
		Current playing sample information.
	*/
	struct CurPlayingSample
	{
		int nSampleIndex;			// Which Sample?
		int nSampleBufferIndex; // If we did an incomplete copy, where are we in the sample?
	};

	typedef std::vector<CurPlayingSample *> iPlayListType;
	typedef std::vector<CurPlayingSample *>::iterator iPlayListIteratorType;

	// List of samples currently playing.
	iPlayListType iPlayList;




	// Audio buffer.
	u32 * SoundBuffers [2];
	int which_sb;

	// Current Sound Buffer to use.	Was more relevant when this was double buffered.
	inline u32 * CurSB (void) { return (SoundBuffers[which_sb]); }
	inline u32 * OthSB (void) { return (SoundBuffers[which_sb^1]); }
	
	// Convert wave to Wii ready data.
	int ConvertWave (unsigned char *wavebuffer);
	void MoveSamplesToNewBuffer (void);

	// MP3 Background Music support.
	friend class BibMp3;	// Friend so we can make mp3 support functions private.
	BibMp3 Mp3Mixer;

	// Takes the supplied buffer and adds it directly to the playing audio buffer
	bool AddToPlayBuffer (unsigned int * pSndBuf, int nSamples, int * nDestBuf, int * nDestPos);
	
public:

	BibSound ();
	~BibSound ();


	// Status reporting variables.
#ifdef DEBUG_BIBSOUND
	int AudioStatus;
	char szAudioLastMsg [128];
#endif

	// Only to be called by Audio callback function.
	void NextBuffer (void);


	void Initialize (void);
	bool IsOn (void) { return (bSoundOn); }
	void TurnOn (bool bTurnOn = true) { bSoundOn = bTurnOn; }

	// Load WAV data and convert.
	bool LoadSoundWav (int nIndex, unsigned char * pData);
	// Load MP3 data and convert.
	bool LoadSoundMp3 (int nIndex, unsigned char * pData, int nLength);
	
	// Play a Sound Effect (WAV) or Background Music (Mp3)
	int PlaySound (int nIndex);
	// Stop a looping Mp3
	void StopSound (int nIndex);
	
	// Needs periodic maintenance for backgroun mp3 thread
	void UpdateMovement (void);


};

