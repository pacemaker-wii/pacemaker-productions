/*
	Frame Rate regulation and measurement.
*/

#include <ogc/lwp_watchdog.h>
#include "BibFrameRate.h"



void BibFrameRate::Init(float tfps)
{
	targetfps = tfps;
	llLastCurrentTicks = gettime ();
	fFrameTimeDelta = 0;
	fMinFPS = 999;
}


void BibFrameRate::SetSpeedFactor()
{
	
	llCurrentTicks = gettime ();

	//This frame's length out of desired length
	fspeedfactor = (llCurrentTicks-llLastCurrentTicks) / (secs_to_ticks(1)/targetfps);
	if (fspeedfactor <= 0)
		fspeedfactor = 1;
	fps = targetfps / fspeedfactor;

	fFrameTimeDelta = ((float)(llCurrentTicks - llLastCurrentTicks)) / (float) (secs_to_ticks(1));

	llLastCurrentTicks = llCurrentTicks;
	
	if (fMinFPS > fps)
		fMinFPS = fps;
}


// Measure amount of time to wait during Flush
//  to gauge how much more processing we can do
//  per frame.
void BibFrameRate::MeasPreFlush (void)
{
	llFlushLastTicks = gettime ();
}

void BibFrameRate::MeasPostFlush (void)
{
	llFlushLastTicks = gettime () - llFlushLastTicks;
}

unsigned int BibFrameRate::GetFlushMicroSecs (void)
{
	return (ticks_to_microsecs (llFlushLastTicks));
}

