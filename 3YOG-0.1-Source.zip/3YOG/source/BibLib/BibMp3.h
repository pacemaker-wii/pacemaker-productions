// BibMp3


#include <gccore.h>
#include <mad/mad.h>

// 8K is too small, 80K seems to work.
#define MP3_THREAD_STACK_SIZE 81920


class BibMp3
{
public:

	/*
	 * This is a private message structure. A generic pointer to this structure
	 * is passed to each of the callback functions. Put here any data you need
	 * to access from within the callbacks.
	 */

	struct MsgBufferType
	{
	  unsigned char const *start;
	  unsigned long length;
	  unsigned char const *CurPos;
	};


private:
	lwp_t ThreadHandle;
	lwpq_t ThreadQueue;
	//!!!! Should allocate this from the heap in this class.
	u8 ThreadStack[MP3_THREAD_STACK_SIZE];
	
	int nCurPlayingIndex;
	int nDestBuf;
	int nDestPos;

	int nAvoidSleepCounter;
public:
	/*
		Not really public, just needs to be avail to mad C functions.
	*/
	class BibSound * pSound;
	struct MsgBufferType MsgBuffer;
	struct mad_decoder decoder;
	
	void ThreadSleep (void);
	void ThreadRun (void);
	void AddToPlayBuffer  (unsigned int * pSndBuf, int nSamples);

public:	
	
	BibMp3 ();
	~BibMp3 ();
	
	int Initialize (class BibSound * pSound, int nIndex, unsigned char * pData, int nLength);
	void Uninitialize (void);

};
