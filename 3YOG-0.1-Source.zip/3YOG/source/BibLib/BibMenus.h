// BibMenus.h

/*






Need selection from list:
	+------------+
	|   Title    |
	|============|
	|  apples    |
	|* oranges   |
	|  bananas   |
	+------------+
int DisplayListBox (char * szItemNames [], int nItems);
  Up/Down to move between.
  (A) to select

Need to capture input and halt all other updates to the main program (i.e. game)






*/

#ifndef _BIBMENUS_H_
#define _BIBMENUS_H_

#include "BibScreenFont.h"

class BibMenus
{
private:
	
	wsp::Sprite bsBoxHeader;
	wsp::Sprite bsBoxMid;
	wsp::Sprite bsBoxFooter;
	BibScreenFont Tahoma_ScreenFont;
	wsp::Sprite bsDimmer;

	// Saved data from the someone set us up the menu.
	const char * szTitle;
	const char * * szItemNames;
	int nItems;
	int nCurSel;

public:

	enum eInputTypes { INPUT_UP, INPUT_DOWN, INPUT_SELECT, INPUT_BACK };

	BibMenus ();
	~BibMenus ();
	void Initialize (void);
	void SetupListBox (const char * szTitle, const char * szItemNames [], const int nItems);
	void DisplayListBox (void);
	int ProcessInput (eInputTypes eInput);


};
#endif

