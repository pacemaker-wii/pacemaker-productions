// BibMenus.cpp


#define _BIBMENUS_CPP_

#include <wiisprite.h>

#include "BibMenus.h"
#include "../ImageServer.h"

// Shouldn't mix BibLib sprites with Game sprites.
#include "../sprites/TahomaFont_16_White_metrics.sprite.h" 
#include "../sprites/TahomaFont_16_Black_metrics.sprite.h" 

//  Average Width of font above
#define FONT_WIDTH 12



BibMenus::BibMenus ()
{
}

BibMenus::~BibMenus ()
{

}

void BibMenus::Initialize (void)
{
	// Load box pictures
	bsBoxHeader . SetImage (isImageServer.GetDialogBoxHeaderImage ());
	bsBoxMid . SetImage (isImageServer.GetDialogBoxMidImage ());
	bsBoxFooter . SetImage (isImageServer.GetDialogBoxFooterImage ());
	bsDimmer . SetImage (isImageServer.GetDimmerImage ());
	
	Tahoma_ScreenFont . Initialize (isImageServer.GetTahomaBlackFontImage (), 
									isImageServer.GetTahomaBlackFontImage ()->GetWidth() / 16, 
									isImageServer.GetTahomaBlackFontImage ()->GetHeight() / 16, 
									TahomaFont_16_Black_metrics);

	nCurSel = 0;
}


void BibMenus::SetupListBox (const char * _szTitle, const char * _szItemNames [], const int _nItems)
{
	szTitle = _szTitle;
	szItemNames = _szItemNames;
	nItems = _nItems;
	nCurSel = 0;
}


void BibMenus::DisplayListBox (void)
{
int i, xMidPoint;
int x, y;


	// Make existing frame buffer dimmerby displaying a mostly transparent black square.
	bsDimmer.SetTransparency (75);
	bsDimmer.SetPosition (0, 0);
	bsDimmer.Draw ();


	/*
		Display Graphic background.
	*/

	// Display Header of list box.
	x = (640 / 2) - (bsBoxHeader.GetImage()->GetWidth() / 2);	// Center horizontally.
	y = (480 / 2) - ((bsBoxHeader.GetImage()->GetHeight() + (bsBoxMid.GetImage()->GetHeight() * nItems) + bsBoxFooter.GetImage()->GetHeight()) / 2);
	bsBoxHeader.SetPosition(x, y);
	bsBoxHeader.Draw();
	
	// Adjust Y location for first mid section.
	y += bsBoxHeader.GetImage()->GetHeight();

	// Do all mid sections except last one.
	for (i = 0; i < nItems - 1; i ++)
	{
		bsBoxMid.SetPosition (x, y);
		bsBoxMid.Draw();
		y += bsBoxMid.GetImage()->GetHeight();
	}
	// Display last mid section.
	bsBoxMid.SetPosition (x, y);
	bsBoxMid.Draw();
	
	// Display footer section.
	y += bsBoxMid.GetImage()->GetHeight();
	bsBoxFooter.SetPosition (x, y);
	bsBoxFooter.Draw();



	/*
		Display Text on top of graphic background.
	*/
	xMidPoint = (x + (bsBoxHeader.GetImage()->GetWidth() / 2));
	x =  xMidPoint - ((strlen (szTitle) * FONT_WIDTH) / 2);
	if (x < 0)
		x = xMidPoint - (bsBoxHeader.GetImage()->GetWidth() / 2) + FONT_WIDTH;
	y = (480 / 2) - ((bsBoxHeader.GetImage()->GetHeight() + (bsBoxMid.GetImage()->GetHeight() * nItems) + 
					bsBoxFooter.GetImage()->GetHeight()) / 2) + 8; //!!! 8 is a fudge factor
	Tahoma_ScreenFont.DisplayText (x, y, szTitle);

	// Adjust Y location for first mid section.
	y += bsBoxHeader.GetImage()->GetHeight() - 8;	//!!! Subtract the fudge factor above.

	// Left justified text for each menu item.
	x =  xMidPoint - (bsBoxHeader.GetImage()->GetWidth() / 2) + (FONT_WIDTH * 2);

	// Do all menu items except last one.
	for (i = 0; i < nItems - 1; i ++)
	{
		Tahoma_ScreenFont.DisplayText (x, y, szItemNames [i]);
		if (nCurSel == i)
			Tahoma_ScreenFont.DisplayText (x - (FONT_WIDTH * 3) + 2, y, "->");
		y += bsBoxMid.GetImage()->GetHeight();
	}
	// Display last menu item section.
	Tahoma_ScreenFont.DisplayText (x, y, szItemNames [i]);
	if (nCurSel == i)
		Tahoma_ScreenFont.DisplayText (x - (FONT_WIDTH * 3) + 2, y, "->");

}


/*
	This function returns:
		-2 = Abort/back.
		-1 = No selection yet.
		0..(nItems-1) = selection made.
*/
int BibMenus::ProcessInput (eInputTypes eInput)
{
	switch (eInput)
	{
		case INPUT_DOWN:
			if (nCurSel < (nItems - 1))
				nCurSel ++;
			else
				nCurSel = 0;
		break;
	
		case INPUT_UP:
			if (nCurSel > 0)
				nCurSel --;
			else
				nCurSel = nItems - 1;
		break;

		case INPUT_SELECT:
			return (nCurSel);
		break;
		
		case INPUT_BACK:
			return (-2);
		break;
		
		default:
		break;
	}
	
	return (-1);
}



