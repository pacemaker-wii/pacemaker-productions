// BibGraphicsHelper

#include <wiisprite.h>
#include "BibGraphicsHelper.h"

void BibGraphicsHelper::DrawLine (int x1, int y1, int x2, int y2, wsp::Sprite * sprite)
{
short int dx, dy, sdx, sdy, x, y, px, py;

	x = 0;
	y = 0;
	dx = x2 - x1;
	dy = y2 - y1;
	sdx = (dx < 0) ? -1 : 1;
	sdy = (dy < 0) ? -1 : 1;
	dx = sdx * dx + 1;
	dy = sdy * dy + 1;
	px = x1;
	py = y1;

	if (dx >= dy)
	{
		for (x = 0; x < dx; x++)
		{
			sprite->SetPosition(px, py);
			sprite->Draw ();

			y += dy;
			if (y >= dx)
			{
				y -= dx;
				py += sdy;
			}
			px += sdx;
		}
	}
	else
	{
		for (y = 0; y < dy; y++)
		{
			sprite->SetPosition(px, py);
			sprite->Draw ();

			x += dx;
			if (x >= dy)
			{
				x -= dy;
				px += sdx;
			}
			py += sdy;
		}
	}
}

