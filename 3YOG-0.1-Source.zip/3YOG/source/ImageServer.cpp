
// ImageServer to share image data.

#include <wiisprite.h>
#include "ImageServer.h"

#include "sprites/Hero.sprite.h" 
#include "Sprites/YOGBackground.sprite.h"
#include "Sprites/Slider.sprite.h"
#include "Sprites/SliderStick.sprite.h"
#include "Sprites/YOGSplashScreen.sprite.h"
#include "Sprites/dot.sprite.h"
#include "Sprites/BlueDot.sprite.h"
#include "sprites/DialogBoxHeader.sprite.h" 
#include "sprites/DialogBoxMid.sprite.h" 
#include "sprites/DialogBoxFooter.sprite.h" 
#include "sprites/TahomaFont_16_White.sprite.h" 
#include "sprites/TahomaFont_16_Black.sprite.h" 
#include "sprites/Dimmer.sprite.h" 
#include "sprites/Bar4x4.sprite.h" 
#include "sprites/RedPixel.sprite.h" 
#include "sprites/Target.sprite.h" 
#include "sprites/Ball.sprite.h" 
#include "sprites/ArrowCursor1.sprite.h" 
#include "sprites/ArrowCursor2.sprite.h" 
#include "sprites/ArrowCursor3.sprite.h" 
#include "sprites/ArrowCursor4.sprite.h" 
#include "sprites/PerpetuaFont_48_Blue.sprite.h" 
#include "sprites/PaceMakerSplashScreen.sprite.h"
#include "sprites/CourierNew_16_WhiteOnBlack.sprite.h" 
#include "sprites/Slider_Vertical.sprite.h"
#include "sprites/BackgroundStars.sprite.h"
#include "sprites/GreenCircle.sprite.h"
#include "sprites/LightBar4x4.sprite.h" 


#define DoImageLoad(p, image_var, image_name) \
	p = new wsp::Image (); \
	iStatus = p->LoadImage(image_var); \
	if (iStatus != wsp::IMG_LOAD_ERROR_NONE) \
	{ \
		sprintf (szLastError, "\n\n Image Load Error %s = (%d)\n", image_name, iStatus); \
		nLastError = iStatus; \
		return (false); \
	}

#define DoImageLoadAll(image_var) \
	p ## image_var ## Image = new wsp::Image (); \
	iStatus = p ## image_var ## Image ->LoadImage(image_var); \
	if (iStatus != wsp::IMG_LOAD_ERROR_NONE) \
	{ \
		sprintf (szLastError, "\n\n Image Load Error %s = (%d)\n", #image_var, iStatus); \
		nLastError = iStatus; \
		return (false); \
	}

ImageServer::ImageServer ()
{
}


ImageServer::~ImageServer ()
{
}


bool ImageServer::Initialize (void)
{
wsp::IMG_LOAD_ERROR iStatus;

	szLastError [0] = 0;
	nLastError = 0;
	
	DoImageLoad (pHeroImage, Hero, "Hero");
	DoImageLoad (pYOGBackgroundImage, YOGBackground, "YOGBackground");
	DoImageLoad (pSliderImage, Slider, "Slider");
	DoImageLoad (pSliderStickImage, SliderStick, "SliderStick");
	DoImageLoad (pSplashScreenImage, YOGSplashScreen, "SplashScreen");
	DoImageLoad (pDotImage, Dot, "Dot");
	DoImageLoad (pBlueDotImage, BlueDot, "BlueDot");
	DoImageLoad (pDialogBoxHeaderImage, DialogBoxHeader, "DialogBoxHeader");
	DoImageLoad (pDialogBoxMidImage, DialogBoxMid, "DialogBoxMid");
	DoImageLoad (pDialogBoxFooterImage, DialogBoxFooter, "DialogBoxFooter");
	DoImageLoad (pTahomaWhiteFontImage, TahomaFont_16_White, "TahomaFont_16_White");
	DoImageLoad (pTahomaBlackFontImage, TahomaFont_16_Black, "TahomaFont_16_Black");
	DoImageLoad (pDimmerImage, Dimmer, "Dimmer");
	DoImageLoad (pBar4x4Image, Bar4x4, "Bar4x4");
	DoImageLoad (pRedPixelImage, RedPixel, "RedPixel");
	DoImageLoad (pTargetImage, Target, "Target");
	DoImageLoad (pBallImage, Ball, "Ball");
	DoImageLoad (pArrowCursor1Image, ArrowCursor1, "ArrowCursor1");
	DoImageLoad (pArrowCursor2Image, ArrowCursor2, "ArrowCursor2");
	DoImageLoad (pArrowCursor3Image, ArrowCursor3, "ArrowCursor3");
	DoImageLoad (pArrowCursor4Image, ArrowCursor4, "ArrowCursor4");
	DoImageLoad (pPerpetuaFont_48_BlueImage, PerpetuaFont_48_Blue, "PerpetuaFont_48_Blue");
	DoImageLoad (pPaceMakerSplashScreenImage, PaceMakerSplashScreen, "PaceMakerSplashScreen");
	DoImageLoad (pCourierNew_16_WhiteOnBlackImage, CourierNew_16_WhiteOnBlack, "CourierNew_16_WhiteOnBlack");
	DoImageLoad (pSlider_VerticalImage, Slider_Vertical, "Slider_Vertical");
	DoImageLoad (pBackgroundStarsImage, BackgroundStars, "BackgroundStars");
	DoImageLoad (pGreenCircleImage, GreenCircle, "GreenCircle");

	DoImageLoadAll (LightBar4x4);
	
	return (true);
}

