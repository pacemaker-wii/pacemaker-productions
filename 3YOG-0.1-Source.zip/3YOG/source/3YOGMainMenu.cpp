
// Main Menu
#include "3YOGWorld.h"
#include "3YOGMainMenu.h"


enum { MENU_TOGGLE_DEBUG_MSGS = 0, MENU_SKIP_LEVEL, MENU_QUIT_GAME, MENU_RETURN_TO_LOADER, MENU_BACK };


const char * MainMenu::szMenuItems  [] = {"Toggle Debug Messages",  "Skip Level",
											"Quit Game", "Return to Loader", "Back"};


static BibWiiInputDevice::SingleAction saMainMenuAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_HOME},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_HOME},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_HOME},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_HOME}
																};
static BibWiiInputDevice::SingleAction saMainMenuUpAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_UP},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_RIGHT},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_RIGHT},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_RIGHT}
																};
static BibWiiInputDevice::SingleAction saMainMenuDownAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_DOWN},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_LEFT},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_LEFT},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_LEFT}
																};
static BibWiiInputDevice::SingleAction saMainMenuSelectAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2}
																};
static BibWiiInputDevice::SingleAction saMainMenuBackAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_B},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_1},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_1},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_1}
																};


void MainMenu::Initialize (YOGWorld * _pWorld)
{
	pWorld = _pWorld;

	WiiMainMenuAction= pWorld->WiiInputDevice.DefineAction (saMainMenuAction);
	WiiMainMenuUpAction= pWorld->WiiInputDevice.DefineAction (saMainMenuUpAction);
	WiiMainMenuDownAction= pWorld->WiiInputDevice.DefineAction (saMainMenuDownAction);
	WiiMainMenuSelectAction= pWorld->WiiInputDevice.DefineAction (saMainMenuSelectAction);
	WiiMainMenuBackAction= pWorld->WiiInputDevice.DefineAction (saMainMenuBackAction);
}


/*
	This is called every game loop.
*/
bool MainMenu::UpdateMovement (void)
{
YOGWorld::eGameStateType eGameState;
int nMenuChoice;

	eGameState = pWorld->GetGameState ();

	if (eGameState == YOGWorld::MAIN_MENU)
	{

		if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuDownAction))
		{
			bmMainMenu.ProcessInput(BibMenus::INPUT_DOWN);
		}
		else if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuUpAction))
		{
			bmMainMenu.ProcessInput(BibMenus::INPUT_UP);
		}
		else if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuSelectAction))
		{
			nMenuChoice = bmMainMenu.ProcessInput(BibMenus::INPUT_SELECT);
			if (nMenuChoice >= 0)
			{
				if (nMenuChoice == MENU_TOGGLE_DEBUG_MSGS)	// Toggle Debug Info.
				{
					if (pWorld->bDebugOn)
						pWorld->bDebugOn = FALSE;
					else
						pWorld->bDebugOn = TRUE;
					pWorld->PopGameState ();
				}
				else if (nMenuChoice == MENU_SKIP_LEVEL)	// Skip Level
				{
					// SkipLevel sets the game state.
					pWorld->SkipLevel ();
				}
				else if (nMenuChoice == MENU_QUIT_GAME)	// Quit Game
				{
					pWorld->SetGameState (YOGWorld::GAME_OVER);
				}
				else if (nMenuChoice == MENU_RETURN_TO_LOADER)	// Return to Loader
				{
					exit (0);
				}
				else if (nMenuChoice == MENU_BACK)	// Back
				{
					// Don't do anything, just exit the menu.
					pWorld->PopGameState ();
				}
				pWorld-> GetView () -> fps . ReInit ();
			}
			
		}
		else if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuBackAction))
		{
			if (bmMainMenu.ProcessInput(BibMenus::INPUT_BACK) == -2)
			{
				pWorld->PopGameState ();
				pWorld-> GetView () -> fps . ReInit ();
			}
		}

		return (true);
	}
	else if (pWorld->WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiMainMenuAction))
	{
		if (eGameState != YOGWorld::MAIN_MENU)
		{
			bmMainMenu.Initialize ();
			bmMainMenu.SetupListBox("Main Menu", szMenuItems, sizeof (szMenuItems) / sizeof (char *));
			pWorld->PushGameState (YOGWorld::MAIN_MENU);
		}
		return (true);
	}


	return (false);
}

