// SliderOb

#include <math.h>

#include <wiisprite.h>
#include "BibLib/BibScreenFont.h"
#include "SliderOb.h"
#include "ImageServer.h"



#define SLIDER_WIDTH (bsSlider.GetImage()->GetWidth())
#define SLIDER_HEIGHT (bsSlider.GetImage()->GetHeight())
#define SLIDERSTICK_WIDTH (bsSliderStick.GetImage()->GetWidth())
#define SLIDERSTICK_HEIGHT (bsSliderStick.GetImage()->GetHeight())
#define SLIDER_ENDCAP_SIZE 25
#define SLIDERV_ENDCAP_SIZE 15
#define USABLE_SLIDER_WIDTH (SLIDER_WIDTH - (SLIDER_ENDCAP_SIZE * 2))
#define USABLE_SLIDER_HEIGHT (SLIDER_HEIGHT - (SLIDERV_ENDCAP_SIZE * 2))

SliderOb::SliderOb ()
{
	nMin = 0;
	nMax = 100;
	nPos = 0;
	nTransparency = 255;
	eType = SLIDER_HORIZONTAL;
}

SliderOb::~SliderOb ()
{
}

void SliderOb::Initialize (eSliderTypes ineType)
{
	eType = ineType;
	
	if (eType == SLIDER_HORIZONTAL)
	{
		bsSlider . SetImage (isImageServer.GetSliderImage ());
		bsSliderStick . SetImage (isImageServer.GetSliderStickImage ());
	}
	else if (eType == SLIDER_VERTICAL)
	{
		bsSlider . SetImage (isImageServer.GetSlider_VerticalImage ());
		bsSliderStick . SetImage (isImageServer.GetSliderStickImage ());
		bsSliderStick . SetRotation (90/2);
	}
}

void SliderOb::SetRange (int _nMin, int _nMax)
{
	nMin = _nMin;
	nMax = _nMax;
}

void SliderOb::SetPosition (int _nPos)
{
	nPos = _nPos;
	
	if (nPos < nMin)
		nMin = nPos;
	if (nPos > nMax)
		nMax = nPos;
}


void SliderOb::Render (BibScreenFont & ScreenFont, int x, int y)
{
char szBuf [64];
int nBarDist;	// How far along the bar do we place the slider stick.


	if (eType == SLIDER_HORIZONTAL)
	{
		/*
			Set basic parameters of slider bar ( I-----I thingy)
		*/
		bsSlider.SetPosition (x, y);
		bsSlider.SetTransparency (nTransparency);
		bsSlider.Draw ();
		

		/*
			Display Text for min and max, at ends of slider bar.
		*/
		sprintf (szBuf, "%03d", nMin);
		ScreenFont.DisplayText (x, y - 18, szBuf, nTransparency);
		sprintf (szBuf, "%03d", nMax);
		ScreenFont.DisplayText (x + SLIDER_WIDTH - 50, y - 18, szBuf, nTransparency);


		/*
			Display slider stick and text
		*/
		
		// Determine where to place the slider stick ( I thingy)
		nBarDist = ((nPos * USABLE_SLIDER_WIDTH) / (nMax - nMin)) + nMin + SLIDER_ENDCAP_SIZE;
		
		// Set basic parameters for stlider stick.
		bsSliderStick.SetPosition(x + nBarDist, y);
		bsSliderStick.SetTransparency (nTransparency);
		bsSliderStick.Draw ();
		
		// Display text for slider stick.
		sprintf (szBuf, "%02d", nPos);
		ScreenFont.DisplayText (x + nBarDist - 8, y - 18, szBuf, nTransparency);
	}
	else if (eType == SLIDER_VERTICAL)
	{
		/*
			Set basic parameters of slider bar ( I-----I thingy)
		*/
		bsSlider.SetPosition (x, y);
		bsSlider.SetTransparency (nTransparency);
		bsSlider.Draw ();
		

		/*
			Display Text for min and max, at ends of slider bar.
		*/
		sprintf (szBuf, "%03d", nMax);
		ScreenFont.DisplayText (x + 12, y - 18, szBuf, nTransparency);
		sprintf (szBuf, "%d", nMin);
		ScreenFont.DisplayText (x + 24, y + SLIDER_HEIGHT + 3, szBuf, nTransparency);


		/*
			Display slider stick and text
		*/
		
		// Determine where to place the slider stick ( I thingy)
		nBarDist = ((nPos * USABLE_SLIDER_HEIGHT) / (nMax - nMin)) + nMin;
		
		// Set basic parameters for stlider stick.
		bsSliderStick.SetPosition(x + SLIDERSTICK_WIDTH + 7, y + (USABLE_SLIDER_HEIGHT - nBarDist) - SLIDERSTICK_WIDTH);
			// +7 is a fudge factor, since I can't seem to get it right.
		bsSliderStick.SetTransparency (nTransparency);
		bsSliderStick.Draw ();
		
		// Display text for slider stick.
		sprintf (szBuf, "%02d", nPos);
		ScreenFont.DisplayText (x + SLIDERSTICK_HEIGHT, y + (USABLE_SLIDER_HEIGHT - nBarDist), szBuf, nTransparency);

	}

}

