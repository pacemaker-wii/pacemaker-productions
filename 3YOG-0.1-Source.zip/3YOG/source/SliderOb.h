// SliderOb


/*
	!!! Ideally this class could be scaled to be big or small.
*/


class SliderOb
{
public:
	enum eSliderTypes { SLIDER_HORIZONTAL, SLIDER_VERTICAL };

private:
	wsp::Sprite bsSlider;
	wsp::Sprite bsSliderStick;
	int nMin;
	int nMax;
	int nPos;
	int nTransparency;

	eSliderTypes eType;

public:
	SliderOb ();
	~SliderOb ();

	void Initialize (eSliderTypes eType);	//Horizontal or Vertical.
	void SetRange (int nMin, int nMax);
	void SetPosition (int nPos);
	// 0 = Transparent, 0xFF = Opaque
	void SetTransparency (int nTrans) { nTransparency = nTrans; }

	int GetMin (void) { return (nMin); }
	int GetMax (void) { return (nMax); }
	int GetPos (void) { return (nPos); }

	void Render (BibScreenFont & ScreenFont, int x, int y);

};

