/*

	Hero Control Class

*/

#include <wiisprite.h>
#include "GameConstants.h"
#include "HeroCtrl.h"
#include "3YOGWorld.h"
#include "ImageServer.h"


#define FRAMES_TO_BUZZ	12


static BibWiiInputDevice::SingleAction saFire [MAX_ACTION_SETS] = {
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_B},
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2},
																	{BibWiiInputDevice::CTRL_GAMECUBE, PAD_BUTTON_A}
																   };

static BibWiiInputDevice::SingleAction saForce [MAX_ACTION_SETS] = {
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_B},
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_1},
																	{BibWiiInputDevice::CTRL_GAMECUBE, PAD_BUTTON_B}
																   };

static BibWiiInputDevice::SingleAction saBomb [MAX_ACTION_SETS] = {
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_MINUS},
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_MINUS},
																	{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_MINUS},
																	{BibWiiInputDevice::CTRL_GAMECUBE, PAD_TRIGGER_Z}
																   };

char szHeroMsg [256];	//!!!!

#ifdef GCUBE_EMU
bool bEmuForceButton = false;
extern int nGCubeEmuCounter1;
#endif

HeroCtrl::HeroCtrl ()
{
}

HeroCtrl::~HeroCtrl ()
{
}

void HeroCtrl::Initialize (class YOGWorld * inpWorld, int nHeroNum)
{
	ControlOb::Initialize (inpWorld);
	
	pWorld = inpWorld;

	// Add the sprites.
	switch (nHeroNum)
	{
		default: sSpriteData.SetImage (isImageServer.GetHeroImage ()); break;
		case 0: sSpriteData.SetImage (isImageServer.GetArrowCursor1Image ()); break;
		case 1: sSpriteData.SetImage (isImageServer.GetArrowCursor2Image ()); break;
		case 2: sSpriteData.SetImage (isImageServer.GetArrowCursor3Image ()); break;
		case 3: sSpriteData.SetImage (isImageServer.GetArrowCursor4Image ()); break;
	}

	sSpriteData.SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);
	sSpriteData.SetRefPixelPosition(48, 0);
	sSpriteData.SetTransparency (160);


	WiiFireAction = pWorld->WiiInputDevice.DefineAction (saFire);
	WiiForceAction = pWorld->WiiInputDevice.DefineAction (saForce);
	WiiBombAction = pWorld->WiiInputDevice.DefineAction (saBomb);

	MyHeroNum = nHeroNum;
	Reset ();

}

void HeroCtrl::UnInitialize ()
{

}


void HeroCtrl::Reset (void)
{
	bpMyLocation.x = 0;
	bpMyLocation.y = 0;
	MyAngle = 0;
	MyDistance = 0;
	bInfoValid = false;
	bDrawLine = false;
	nScore = 0;
	
	ResetForNewLevel ();
}

void HeroCtrl::ResetForNewLevel (void)
{
	nPushersLeft = 30;
	nBurstsLeft = 5;
}


bool HeroCtrl::IsActive (void)
{
	if (pWorld->WiiInputDevice.IsPresent (BibWiiInputDevice::CTRL_WII_REMOTE, MyHeroNum))
	{
		return (bInfoValid);
	}
	else
	{
		return (false);
	}
}


bool HeroCtrl::UpdateMovement (float fSpeedFactor)
{
	if (! pWorld->WiiInputDevice.IsPresent (BibWiiInputDevice::CTRL_WII_REMOTE, MyHeroNum))
	{
		if (MyHeroNum == 0)
			sprintf (szHeroMsg, "H0: Not Present %d", MyHeroNum);

		return (false);
	}

	if (MyHeroNum == 0) sprintf (szHeroMsg, "H0: Pre ctrlob::Update");

	// Call the base class to update sprite data, etc.
	if (ControlOb::UpdateMovement (fSpeedFactor))
	{
		bool bStatus;
		int x, y, z, angle;
		
		if (MyHeroNum == 0) sprintf (szHeroMsg, "H0: Pre Wii_Cursor");
		bStatus = pWorld->WiiInputDevice.Wii_Cursor (MyHeroNum, x, y, z, angle);

		if (bStatus)
		{
			bpMyLocation.x = x;
			bpMyLocation.y = y;
			MyDistance = z;
			MyAngle = angle;
			bInfoValid = true;
			
			if (MyHeroNum == 0) sprintf (szHeroMsg, "H0: Cursor (%d,%d,%d,%d)", bpMyLocation.x, bpMyLocation.y, MyDistance, MyAngle);

#ifdef GCUBE_EMU
			bEmuForceButton = false;
			if ((MyHeroNum == 0) && (nGCubeEmuCounter1 == 10)) 
			{
				bEmuForceButton = true;
			}
#endif
			if (pWorld->WiiInputDevice.ActionDown (MyHeroNum, WiiFireAction))
			{
				if (nPushersLeft > 0)
				{
					nPushersLeft --;
					int xForce = sin(angle * 3.14159/180) * 100000;
					int yForce = cos(angle * 3.14159/180) * -100000;
					pWorld->DWorld.CreatePusher (xForce, yForce, x, y, angle);
				}
			}

#ifdef GCUBE_EMU
			bEmuForceButton = false;
			if ((MyHeroNum == 0) && (nGCubeEmuCounter1 > 48) && (nGCubeEmuCounter1 < 88))
			{
				bEmuForceButton = true;
			}
#endif
			
			if (pWorld->WiiInputDevice.ActionHeld (MyHeroNum, WiiForceAction))
			{
				nScore --;
				pWorld->DWorld.ApplyForce (x, y);
				bDrawLine = true;
			}
			else
			{
				bDrawLine = false;
			}


#ifdef GCUBE_EMU
			bEmuForceButton = false;
			if ((MyHeroNum == 0) && (nGCubeEmuCounter1 == 175))
			{
				bEmuForceButton = true;
			}
#endif
			if (pWorld->WiiInputDevice.ActionDown (MyHeroNum, WiiBombAction))
			{
				if (nBurstsLeft > 0)
				{
					nBurstsLeft --;

					int radius = 5;
					for (int i = 0; i < 360; i += 20)
					{
						radius = i / 10;
						if (radius > 20)
							radius = 20;
						pWorld->DWorld.CreateBurst (x + radius * cos(i * 3.14159 / 180), y + radius * sin(i * 3.14159 / 180), angle);
					}
				}
			}
#ifdef GCUBE_EMU
			bEmuForceButton = false;
#endif
			
		}
		else
		{
			bInfoValid = false;
		}

	
		return (true);
	}

	return (false);
}


wsp::Sprite * HeroCtrl::GetCurSprite (void)
{
	sSpriteData.SetPosition (bpMyLocation.x, bpMyLocation.y);
	sSpriteData.SetRotation (MyAngle/2);
	return (& sSpriteData);
}

void HeroCtrl::GetLocation (int & x, int & y, int & z, int & angle)
{
	x = bpMyLocation.x;
	y = bpMyLocation.y;
	z = MyDistance;
	angle = MyAngle;
}

