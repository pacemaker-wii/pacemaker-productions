
// ImageServer to share image data.

#include <wiisprite.h>
#include "ImageServer.h"


#include "Sprites/XmasCountdownBackground.sprite.h"
#include "Sprites/CalcFont32.sprite.h"
#include "Sprites/PaceMakerSplashScreen.sprite.h"
#include "Sprites/CourierNewFont16.sprite.h"
#include "Sprites/PepperMintHandPointer.sprite.h"

#define DoImageLoadAll(image_var) \
	p ## image_var ## Image = new wsp::Image (); \
	iStatus = p ## image_var ## Image ->LoadImage(image_var); \
	if (iStatus != wsp::IMG_LOAD_ERROR_NONE) \
	{ \
		sprintf (szLastError, "\n\n Image Load Error %s = (%d)\n", #image_var, iStatus); \
		nLastError = iStatus; \
		return (false); \
	}

ImageServer::ImageServer ()
{
}


ImageServer::~ImageServer ()
{
}


bool ImageServer::Initialize (void)
{
wsp::IMG_LOAD_ERROR iStatus;

	szLastError [0] = 0;
	nLastError = 0;
	
	DoImageLoadAll (XmasCountdownBackground);
	DoImageLoadAll (CalcFont32);
	DoImageLoadAll (PaceMakerSplashScreen);
	DoImageLoadAll (CourierNewFont16);
	DoImageLoadAll (PepperMintHandPointer);
	
	return (true);
}

