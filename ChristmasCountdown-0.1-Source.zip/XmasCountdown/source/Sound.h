/*

	Sound.h

*/

#include "BibLib/BibSound.h"

class XmasCountdownSound : public BibSound
{
private:

public:
	XmasCountdownSound ();

	enum eSounds { SND_OUCH, MP3_SILENT_NIGHT };

	int PlaySound (eSounds eThisSound);

};
