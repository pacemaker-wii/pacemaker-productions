//
// Main.cpp : Defines the entry point for the application.
//

/*
	Includes
*/

#include <malloc.h>
#include <wiisprite.h>
#include "GameConstants.h"


#include "View.h"
#include "World.h"
#include "ImageServer.h"
#include "wsp_Console.h"


// Global so all objects can access it.
ImageServer isImageServer;






/*
	Main Entry Point.
*/
int main (void)
{

	/* initialize random seed: */
	srand (time(NULL));

	/*
		Global Game Objects
	*/
	wsp::GameWindow gwd;
	gwd.InitVideo();
	gwd.SetBackground((GXColor){ 0, 0, 128, 255 });
	gwd.Flush();


	// Object to hold all of the images
	//  so they won't be loaded into memory twice.
	if (! isImageServer.Initialize ())
	{
		gwd.SetBackground((GXColor){ 255, 0, 0, 255 });
		gwd.Flush();
		// Error initializing ImageServer....program will now hang.
		while (1);
	}

	// Set background to black after initializations have succeeded.
	gwd.SetBackground((GXColor){ 255, 255, 255, 255 });

	/*
		Create some significant Game objects.
		Put these on the heap, not stack.
	*/
	XmasCountdownView  * pView = new XmasCountdownView ();
	XmasCountdownWorld * pWorld = new XmasCountdownWorld ();
#ifndef PRODUCTION
	wsp_Console * wspConsole = new wsp_Console();
#endif

	pView -> Initialize ();
	pWorld -> SetView (pView);
	pWorld -> Initialize (wsp::GameWindow::GetWidth(), wsp::GameWindow::GetHeight());
	pView -> SetWorld (pWorld);
	pView -> fps . Init (EXPECT_FRAMES_PER_SECOND);

#ifndef PRODUCTION
	wspConsole->InitConsole ();
#endif

#ifdef EXECUTE_UNIT_TESTS
	#include "UnitTests/UnitTests.h"
	DoUnitTests ();
#endif


	// enter main event loop
    while(1)
    {
		// Update the frames-per-second data.
		pView -> fps . SetSpeedFactor ();

		// Move/update all objects.
		pWorld -> UpdateMovement (pView->fps.fspeedfactor);

		// Render the view into the Memory Device Context (the screen).
#ifndef EXECUTE_UNIT_TESTS
		pView -> Render ();
#endif
		
#ifndef PRODUCTION
		// printf support
		wspConsole->RenderConsole ();
#endif

		// Get Start time for Flush.
		pView -> fps . MeasPreFlush ();

		// Put the back buffer into the screen.
		gwd.Flush();
	
		// Get Stop time and do calculation
		pView -> fps . MeasPostFlush ();

    } // end while


	return 0;
}


