// World.h: interface for the World class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "GameConstants.h"
#include "BibLib/BibWiiInputDevice.h"
#include "BibLib/BibPoint.h"

#include "View.h"
#include "Sound.h"


class XmasCountdownWorld
{
public:	
	enum eGameStateType { SPLASH_SCREEN_PACEMAKER, XMAS_COUNTDOWN };
	
	BibWiiInputDevice WiiInputDevice;

	// Sounds object
	XmasCountdownSound pSound;


private:

	// FORTNIGHT = 14 days.
	enum eTimeLeftUnitsType { TLU_DHMS = 0, TLU_DAYS, TLU_HOURS, TLU_MINUTES, TLU_SECONDS, TLU_WEEKS, TLU_FORTNIGHT, TLU_NANOSECONDS, TLU_KIDTIME, TLU_LAST_ONE };

	eTimeLeftUnitsType eTimeLeftUnits;

	class XmasCountdownView * pView;
	wsp::Sprite bsBackgroundPic;


	// From WiiInputDevice ActionMap
	//   To skip splash screen.
	int WiiSplashScreenAction;
	int WiiPressAction;
	int WiiAltPressAction;
	int WiiHomeAction;
	
	void UpdateWiiRemoteInfo (void);
	
	eGameStateType eGameState;
	int nGameStateCounter;
	
	unsigned int nScore;
	void UpdateTimeLeftString (void);
	time_t TimeLeftInSeconds;
	char szTimeLeftString [3] [64];
	
	
	time_t FindTimeLeftToXmas (time_t CurTime);


public:
	XmasCountdownWorld();
	virtual ~XmasCountdownWorld();

	void Initialize (int nWidth, int nHeight);
	void UnInitialize (void);


	void SetView (XmasCountdownView * inpView) { pView = inpView; }
	XmasCountdownView * GetView (void) { return (pView); }

	// Background Sprite accessor method.
	wsp::Sprite & GetBackgroundSprite (void) { return bsBackgroundPic; }


	void UpdateMovement (float fSpeedFactor);

	// Game State methods.
	eGameStateType GetGameState (void) { return (eGameState); }
	void SetGameState (eGameStateType ineGameState) { eGameState = ineGameState; }
	

	bool GetPointer (int nWiiRemote, int & xLoc, int & yLoc, int & nAngle);
	unsigned int GetScore (void) { return (nScore); }
	char * GetString (int StringNumber) { return (szTimeLeftString [StringNumber]); }
};

