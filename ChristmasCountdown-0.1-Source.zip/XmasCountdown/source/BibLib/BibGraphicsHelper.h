// BibGraphicsHelper


class BibGraphicsHelper
{
private:
	

public:
	static void DrawLine (int x1, int y1, int x2, int y2, wsp::Sprite * sprite);

};
