// BibPoint.cpp: implementation of the BibPoint class.
//
//////////////////////////////////////////////////////////////////////

#include <math.h>

#include "BibPoint.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

BibPoint::BibPoint(int inx, int iny, int inz)
{
	x = inx;
	y = iny;
	z = inz;
}


BibPoint::~BibPoint()
{

}



void BibPoint::SetSize (int inx, int iny)
{
	x = inx;
	y = iny;
}

void BibPoint::SetSize (int inx, int iny, int inz)
{
	x = inx;
	y = iny;
	z = inz;
}

bool BibPoint::operator== (BibPoint &other)
{
	return  (x == other.x) &&
			(y == other.y) &&
			(z == other.z);
}


BibPoint BibPoint::operator+ (BibPoint &other)
{
	return BibPoint (x + other . x, y + other . y, z + other . z);
}


BibPoint BibPoint::operator- (BibPoint &other)
{
	return BibPoint (x - other . x, y - other . y, z - other . z);
}


BibPoint BibPoint::operator+ (int fScalar)
{
	return BibPoint (x + fScalar, y + fScalar, z + fScalar);
}

BibPoint BibPoint::operator- (int fScalar)
{
	return BibPoint (x - fScalar, y - fScalar, z - fScalar);
}


BibPoint BibPoint::operator/ (int fDenominator)
{
	return BibPoint (x / fDenominator, y / fDenominator, z / fDenominator);
}


BibPoint BibPoint::operator* (int fScalar)
{
	return BibPoint (x * fScalar, y * fScalar, z * fScalar);
}

int BibPoint::Dot (BibPoint & other)
{

    return (x*other.x + y*other.y + z*other.z);
}


int BibPoint::Magnitude (void)
{
int fLen;

	fLen = (int) sqrt ((double) (x*x + y*y + z*z));
	return (fLen);
}

void BibPoint::Normalize (void)
{
int fLen;

	fLen = Magnitude ();
	x = x / fLen;
	y = y / fLen;
	z = z / fLen;

//	ASSERT (Magnitude() > .99);
//	ASSERT (Magnitude() < 1.01);
}


int BibPoint::DistanceSquared (BibPoint & other)
{
	return ((other.x - x) * (other.x - x) + 
		    (other.y - y) * (other.y - y) + 
			(other.z - z) * (other.z - z));
}

int BibPoint::Distance (BibPoint & other)
{
	return (int) sqrt ((double) DistanceSquared (other));
}

