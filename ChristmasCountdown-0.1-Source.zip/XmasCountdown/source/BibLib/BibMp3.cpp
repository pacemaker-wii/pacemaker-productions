// BibMp3


#include <stdio.h>
#include <malloc.h>
#include "BibSound.h"



static BibMp3 * pThis = NULL;

#ifdef DEBUG_BIBSOUND
extern char szDebugMsg3 [256];
static int nCounter = 0;
static int nFalseCounter = 0;
#endif

/*
 * This is the input callback. The purpose of this callback is to (re)fill
 * the stream buffer which is to be decoded. Give out the data a chunk at
 * a time so we can switch to a new mp3 song easier.
 */

#define MAX_INPUT_SIZE 4096

static enum mad_flow input(void *data, struct mad_stream *stream)
{
BibMp3::MsgBufferType *buffer = (BibMp3::MsgBufferType *) data;

#if 0
int nNewLength; 

	if (buffer->CurPos >= buffer->start + buffer->length)
		buffer->CurPos = buffer->start;
		
	nNewLength = ((buffer->start + buffer->length) - buffer->CurPos);
	if (nNewLength > 4096)
	{
		nNewLength = 4096;
	}
	
	mad_stream_buffer(stream, buffer->CurPos, nNewLength);
	
	buffer->CurPos += nNewLength;
else
#endif
{
	mad_stream_buffer(stream, buffer->start, buffer->length);
}


	return MAD_FLOW_CONTINUE;
	// Use: return MAD_FLOW_STOP; // to stop providing input.
}




/*
 * The following utility routine performs simple rounding, clipping, and
 * scaling of MAD's high-resolution samples down to 16 bits. It does not
 * perform any dithering or noise shaping, which would be recommended to
 * obtain any exceptional audio quality. It is therefore not recommended to
 * use this routine if high-quality output is desired.
 */

static inline signed int scale(mad_fixed_t sample)
{
  /* round */
  sample += (1L << (MAD_F_FRACBITS - 16));

  /* clip */
  if (sample >= MAD_F_ONE)
    sample = MAD_F_ONE - 1;
  else if (sample < -MAD_F_ONE)
    sample = -MAD_F_ONE;

  /* quantize */
  return sample >> (MAD_F_FRACBITS + 1 - 16);
}

/*
 * This is the output callback function. It is called after each frame of
 * MPEG audio data has been completely decoded. The purpose of this callback
 * is to output (or play) the decoded PCM audio.
 */
#if 0	// This does not handle sample rates other than 48000Hz.  Delete this.
static enum mad_flow output(void *data,
		     struct mad_header const *header,
		     struct mad_pcm *pcm)
{
unsigned int nsamples;
mad_fixed_t const *left_ch, *right_ch;
unsigned int * pSndBuf;
unsigned short LeftSample, RightSample;


	nsamples  = pcm->length;
	left_ch   = pcm->samples[0];
	right_ch  = pcm->samples[1];


	pSndBuf = (unsigned int *) malloc (pcm->length * 4);
	for (int i = 0; i < pcm->length; i ++)
	{
		LeftSample = scale (pcm->samples[0][i]);
		RightSample = scale (pcm->samples[1][i]);
		pSndBuf [i] = ((LeftSample & 0xFFFF) << 16) | (RightSample & 0xFFFF);
	}
	
	pThis->AddToPlayBuffer (pSndBuf, pcm->length * 4);
	
	free (pSndBuf);


  return MAD_FLOW_CONTINUE;
}
#endif

static enum mad_flow output_with_sample_rate_adjustment (void *data, struct mad_header const *header, struct mad_pcm *pcm)
{
unsigned int nSrcSamples, nDestSamples;
unsigned short LeftSample, RightSample;
unsigned int * pDestSndBuf;
unsigned int DestSndBufLenBytes;
unsigned int nSrcSampleIndex;
#define SAMPLE_RATE_MULTIPLIER 48000 / pcm->samplerate	//!!!! This makes some assumptions about order of operations.




	nSrcSamples = pcm->length;
	DestSndBufLenBytes = pcm->length * 4 * SAMPLE_RATE_MULTIPLIER;
	nDestSamples = pcm->length * SAMPLE_RATE_MULTIPLIER;

	pDestSndBuf = (unsigned int *) malloc (DestSndBufLenBytes);

/*
	printf ("MP3 Sample Rate = %d\n", pcm->samplerate);

	printf ("MadOutput: nSrcSamples: %d, LenBytes: %d\n", nSrcSamples, DestSndBufLenBytes);
	printf ("MadOutput: %f, %f\n", (float) 48000.0f, (float) 48000.0f / pcm->samplerate);
	printf ("MadOutput: %d, %d, %d =? %d\n", pcm->length, pcm->length * 4, pcm->length * 4 * SAMPLE_RATE_MULTIPLIER, DestSndBufLenBytes);
*/	
	
	// Copy data from mad output into Wii formatted sound buffer.
	// Stretch data for mismatched sample rates.
	for (unsigned int i = 0; i < nDestSamples; i ++)
	{
		nSrcSampleIndex = (int) (i * pcm->samplerate / 48000.0);
		
		LeftSample = scale (pcm->samples[0][nSrcSampleIndex]);
		RightSample = scale (pcm->samples[1][nSrcSampleIndex]);

		pDestSndBuf [i] = ((LeftSample & 0xFFFF) << 16) | (RightSample & 0xFFFF);
	}
	
	pThis->AddToPlayBuffer (pDestSndBuf, DestSndBufLenBytes);
	
	free (pDestSndBuf);


  return MAD_FLOW_CONTINUE;
}




/*
 * This is the error callback function. It is called whenever a decoding
 * error occurs. The error is indicated by stream->error; the list of
 * possible MAD_ERROR_* errors can be found in the mad.h (or stream.h)
 * header file.
 */

static enum mad_flow error(void *data,
		    struct mad_stream *stream,
		    struct mad_frame *frame)
{
	BibMp3::MsgBufferType *buffer = (BibMp3::MsgBufferType *) data;
	printf("decoding error 0x%04x (%s) at byte offset %u\nDid you forget to remove the ID3 tags?\n",
			stream->error, mad_stream_errorstr(stream),
			stream->this_frame - buffer->start);

  /* return MAD_FLOW_BREAK here to stop decoding (and propagate an error) */
	return (MAD_FLOW_BREAK);
	//return (MAD_FLOW_CONTINUE);
}






BibMp3::BibMp3 ()
{
	pSound = NULL;
	pThis = this;
	ThreadHandle = LWP_THREAD_NULL;
	ThreadQueue = LWP_TQUEUE_NULL;
	nCurPlayingIndex = -1;
}

BibMp3::~BibMp3 ()
{
}





static void * ThreadFunction (void * pArg)
{
int nResult;

	/* configure input, output, and error functions */
	mad_decoder_init(&pThis->decoder, &pThis->MsgBuffer,
		   input, 0 /* header */, 0 /* filter */, output_with_sample_rate_adjustment,
		   error, 0 /* message */);

	/* start decoding */
	nResult = mad_decoder_run(&pThis->decoder, MAD_DECODER_MODE_SYNC);

	/* release the decoder */
	mad_decoder_finish(&pThis->decoder);

	return (NULL);
}






/*
	Only one Mp3 decoding at once.  If Initialize is called a second time,
	then we stop the thread and restart the decoding (same mp3 or different mp3).
*/
int BibMp3::Initialize (class BibSound * inpSound, int nIndex, unsigned char * pData, int nLength)
{
	if (ThreadHandle != LWP_THREAD_NULL)
	{
		// Thread is running.

		// Save which Mp3 is playing.
		nCurPlayingIndex = nIndex;

		/* initialize our private message structure */
		// This will be picked up in the next input() call.
		MsgBuffer.start  = pData;
		MsgBuffer.CurPos  = pData;
		MsgBuffer.length = nLength;
		
		nAvoidSleepCounter = 3;
		
		return (-1);
	}

	// Check to see if the thread exists already.
	// If it doesn't exist, create it.
	if (ThreadHandle == LWP_THREAD_NULL)
	{
		// Save the BibSound pointer.
		pSound = inpSound;

		// Save which Mp3 is playing.
		nCurPlayingIndex = nIndex;

		nDestBuf = 0;	// May start 2 seconds late if I guess the wrong buffer.
		nDestPos = 0;

		nAvoidSleepCounter = 3;

		/* initialize our private message structure */
		MsgBuffer.start  = pData;
		MsgBuffer.CurPos  = pData;
		MsgBuffer.length = nLength;

		LWP_InitQueue (&ThreadQueue);

		// Need to create a separate thread here.
		LWP_CreateThread (&ThreadHandle, ThreadFunction, NULL, ThreadStack, MP3_THREAD_STACK_SIZE, 80);
	}

	return (ThreadHandle);
}


void BibMp3::ThreadSleep (void)
{
	LWP_ThreadSleep (ThreadQueue);
}

void BibMp3::ThreadRun (void)
{
	if (ThreadQueue != LWP_TQUEUE_NULL)
		LWP_ThreadSignal (ThreadQueue);
}


/*
	Add to playing buffer or sleep the thread until it can be added.
*/
void BibMp3::AddToPlayBuffer  (unsigned int * pSndBuf, int nSamples)
{
bool bStatus;

	
	// Loop until we successfully add the data to the play buffer.
	//  Since decoding may be well ahead of playing, we might have to pause the thread.
	do
	{
		// This takes a buffer and a buffer location since
		//	the mp3 decoding will typically run ahead of the playing.
		//  This also means that the sound object needs to be double buffered.
		//  This also means that the function can reject the data and we'll 
		//  retry later.
		bStatus = pSound->AddToPlayBuffer (pSndBuf, nSamples, &nDestBuf, &nDestPos);
#ifdef DEBUG_BIBSOUND
		if (bStatus == false)
			nFalseCounter ++;

		sprintf (szDebugMsg3, "Mp3: (%d) Samples=%d, AddToBuf (%s) FC=%d, DBuf=%d, DPos=%d", nCounter++, nSamples, bStatus ? "true" : "false", nFalseCounter, nDestBuf, nDestPos);
#endif

		//Throttling mechanism.  Decoding should be ahead of playing.
		if (nAvoidSleepCounter == 0)
		{
			pThis->ThreadSleep ();
			nAvoidSleepCounter = 3;
		}
		else
			nAvoidSleepCounter --;

	}
	while (! bStatus);


	return;
}
