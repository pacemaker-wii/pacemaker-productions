/*
	wsp_console class

	console (printf) support for libwiisprite
*/




class wsp_Console
{
private:
	BibScreenFont CourierNew_ScreenFont;

public:
	void InitConsole (void);
	void RenderConsole (void);
};
