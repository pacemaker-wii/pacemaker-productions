// Unit Tests

#include <stdio.h>
#include <string.h>
#include <math.h>

int nPassedCounter;
int nFailedCounter;

//#define PRINT_PASSES

bool CheckExpectedDataDouble (double fExpected, double fActual, double fMargin, const char * szTestName)
{
	if ((fActual >= fExpected - fMargin) && 
		(fActual <= fExpected + fMargin))
	{
		nPassedCounter ++;
#ifdef PRINT_PASSES
		printf ("%s (%g == %g): passed\n", szTestName, fExpected, fActual);
#endif
		return (true);
	}
	else
	{
		nFailedCounter ++;
		printf ("%s: FAILED (%g != %g (+/- %g)\n", szTestName, fExpected, fActual, fMargin);

		printf ("\t%g >= %g\n", fActual, fExpected - fMargin);
		printf ("\t%g <= %g\n", fActual, fExpected + fMargin);
		printf ("\tDelta %g\n", fActual - fExpected);

		return (false);
	}
}


bool CheckExpectedDataString (const char * szExpected, const char * szActual, const char * szTestName)
{
	if (strcmp (szExpected, szActual) == 0)
	{
		nPassedCounter ++;
#ifdef PRINT_PASSES
		printf ("%s (\"%s\" == \"%s\"): passed\n", szTestName, szExpected, szActual);
#endif
		return (true);
	}
	else
	{
		nFailedCounter ++;
		printf ("%s: FAILED (\"%s\" != \"%s\")\n", szTestName, szExpected, szActual);
		return (false);
	}
}


void TestOne (void)
{
	CheckExpectedDataString ("0", "0", __func__);
	CheckExpectedDataDouble (0, 0, 0, __func__);
}


void DoUnitTests (void)
{

	nPassedCounter = 0;
	nFailedCounter = 0;


	/*
		Tests
	*/

	TestOne ();
	
	printf ("%d Passed, %d Failed\n", nPassedCounter, nFailedCounter);

}


