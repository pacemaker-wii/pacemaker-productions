// View.h: interface for the View class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <wiisprite.h>
#include "BibLib/BibScreenFont.h"
#include "BibLib/BibFrameRate.h"

class XmasCountdownView
{
private:
	BibScreenFont Calc_ScreenFont;
	class XmasCountdownWorld * pWorld;

	wsp::Sprite PaceMakerSplashScreenSprite;
	wsp::Sprite CursorPointerSprite;
	
public:
	BibFrameRate fps;

public:
	XmasCountdownView();
	~XmasCountdownView();

	void Initialize (void);
	void Render (void);
	void SetWorld (class XmasCountdownWorld * pinWorld) { pWorld = pinWorld; }

};

