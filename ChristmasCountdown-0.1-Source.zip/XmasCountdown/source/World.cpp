// World.cpp: implementation for the World class.
//
//////////////////////////////////////////////////////////////////////

#include <ogc/lwp_watchdog.h>

#include "GameConstants.h"
#include "World.h"
#include "ImageServer.h"



static BibWiiInputDevice::SingleAction saSplashScreenAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
																};

static BibWiiInputDevice::SingleAction saPressAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
																};

static BibWiiInputDevice::SingleAction saAltPressAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_B}
																};

static BibWiiInputDevice::SingleAction saHomeAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_HOME},
																};









XmasCountdownWorld::XmasCountdownWorld ()
{
}

XmasCountdownWorld::~XmasCountdownWorld ()
{
}



void XmasCountdownWorld::Initialize (int nWidth, int nHeight)
{
	WiiInputDevice.Initialize (nWidth, nHeight);

	// Instantiate button actions.
	WiiSplashScreenAction = WiiInputDevice.DefineAction (saSplashScreenAction);
	WiiPressAction = WiiInputDevice.DefineAction (saPressAction);
	WiiAltPressAction = WiiInputDevice.DefineAction (saAltPressAction);
	WiiHomeAction = WiiInputDevice.DefineAction (saHomeAction);

	pSound.Initialize ();

	// Load background
	bsBackgroundPic.SetImage (isImageServer.GetXmasCountdownBackgroundImage ());
	bsBackgroundPic.SetPosition(0, 0);


	// Set game state to start.
	eGameState = XmasCountdownWorld::SPLASH_SCREEN_PACEMAKER;

	// Reset.
	nGameStateCounter = 0;
	nScore = 0;
	strcpy (szTimeLeftString[0], "No Time Left");
	strcpy (szTimeLeftString[1], "No Time Left");
	strcpy (szTimeLeftString[2], "No Time Left");
	TimeLeftInSeconds = 0;
	eTimeLeftUnits = TLU_DHMS;
}





/*
	Main Control Loop.

	This is called every game loop.
*/
void XmasCountdownWorld::UpdateMovement (float fSpeedFactor)
{
	nGameStateCounter ++;

	WiiInputDevice.ScanInputDevice ();
	pSound.UpdateMovement ();



	// State machine:
	switch (eGameState)
	{
		case XmasCountdownWorld::XMAS_COUNTDOWN:

			if (WiiInputDevice.ActionHeld (WPAD_CHAN_0, WiiHomeAction))
			{
				exit (0);
			}
			
			if (WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiAltPressAction) || 
				WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiPressAction))
			{
				// eTimeLeftUnits ++;
				eTimeLeftUnits = eTimeLeftUnitsType (eTimeLeftUnits + 1);
				
				if (eTimeLeftUnits >= TLU_LAST_ONE)
				{
					eTimeLeftUnits = TLU_DHMS;
				}
			}

			UpdateTimeLeftString ();
			
		break;

		default:
		case XmasCountdownWorld::SPLASH_SCREEN_PACEMAKER:

			if (WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiSplashScreenAction) ||
			    (nGameStateCounter > PACEMAKER_SPLASHSCREEN_WAIT_TIME))
			{
				nGameStateCounter = 0;
				eGameState = XmasCountdownWorld::XMAS_COUNTDOWN;
				pSound.PlaySound (XmasCountdownSound::MP3_SILENT_NIGHT);
			}

			// Don't do any processing.
			return;
		break;
	}

}


void XmasCountdownWorld::UpdateTimeLeftString (void)
{
time_t CurTime;
float fd;

	CurTime = time (NULL);// - 252802115;	//!!!! Hack for Dolphin emulator.
	TimeLeftInSeconds = FindTimeLeftToXmas (CurTime);


	szTimeLeftString[0][0] = 0;
	szTimeLeftString[1][0] = 0;
	szTimeLeftString[2][0] = 0;
	
	switch (eTimeLeftUnits)
	{
		default:
			sprintf (szTimeLeftString[0], "I'm confused, what's Christmas?");
		break;
	
		case TLU_DHMS:

			/*
				Compute Time left in days, hours, minutes and seconds.
			*/
			int d, h, m, s;
			int TempSecondsLeft;
			TempSecondsLeft = TimeLeftInSeconds;
			d = TimeLeftInSeconds / (24 * 60 * 60);
			TempSecondsLeft = TempSecondsLeft - (d * 24 * 60 * 60);
			h = TempSecondsLeft / (60 * 60);
			TempSecondsLeft = TempSecondsLeft - (h * 60 * 60);
			m = TempSecondsLeft / 60;
			TempSecondsLeft = TempSecondsLeft - (m * 60);
			s = TempSecondsLeft;
			
			// " 34d:2h:03m:04s"
			sprintf (szTimeLeftString[0], "% 3dd:%dh:%02dm:%02ds", d, h, m, s);
		break;
		
		case TLU_DAYS:
			/*
				Compute Time left in days.
			*/
			fd = TimeLeftInSeconds / (24.0 * 60.0 * 60.0);

			// " 34.23d"
			sprintf (szTimeLeftString[0], "% 3g", fd);
			sprintf (szTimeLeftString[1], "days");
		break;
		
		case TLU_HOURS:
			/*
				Compute Time left in hours.
			*/
			fd = TimeLeftInSeconds / (60.0 * 60.0);
			sprintf (szTimeLeftString[0], "%g", fd);
			sprintf (szTimeLeftString[1], "hours");
		break;
		
		case TLU_MINUTES:
			/*
				Compute Time left in minutes.
			*/
			fd = TimeLeftInSeconds / 60.0;
			sprintf (szTimeLeftString[0], "%g", fd);
			sprintf (szTimeLeftString[1], "minutes");
		break;
		
		case TLU_SECONDS:
			sprintf (szTimeLeftString[0], "%d", (int) TimeLeftInSeconds);
			sprintf (szTimeLeftString[1], "seconds");
		break;
		
		case TLU_WEEKS:
			fd = TimeLeftInSeconds / (60.0 * 60.0 * 24.0 * 7.0);
			sprintf (szTimeLeftString[0], "%g", fd);
			sprintf (szTimeLeftString[1], "weeks");
		break;
		
		case TLU_FORTNIGHT:
			fd = TimeLeftInSeconds / (60.0 * 60.0 * 24.0 * 14.0);
			sprintf (szTimeLeftString[0], "%g", fd);
			sprintf (szTimeLeftString[1], "fortnights");
		break;
		
		case TLU_NANOSECONDS:
			fd = TimeLeftInSeconds * (1000000000.0);
			sprintf (szTimeLeftString[0], "%g", fd);
			sprintf (szTimeLeftString[1], "nanoseconds");
		break;
		
		case TLU_KIDTIME:
			fd = TimeLeftInSeconds / (24 * 60 * 60) * 2;
			sprintf (szTimeLeftString[0], "%d", (int) fd);
			sprintf (szTimeLeftString[1], "Santa Claus");
			sprintf (szTimeLeftString[2], "Questions");
		break;
	}

}


time_t XmasWiiEpochSeconds [] = 
{
/*12/25/2007*/	 1198627200,
/*12/25/2008*/	 1230249600, 
/*12/25/2009*/	 1261785600, 
/*12/25/2010*/	 1293321600, 
/*12/25/2011*/	 1324857600, 
/*12/25/2012*/	 1356480000, 
/*12/25/2013*/	 1388016000, 
/*12/25/2014*/	 1419552000, 
/*12/25/2015*/	 1451088000,
/*12/25/2016*/	 1482710400, 
/*12/25/2017*/	 1514246400, 
/*12/25/2018*/	 1545782400, 
/*12/25/2019*/	 1577318400, 
/*12/25/2020*/	 1608940800 

};

time_t XmasCountdownWorld::FindTimeLeftToXmas (time_t CurTime)
{
unsigned int i;

	for (i = 0; i < sizeof (XmasWiiEpochSeconds) / sizeof (time_t); i ++)
	{
		if (CurTime < XmasWiiEpochSeconds [i])
		{
			return (XmasWiiEpochSeconds [i] - CurTime);
		}
	}

	printf ("Is this 2020 or is there a bug?  No Christmas found.\n");
	return (0);
}


bool XmasCountdownWorld::GetPointer (int nWiiRemote, int & xLoc, int & yLoc, int & nAngle)
{
bool bCursorDataValid;
int z;

	if ((nWiiRemote < 0) || (nWiiRemote > WPAD_MAX_WIIMOTES))
		return (false);

	bCursorDataValid = WiiInputDevice.Wii_Cursor (nWiiRemote, xLoc, yLoc, z, nAngle);

	return (bCursorDataValid);
}


