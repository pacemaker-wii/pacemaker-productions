// View.h: interface for the View class.
//
//////////////////////////////////////////////////////////////////////

#include "View.h"
#include "World.h"
#include "BibLib/BibGraphicsHelper.h"
#include "ImageServer.h"

#include "Sprites/CalcFont32Metrics.sprite.h" 


#define CALC_FONT_WIDTH ((int) (CalcFont32Metrics[0]))
 
 
 
XmasCountdownView::XmasCountdownView()
{
}

XmasCountdownView::~XmasCountdownView()
{
}


#ifndef PRODUCTION
static int nFrameCounter = 0;

char szDebugMsg1 [256];
char szDebugMsg2 [256];
char szDebugMsg3 [256];
char szDebugMsg4 [256];
char szDebugMsg5 [256];

#endif


void XmasCountdownView::Initialize (void)
{
	Calc_ScreenFont . Initialize (isImageServer.GetCalcFont32Image (), 
									isImageServer.GetCalcFont32Image ()->GetWidth() / 16, 
									isImageServer.GetCalcFont32Image ()->GetHeight() / 16, 
									CalcFont32Metrics);

	PaceMakerSplashScreenSprite.SetImage (isImageServer.GetPaceMakerSplashScreenImage ());

	CursorPointerSprite.SetImage (isImageServer.GetPepperMintHandPointerImage ());
	CursorPointerSprite.SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);
	CursorPointerSprite.SetTransparency (200);
}


/*
	Render the view (to the screen)
*/
void XmasCountdownView::Render (void)
{
int x, y, angle;
bool bPointerIsValid;
char szBuf [1024];


	// Check to see if we have been initialized.
	if (! pWorld)
		return;

	

	/*
		Do rendering, backgrounds and foregrounds.
	*/
	switch (pWorld -> GetGameState ())
	{
		default:
		case XmasCountdownWorld::SPLASH_SCREEN_PACEMAKER:
			PaceMakerSplashScreenSprite.Draw();
			return;	// Don't display anything else, to preserve the purity of the PaceMaker splash screen.
		break;



		case XmasCountdownWorld::XMAS_COUNTDOWN:
			/*
				Put background bitmaps in here.
			*/
			pWorld -> GetBackgroundSprite ().Draw ();


			sprintf (szBuf, "%s", pWorld->GetString (0));
			Calc_ScreenFont.DisplayText (340 - (strlen (szBuf) * CALC_FONT_WIDTH / 2) , 220, szBuf);

			sprintf (szBuf, "%s", pWorld->GetString (1));
			Calc_ScreenFont.DisplayText (340 - (strlen (szBuf) * CALC_FONT_WIDTH / 2) , 244, szBuf);

			sprintf (szBuf, "%s", pWorld->GetString (2));
			Calc_ScreenFont.DisplayText (340 - (strlen (szBuf) * CALC_FONT_WIDTH / 2) , 268, szBuf);

			bPointerIsValid = pWorld->GetPointer (0, x, y, angle);
			if (bPointerIsValid)
			{
				CursorPointerSprite.SetPosition (x, y);
				CursorPointerSprite.Draw ();
			}

		break;
	}
	
	
	

#ifndef PRODUCTION
	/*
		Display debug text.
	*/
	sprintf (szBuf, "(%d)", nFrameCounter ++);
	Calc_ScreenFont.DisplayText (40, 50, szBuf);


extern char szDebugMsg1 [256];
extern char szDebugMsg2 [256];
extern char szDebugMsg3 [256];
extern char szDebugMsg4 [256];
extern char szDebugMsg5 [256];
	Calc_ScreenFont.DisplayText (40, 200, szDebugMsg1);
	Calc_ScreenFont.DisplayText (40, 220, szDebugMsg2);
	Calc_ScreenFont.DisplayText (40, 240, szDebugMsg3);
	Calc_ScreenFont.DisplayText (40, 260, szDebugMsg4);
	Calc_ScreenFont.DisplayText (40, 280, szDebugMsg5);


	/*
		Put the fps at the bottom.
	*/
	sprintf (szBuf, "fps %02.2f", fps.fps);
	Calc_ScreenFont.DisplayText (40, 380, szBuf);
#endif

	
}



