﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RoguelikeCharacterBuilder
{
    public class Monster
    {
        public Monster(char Thing, string Name, int x, int y, int FightingPoints, int DefensePoints, int HealthPoints, double Level)
        {
            this.Thing = Thing;
            this.Name = Name;
            this.x = x;
            this.y = y;
            this.FightingPoints = FightingPoints;
            this.DefensePoints = DefensePoints;
            this.HealthPoints = HealthPoints;
            this.Level = Level;
        }

        public char Thing;
        public string Name;
        public int x, y;
        public int FightingPoints;
        public int DefensePoints;
        public int HealthPoints;
        public double Level;
    }

    class MonsterManager
    {
        private List<Monster> MonsterList;


        public MonsterManager()
        {
            MonsterList = new List<Monster>();
        }

        public void AddMonster(Monster theMonster)
        {
            MonsterList.Add(theMonster);
        }

        public bool IsMonsterAt(int x, int y, out Monster theMonster)
        {
            foreach (Monster m in MonsterList)
            {
                if ((m.x == x) && (m.y == y))
                {
                    theMonster = m;
                    return (true);
                }
            }

            theMonster = null;
            return (false);
        }

        public void RemoveMonster(Monster theMonster)
        {
            Monster m;

            for (int i = 0; i < MonsterList.Count; i++)
            {
                m = MonsterList.ElementAt(i);
                if ((m.x == theMonster.x) && (m.y == theMonster.y))
                {
                    MonsterList.RemoveAt(i);
                }
            }
        }

    }
}
