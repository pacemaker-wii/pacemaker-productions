﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libtcod;

namespace RoguelikeCharacterBuilder
{
    class HeroData
    {
        const int DisplayAtCol = 54;
        const int DisplayAtRow = 4;

        public static readonly string[] StatNames = { "Health Pts", "Stealth Pts", "Fight Pts", "Defense Pts", "SaveMe Pts" };
        public static readonly string[] PointNames = { "Stealth Pts ->", "Fight Pts ->", "Defense Pts ->"};

        public struct StatsType
        {
            public double Level;
            public int HealthPoints;
            public int StealthPoints;
            public int FightPoints;
            public int DefensePoints;
            public int SaveMePoints;
        };

        public string MyName;
        public int MapX;
        public int MapY;
        public StatsType Stats;
        public StatsType PointsToUse;
        
        private J_TCODMenu AdjustPointsMenu;
        private int[] AdjustPointsList;

        public HeroData(string HeroName, int[] stats)
        {
            MyName = HeroName;
            MapX = 5;
            MapY = 5;
            Stats = new StatsType();
            Stats.Level = 1;
            Stats.HealthPoints = stats[0];
            Stats.StealthPoints = stats[1];
            Stats.FightPoints = stats[2];
            Stats.DefensePoints = stats[3];
            Stats.SaveMePoints = stats[4];

            PointsToUse.HealthPoints = 0;
            PointsToUse.StealthPoints = 0;
            PointsToUse.FightPoints = 0;
            PointsToUse.DefensePoints = 0;
            PointsToUse.SaveMePoints = 0;
        }


        public void Display(Program.eGameState GameState)
        {
            TCODConsole.root.printFrame(DisplayAtCol, DisplayAtRow, 23, 20);
            TCODUtility.PrintString(DisplayAtCol + 1, DisplayAtRow + 1, String.Format ("Name: {0}", MyName), TCODColor.white, TCODColor.black);
            TCODUtility.PrintString(DisplayAtCol + 1, DisplayAtRow + 2, String.Format("{0,-11}: {1:0.00}", "Level", Stats.Level), TCODColor.white, TCODColor.black);
            TCODUtility.PrintString(DisplayAtCol + 1, DisplayAtRow + 3, String.Format("{0,-11}: {1}", StatNames[0], Stats.HealthPoints), TCODColor.white, TCODColor.black);
            TCODUtility.PrintString(DisplayAtCol + 1, DisplayAtRow + 4, String.Format("{0,-11}: {1}", StatNames[1], Stats.StealthPoints), TCODColor.white, TCODColor.black);
            TCODUtility.PrintString(DisplayAtCol + 1, DisplayAtRow + 5, String.Format("{0,-11}: {1}", StatNames[2], Stats.FightPoints), TCODColor.white, TCODColor.black);
            TCODUtility.PrintString(DisplayAtCol + 1, DisplayAtRow + 6, String.Format("{0,-11}: {1}", StatNames[3], Stats.DefensePoints), TCODColor.white, TCODColor.black);
            TCODUtility.PrintString(DisplayAtCol + 1, DisplayAtRow + 7, String.Format("{0,-11}: {1}", StatNames[4], Stats.SaveMePoints), TCODColor.white, TCODColor.black);

            if (GameState == Program.eGameState.eAdjustPoints)
            {
                AdjustPointsMenu.DisplayMenu();
                TCODUtility.DisplayList(DisplayAtCol + 17, DisplayAtRow + 10, AdjustPointsList, TCODColor.white, TCODColor.black);
            }
            else
            {
                TCODUtility.PrintString(DisplayAtCol + 1, DisplayAtRow + 9, "Points to use:", TCODColor.white, TCODColor.black);
                TCODUtility.PrintString(DisplayAtCol + 1, DisplayAtRow + 10, String.Format("{0,-14}: {1}", PointNames[0], PointsToUse.StealthPoints), TCODColor.white, TCODColor.black);
                TCODUtility.PrintString(DisplayAtCol + 1, DisplayAtRow + 11, String.Format("{0,-14}: {1}", PointNames[1], PointsToUse.FightPoints), TCODColor.white, TCODColor.black);
                TCODUtility.PrintString(DisplayAtCol + 1, DisplayAtRow + 12, String.Format("{0,-14}: {1}", PointNames[2], PointsToUse.DefensePoints), TCODColor.white, TCODColor.black);
            }
        }

        public void InitAdjustPoints()
        {
            AdjustPointsMenu = new J_TCODMenu(DisplayAtCol + 1, DisplayAtRow + 10, PointNames, 0, 
                                            TCODColor.white, TCODColor.black, 
                                            TCODColor.black, TCODColor.white);

            AdjustPointsList = new int[3];
            AdjustPointsList[0] = PointsToUse.StealthPoints;
            AdjustPointsList[1] = PointsToUse.FightPoints;
            AdjustPointsList[2] = PointsToUse.DefensePoints;

            ValidatePoints();
        }


        public bool Actions(TCODKey key, ref Program.eGameState GameState)
        {
            if (key.KeyCode == TCODKeyCode.Down)
            {
                AdjustPointsMenu.IncrementSelection();
                return (true);
            }
            else if (key.KeyCode == TCODKeyCode.Up)
            {
                AdjustPointsMenu.DecrementSelection();
                return (true);
            }
            else if (key.KeyCode == TCODKeyCode.Right)
            {
                AdjustPointsList[AdjustPointsMenu.GetSelection()]++;
                ValidatePoints();

                return (true);
            }
            else if (key.KeyCode == TCODKeyCode.Left)
            {
                AdjustPointsList[AdjustPointsMenu.GetSelection()]--;
                ValidatePoints();

                return (true);
            }
            else if ((key.KeyCode == TCODKeyCode.Tab) || (key.KeyCode == TCODKeyCode.Enter))
            {
                PointsToUse.StealthPoints = AdjustPointsList[0];
                PointsToUse.FightPoints = AdjustPointsList[1];
                PointsToUse.DefensePoints = AdjustPointsList[2];

                GameState = Program.eGameState.ePlaying;
                return (true);
            }
            else if (key.KeyCode == TCODKeyCode.Escape)
            {
                GameState = Program.eGameState.ePlaying;
                return (true);
            }

            return (false);
        }


        private void ValidatePoints()
        {
            for (int i = 0; i < 3; i++)
            {
                int stat = 0;
                switch (i)
                {
                    case 0: stat = Stats.StealthPoints; break;
                    case 1: stat = Stats.FightPoints; break;
                    case 2: stat = Stats.DefensePoints; break;
                }

                if ((AdjustPointsList[i] > stat) ||
                    (AdjustPointsList[i] < 0))
                {
                    AdjustPointsList[i] = stat;
                }
            }
        }
    }
}
