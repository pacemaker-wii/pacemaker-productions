﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libtcod;

namespace RoguelikeCharacterBuilder
{
    /// <summary>
    /// Menu to set character's stats.
    /// </summary>
    class CharacterMenu
    {
        private static int[] stats = { 1, 0, 100, 100, 0 };
        private J_TCODMenu theMenu;

        const int MenuFirstRow = 15;
        const int MenuFirstCol = 25;

        public CharacterMenu()
        {
            theMenu = new J_TCODMenu(MenuFirstCol, MenuFirstRow, HeroData.StatNames, 0, TCODColor.grey, TCODColor.black, TCODColor.black, TCODColor.white);
        }

        public int[] GetStats()
        {
            return (stats);
        }

        private void DisplayHeader()
        {
            TCODConsole.root.setForegroundColor(TCODColor.grey);
            TCODConsole.root.setBackgroundColor(TCODColor.black);
            TCODConsole.root.print(20, 2, "Character Menu");

            TCODConsole.root.rect(10, 25, 70, 25, true);

            TCODConsole.root.print(10, 25, "Right/Left to adjust stats.  Enter when Done.");
            TCODConsole.root.print(10, 26, "Add as much as you like....you'll need it.");
        }

        public void DisplayMenu()
        {
            DisplayHeader();
            theMenu.DisplayMenu();
            TCODUtility.DisplayList(MenuFirstCol + 15, MenuFirstRow, stats, TCODColor.grey, TCODColor.black);
        }

        public bool MenuActions(TCODKey key, ref Program.eGameState GameState)
        {
            if (key.KeyCode == TCODKeyCode.Down)
            {
                theMenu.IncrementSelection();
                return (true);
            }
            else if (key.KeyCode == TCODKeyCode.Up)
            {
                theMenu.DecrementSelection();
                return (true);
            }
            else if (key.KeyCode == TCODKeyCode.Right)
            {
                stats[theMenu.GetSelection()]++;
                return (true);
            }
            else if (key.KeyCode == TCODKeyCode.Left)
            {
                stats[theMenu.GetSelection()]--;
                return (true);
            }
            else if (key.KeyCode == TCODKeyCode.Enter)
            {
                GameState = Program.eGameState.ePlaying;
                return (true);
            }
            else if (key.KeyCode == TCODKeyCode.Escape)
            {
                GameState = Program.eGameState.eCharacterName;
                return (true);
            }

            return (false);
        }


        public int[] GetStartingStats()
        {
            return (stats);
        }
    }
}
