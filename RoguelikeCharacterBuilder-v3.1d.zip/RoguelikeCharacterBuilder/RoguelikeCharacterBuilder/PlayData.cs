﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libtcod;

namespace RoguelikeCharacterBuilder
{
    class PlayData
    {
        const int DisplayMapAtCol = 12;
        const int DisplayMapAtRow = 8;
        const int DisplayMapWidth = 41;
        const int DisplayMapHeight = 21;

        const int DisplayMsgWinAtCol = 11;
        const int DisplayMsgWinAtRow = 30;



        MapData md;
        HeroData hd;
        MessageWindow mw;
        TCODRandom RandomGenerator;


        public PlayData(string HeroName, int[] stats)
        {
            md = new MapData();
            hd = new HeroData(HeroName, stats);
            hd.MapX = md.StartingX;
            hd.MapY = md.StartingY;
            mw = new MessageWindow(DisplayMsgWinAtCol, DisplayMsgWinAtRow, 10, 100);
            mw.AddMsg("Welcome...");
            md.SetHeroLocation(hd.MapX, hd.MapY);
            RandomGenerator = new TCODRandom(TCODRandomType.MersenneTwister);
        }

        public void Display(Program.eGameState GameState)
        {
            int MapX, MapY;

            TCODConsole.root.print(10, DisplayMapAtRow - 2, "Play Data Goes Here.");

            MapX = hd.MapX - DisplayMapWidth / 2;
            MapY = hd.MapY - DisplayMapHeight / 2;
            DisplayMap(DisplayMapAtCol, DisplayMapAtRow, DisplayMapWidth, DisplayMapHeight, MapX, MapY);

            TCODConsole.root.putCharEx(DisplayMapWidth / 2 + DisplayMapAtCol, DisplayMapHeight / 2 + DisplayMapAtRow, 
                                        '@', TCODColor.white, TCODColor.black);

            mw.Display();
            hd.Display(GameState);
        }

        public bool Actions(TCODKey key, ref Program.eGameState GameState)
        {
            Monster theMonster;
            int TryX, TryY;
            bool TryMove;

            if (GameState == Program.eGameState.eAdjustPoints)
            {
                return (hd.Actions(key, ref GameState));
            }

            TryX = -1;
            TryY = -1;
            TryMove = false;
            if ((key.KeyCode == TCODKeyCode.Down) || (key.KeyCode == TCODKeyCode.KeypadTwo))
            {
                TryX = hd.MapX;
                TryY = hd.MapY + 1;
                TryMove = true;
            }
            else if ((key.KeyCode == TCODKeyCode.Up) || (key.KeyCode == TCODKeyCode.KeypadEight))
            {
                TryX = hd.MapX;
                TryY = hd.MapY - 1;
                TryMove = true;
            }
            else if ((key.KeyCode == TCODKeyCode.Left) || (key.KeyCode == TCODKeyCode.KeypadFour))
            {
                TryX = hd.MapX - 1;
                TryY = hd.MapY;
                TryMove = true;
            }
            else if ((key.KeyCode == TCODKeyCode.Right) || (key.KeyCode == TCODKeyCode.KeypadSix))
            {
                TryX = hd.MapX + 1;
                TryY = hd.MapY;
                TryMove = true;
            }
            else if ((key.KeyCode == TCODKeyCode.Pagedown) || (key.KeyCode == TCODKeyCode.KeypadThree))
            {
                TryX = hd.MapX + 1;
                TryY = hd.MapY + 1;
                TryMove = true;
            }
            else if ((key.KeyCode == TCODKeyCode.Pageup) || (key.KeyCode == TCODKeyCode.KeypadNine))
            {
                TryX = hd.MapX + 1;
                TryY = hd.MapY - 1;
                TryMove = true;
            }
            else if ((key.KeyCode == TCODKeyCode.Home) || (key.KeyCode == TCODKeyCode.KeypadSeven))
            {
                TryX = hd.MapX - 1;
                TryY = hd.MapY - 1;
                TryMove = true;
            }
            else if ((key.KeyCode == TCODKeyCode.End) || (key.KeyCode == TCODKeyCode.KeypadOne))
            {
                TryX = hd.MapX - 1;
                TryY = hd.MapY + 1;
                TryMove = true;
            }
            else if (key.KeyCode == TCODKeyCode.Tab)
            {
                mw.AddMsg("Use arrows to change points to use in subsequent actions.");
                mw.AddMsg("Tab or Enter to accept changes, Escape to cancel changes.");
                GameState = Program.eGameState.eAdjustPoints;
                hd.InitAdjustPoints();
                return (true);
            }



            if (TryMove)
            {  
                if (CanMoveTo(TryX, TryY))
                {
                    mw.AddMsg(String.Format ("{0}-{1}", TryX, TryY));
                    hd.MapX = TryX;
                    hd.MapY = TryY;
                    md.SetHeroLocation(hd.MapX, hd.MapY);
                    return (true);
                }

                if (md.IsMonsterAt(TryX, TryY, out theMonster))
                {
                    //!!!!mw.AddMsg("Mash...." + theMonster.Name);
                    Attack(hd, theMonster);
                    return (true);
                }
                return (true);
            }



            return (false);
        }

        private bool CanMoveTo(int x, int y)
        {
            if (md.GetCell(x, y).Thing == '.')
            {
                return (true);
            }
            return (false);
        }





        private void DisplayMap(int AtCol, int AtRow, int width, int height, int MapFirstCol, int MapFirstRow)
        {
            TCODConsole.root.printFrame(AtCol-1, AtRow-1, width+2, height+2);

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    MapData.CellData cd = md.GetCell(MapFirstCol + i, MapFirstRow + j);
                    TCODConsole.root.setBackgroundFlag(cd.BackFlag);
                    TCODConsole.root.putCharEx(AtCol + i, AtRow + j, cd.Thing, cd.Fore, cd.Back);
                }
            }
        }


        /*
         * Attack:
         * 
         * 1.  Player: Chance to hit = (50% + p.level - m.level)
         * 2.  If hit, m.hp -= ((p.level*p.fp) + (m.level*m.dp))
         * 
         * 
         * 
         * 
         * 
         */
        private void Attack(HeroData hd, Monster theMonster)
        {
            int ToHit;
            int Dam, Def;

            //mw.AddMsg(String.Format("{0} attacks the {1}.", hd.MyName, theMonster.Name));

            /*
             * Adjust points to use.
             */
            if (hd.PointsToUse.FightPoints > hd.Stats.FightPoints)
            {
                hd.PointsToUse.FightPoints = Math.Max(0, hd.Stats.FightPoints);
            }
            if (hd.PointsToUse.DefensePoints > hd.Stats.DefensePoints)
            {
                hd.PointsToUse.DefensePoints = Math.Max(0, hd.Stats.DefensePoints);
            }



            /*
             * Calculate ToHit and Damage.
             */
            ToHit = RandomGenerator.getInt(0, (int) (100 + hd.Stats.Level - theMonster.Level));

            if (ToHit >= 50)
            {
                Dam = RandomGenerator.getInt(1, (int) (hd.Stats.Level * hd.PointsToUse.FightPoints * 1.25));
                Def = RandomGenerator.getInt(0, (int)(theMonster.Level * theMonster.DefensePoints));
                Dam -= Def;

                if (Dam > 0)
                {
                    theMonster.HealthPoints -= Dam;

                    if (theMonster.HealthPoints <= 0)
                    {
                        mw.AddMsg(String.Format("{0} is defeated.", theMonster.Name));
                        md.RemoveMonster(theMonster);
                        hd.Stats.Level += theMonster.Level;
                    }
                    else
                    {
                        mw.AddMsg(String.Format("Pow!  {0} has {1} hp left.", theMonster.Name, theMonster.HealthPoints));
                    }
                }
                else
                {
                    mw.AddMsg(String.Format("{0}'s attack does nothing.", hd.MyName));
                }

                hd.Stats.FightPoints -= hd.PointsToUse.FightPoints;
            }
            else if (ToHit < 10)
            {
                mw.AddMsg(String.Format("{0} totally misses the {1}.", hd.MyName, theMonster.Name));
            }
            else
            {
                mw.AddMsg(String.Format("{0} misses the {1}.", hd.MyName, theMonster.Name));
            }

        }

    }
}
