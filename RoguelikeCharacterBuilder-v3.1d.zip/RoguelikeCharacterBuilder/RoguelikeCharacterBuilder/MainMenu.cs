﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libtcod;

namespace RoguelikeCharacterBuilder
{
    class MainMenu
    {
        private string[] MenuData = { "Start New Character", "Load Character", "Exit" };
        private  J_TCODMenu theMenu;

        const int MenuFirstRow = 5;
        const int MenuFirstCol = 25;

        public MainMenu()
        {
            theMenu = new J_TCODMenu(MenuFirstCol, MenuFirstRow, MenuData, 0, TCODColor.grey, TCODColor.black, TCODColor.black, TCODColor.white);
        }


        private void DisplayHeader()
        {
            TCODConsole.root.setForegroundColor(TCODColor.grey);
            TCODConsole.root.setBackgroundColor(TCODColor.black);
            TCODConsole.root.printFrame(20, 2, 40, 10, true);
            TCODConsole.root.print(20, 2, "Main Menu");

            TCODConsole.root.print(10, 25, "Welcome to Roguelike Character Builder.");
            TCODConsole.root.print(10, 26, "The objective is to end the game with as many points as possible.");
        }

        public void DisplayMenu()
        {
            DisplayHeader();
            theMenu.DisplayMenu();
        }

        public bool MenuActions(TCODKey key, ref Program.eGameState GameState)
        {
            if (key.KeyCode == TCODKeyCode.Down)
            {
                theMenu.IncrementSelection();
                return (true);
            }
            else if (key.KeyCode == TCODKeyCode.Up)
            {
                theMenu.DecrementSelection();
                return (true);
            }
            else if ((key.KeyCode == TCODKeyCode.Space) || 
                     (key.KeyCode == TCODKeyCode.Enter))
            {
                if (theMenu.GetSelection() == 2)
                {
                    GameState = Program.eGameState.eExit;
                }
                else if (theMenu.GetSelection() == 0)
                {
                    GameState = Program.eGameState.eCharacterName;
                }
                return (true);
            }

            return (false);
        }


    }
}
