﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libtcod;

namespace RoguelikeCharacterBuilder
{
    class GetHeroName
    {
        private int DisplayAtCol;
        private int DisplayAtRow;
        private string Prompt;
        private string Input;

        /// <summary>
        /// Get a string from the user, e.g. your name.
        /// </summary>
        public GetHeroName(int DisplayAtCol, int DisplayAtRow, String Prompt)
        {
            this.DisplayAtCol = DisplayAtCol;
            this.DisplayAtRow = DisplayAtRow;
            this.Prompt = Prompt;
            this.Input = "";
        }

        public string GetData()
        {
            return (Input);
        }

        public void Display()
        {
            TCODUtility.PrintString(DisplayAtCol, DisplayAtRow, Prompt, TCODColor.white, TCODColor.black);
            TCODUtility.PrintString(DisplayAtCol + Prompt.Length, DisplayAtRow, Input, TCODColor.white, TCODColor.black);
            TCODUtility.PrintString(DisplayAtCol + Prompt.Length + Input.Length, DisplayAtRow, "_", TCODColor.white, TCODColor.black);
        }

        public bool Actions(TCODKey key, ref Program.eGameState GameState)
        {
            if (!key.Pressed)
            {
                return (true);
            }

            if (key.KeyCode == TCODKeyCode.Escape)
            {
                GameState = Program.eGameState.eMainMenu;
                return (true);
            }


            if (key.KeyCode == TCODKeyCode.Enter)
            {
                if (Input.Length != 0)
                {
                    GameState = Program.eGameState.eCharacterMenu;
                }
                return (true);
            }


            if (key.KeyCode == TCODKeyCode.Backspace)
            {
                if (Input.Length > 0)
                {
                    Input = Input.Substring(0, Input.Length - 1);
                }
                return (true);
            }


            if (IsPrintableCharacter (key.Character) && (key.KeyCode != TCODKeyCode.Space))
            {
                Input += key.Character;
                return (true);
            }

            return (false);
        }

        private bool IsPrintableCharacter(char candidate)
        {
            return !(candidate < 0x20 || candidate > 127);
        }
    }
}
