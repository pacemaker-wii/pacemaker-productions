﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libtcod;
using System.Threading;

namespace RoguelikeCharacterBuilder
{
    class Program
    {
        public enum eGameState { eExit, eMainMenu, eCharacterName, eCharacterMenu, ePlaying, eAdjustPoints };
        static eGameState GameState;

        static void Main(string[] args)
        {
            TCODKey key;
            bool SwallowedKey;
            CharacterMenu cm;
            MainMenu mm;
            GetHeroName gs;
            PlayData pd = null;

            TCODConsole.initRoot(80, 50, "Roguelike Character Builder (TCOD.Net)", false, TCODRendererType.SDL);
            GameState = eGameState.eMainMenu;
            cm = new CharacterMenu();
            mm = new MainMenu();
            gs = new GetHeroName(21, 13, "Enter Your Name: ");


            /*
             * Main Game Loop.
             */
            while (!TCODConsole.isWindowClosed())
            {
                TCODConsole.root.setBackgroundColor(TCODColor.black);
                TCODConsole.root.clear();

                /*
                 * Switch for what to display right now.
                 */
                switch (GameState)
                {
                    default:
                    case eGameState.eExit:
                    break;

                    case eGameState.eAdjustPoints:
                        pd.Display(GameState);
                    break;

                    case eGameState.ePlaying:
                        if (pd == null)
                        {
                            pd = new PlayData(gs.GetData(), cm.GetStats());
                        }
                        pd.Display(GameState);
                    break;

                    case eGameState.eMainMenu:
                        mm.DisplayMenu();
                    break;

                    case eGameState.eCharacterName:
                        mm.DisplayMenu();
                        gs.Display();
                    break;

                    case eGameState.eCharacterMenu:
                        mm.DisplayMenu();
                        gs.Display();
                        cm.DisplayMenu();
                    break;

                }

                TCODConsole.flush();
                key = TCODConsole.waitForKeypress(false);
                SwallowedKey = false;


                /*
                 * Switch for what to do with key presses.
                 */
                switch (GameState)
                {
                    default:
                        SwallowedKey = false;
                        break;

                    case eGameState.eAdjustPoints:
                        SwallowedKey = pd.Actions(key, ref GameState);
                    break;

                    case eGameState.ePlaying:
                        SwallowedKey = pd.Actions(key, ref GameState);
                    break;

                    case eGameState.eMainMenu:
                        SwallowedKey = mm.MenuActions(key, ref GameState);
                        break;

                    case eGameState.eCharacterMenu:
                        SwallowedKey = cm.MenuActions(key, ref GameState);
                        break;

                    case eGameState.eCharacterName:
                        SwallowedKey = gs.Actions(key, ref GameState);
                        break;

                }



                if (GameState == eGameState.eExit)
                {
                    TCODConsole.root.setForegroundColor(TCODColor.white);
                    TCODConsole.root.setBackgroundColor(TCODColor.black);
                    TCODConsole.root.print(41, 31, "Later!");
                    TCODConsole.flush();
                    Thread.Sleep(100);
                    break;
                }


                if (!SwallowedKey)
                {
                    if (key.KeyCode == TCODKeyCode.Escape)
                    {
                        TCODConsole.root.print(21, 43, "ESCAPE!");
                        TCODConsole.flush();
                        Thread.Sleep(100);
                        break;
                    }
                }
            }

        }
    }
}



#if false
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.IO;


// Note: When building this code, you must reference the
// System.Runtime.Serialization.dll assembly.

namespace SerializationTest
{
    public class Program
    {
        [DataContract]
        public class MyClass
        {
            [DataMember]
            private int abc;
        }

        static void Main(string[] args)
        {
            MyClass mc = new MyClass();





            MemoryStream ms = new MemoryStream();
            string SerialOutput = "";

            DataContractSerializer dcs = new DataContractSerializer(typeof (MyClass));
            dcs.WriteObject(ms, mc);


            foreach (byte b in ms.GetBuffer())
            {
                if (b == 0)
                {
                    break;
                }
                SerialOutput += (char)b;
            }

            ms.Seek(0, SeekOrigin.Begin);
            MyClass newmc;
            newmc = (MyClass) dcs.ReadObject(ms);
        }
    }
}

#endif