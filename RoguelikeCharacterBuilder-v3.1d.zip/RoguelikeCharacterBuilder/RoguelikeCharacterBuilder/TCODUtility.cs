﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libtcod;

namespace RoguelikeCharacterBuilder
{
    class TCODUtility
    {
        /// <summary>
        /// Display a list of items on the root console.
        /// </summary>
        static public void DisplayList(int x, int y, System.Collections.IEnumerable theList, TCODColor Fore, TCODColor Back)
        {
            int row = 0;

            foreach (var v in theList)
            {
                PrintString(x, y + row, v.ToString(), Fore, Back);
                row++;
            }
        }


        /// <summary>
        /// Display a string on the root console.
        /// </summary>
        static public void PrintString(int x, int y, string theLine, TCODColor Fore, TCODColor Back)
        {
            TCODConsole.root.setForegroundColor(Fore);
            TCODConsole.root.setBackgroundColor(Back);
            TCODConsole.root.rect(x, y, theLine.Length, 1, true, TCODBackgroundFlag.Set);
            TCODConsole.root.print(x, y, theLine);
        }



    }
}
