﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libtcod;

namespace RoguelikeCharacterBuilder
{
    class MapData
    {
        public struct CellData
        {
            public CellData(char Thing, TCODColor Fore, TCODColor Back, bool SeenOnce, bool Lighted)
            {
                this.Thing = Thing;
                this.Fore = Fore;
                this.Back = Back;
                this.SeenOnce = SeenOnce;
                this.Lighted = Lighted;
                this.BackFlag = TCODBackgroundFlag.Default;
            }

            public char Thing;
            public TCODColor Fore;
            public TCODColor Back;
            public TCODBackgroundFlag BackFlag;
            public bool SeenOnce;
            public bool Lighted;    //!!!! Not used.
        };

        private MonsterManager mm;
        private CellData [,] theData;
        private TCODMap tMap;
        private const int MapSize = 55;

        public int StartingX, StartingY;

        public MapData()
        {
            mm = new MonsterManager();
            GenMap();
            BuildTCODMap();
        }

        // Build a map.
        private void GenMap()
        {
            int CenterX1, CenterY1, Radius1;
            int CenterX2, CenterY2, Radius2;
            TCODRandom r = new TCODRandom(TCODRandomType.MersenneTwister);
            theData = new CellData[MapSize, MapSize];

            for (int x = 0; x < MapSize; x++)
            {
                for (int y = 0; y < MapSize; y++)
                {
                    if ((x == 0) || (x == MapSize - 1) ||
                        (y == 0) || (y == MapSize - 1))
                    {
                        theData[x, y] = new CellData('#', TCODColor.grey, TCODColor.black, false, false);
                    }
                    else
                    {
                        theData[x, y] = new CellData('#', TCODColor.grey, TCODColor.black, false, false);
                    }
                }
            }


            CenterX2 = 0;
            CenterY2 = 0;
            for (int i = 0; i < 10; i++)
            {
                CenterX1 = r.getInt(1, MapSize - 1);
                CenterY1 = r.getInt(1, MapSize - 1);
                Radius1 = r.getInt(3, 9);

                CreateRoom(CenterX1, CenterY1, Radius1);

                CenterX2 = r.getInt(1, MapSize - 1);
                CenterY2 = r.getInt(1, MapSize - 1);
                Radius2 = r.getInt(1, 5);

                CreateRoom(CenterX2, CenterY2, Radius2);

                CreateLine(CenterX1, CenterY1, CenterX2, CenterY2);
            }

            StartingX = CenterX2;
            StartingY = CenterY2;
        }

        /// <summary>
        /// Return cell data with color adjustments for FOV/LOS.
        /// </summary>
        public CellData GetCell(int x, int y)
        {
            CellData cd;
            Monster theMonster;

            if ((x < 0) || (y < 0) ||
                (x >= MapSize) || (y >= MapSize))
            {
                return (new CellData('#', TCODColor.black, TCODColor.black, false, false));
            }

            cd = theData[x, y];

            if (tMap.isInFov(x, y))
            {
                cd.Back = TCODColor.darkestYellow;
                theData[x, y].SeenOnce = true;

                if (mm.IsMonsterAt(x, y, out theMonster))
                {
                    cd.Thing = theMonster.Thing;
                }
            }
            else
            {
                if (cd.SeenOnce)
                {
                    cd.Fore = new TCODColor((byte)(cd.Fore.Red * 0.5), (byte)(cd.Fore.Green * 0.5), (byte)(cd.Fore.Blue * 0.5));
                }
                else
                {
                    cd.Fore = TCODColor.black;
                    cd.Back = TCODColor.black;
                }
            }
            return (cd);
        }


        private void CreateRoom(int CenterX, int CenterY, int Radius)
        {
            for (int x = 0; x < MapSize; x++)
            {
                for (int y = 0; y < MapSize; y++)
                {
                    if ((x == 0) || (x == MapSize - 1) ||
                        (y == 0) || (y == MapSize - 1))
                    {
                        continue;
                    }
                    if ((CenterX - x) * (CenterX - x) + (CenterY - y) * (CenterY - y) < Radius * Radius)
                    {
                        theData[x, y] = new CellData('.', TCODColor.white, TCODColor.black, false, false);
                    }
                }
            }

            //theData[CenterX, CenterY] = new CellData('j', TCODColor.orange, TCODColor.black, false, false);
            if (Radius > 2)
            {
                mm.AddMonster(new Monster('j', "jeff", CenterX, CenterY, 1, 1, 10, 1));
                mm.AddMonster(new Monster('t', "small tree", CenterX + 1, CenterY + 0, 0, 1, 10, 0.01));
                mm.AddMonster(new Monster('t', "small tree", CenterX + 1, CenterY + 1, 0, 1, 10, 0.01));
                mm.AddMonster(new Monster('t', "small tree", CenterX - 1, CenterY + 0, 0, 1, 10, 0.01));
                mm.AddMonster(new Monster('t', "small tree", CenterX - 1, CenterY - 1, 0, 1, 10, 0.01));
            }
        }


        private void CreateLine(int X1, int Y1, int X2, int Y2)
        {
            int xCur, yCur;

            TCODLine.init(X1, Y1, X2, Y2);
            xCur = X1;
            yCur = Y1;

            while (!TCODLine.step(ref xCur, ref yCur))
            {
                CreateRoom(xCur, yCur, 2);  // Wide Hallways.

                // Narrow hallways.
                //theData[xCur, yCur] = new CellData('.', TCODColor.white, TCODColor.black, false, false);
            }
        }


        // Recreate map data in a TCOD data structure for FOV calculations.
        private void BuildTCODMap()
        {
            tMap = new TCODMap(MapSize, MapSize);
            for (int x = 0; x < MapSize; x++)
            {
                for (int y = 0; y < MapSize; y++)
                {
                    tMap.setProperties(x, y, theData[x, y].Thing != '#', theData[x, y].Thing == '.');
                }
            }
        }

        // Recalculate FOV each time the hero moves.
        public void SetHeroLocation(int x, int y)
        {
            tMap.computeFov(x, y, 8, true, TCODFOVTypes.ShadowFov);
        }


        public bool IsMonsterAt(int x, int y, out Monster theMonster)
        {
            return (mm.IsMonsterAt(x, y, out theMonster));
        }

        public void RemoveMonster(Monster theMonster)
        {
            mm.RemoveMonster(theMonster);
        }
    }
}
