﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libtcod;

namespace RoguelikeCharacterBuilder
{
    /// <summary>
    /// Generic menu.
    /// </summary>
    class J_TCODMenu
    {
        private int x, y;
        private string[] MenuText;
        private int CurSelection;
        private TCODColor UnselectedFore;
        private TCODColor UnselectedBack;
        private TCODColor SelectedFore;
        private TCODColor SelectedBack;

        public J_TCODMenu(int x, int y, string[] MenuText, int CurSelection, 
                    TCODColor UnselectedFore, TCODColor UnselectedBack,
                    TCODColor SelectedFore, TCODColor SelectedBack)
        {
            this.x = x;
            this.y = y;
            this.MenuText = MenuText;
            this.CurSelection = CurSelection;
            this.UnselectedFore = UnselectedFore;
            this.UnselectedBack = UnselectedBack;
            this.SelectedFore = SelectedFore;
            this.SelectedBack = SelectedBack;
        }

        public void DisplayMenu()
        {
            for (int i = 0; i < MenuText.GetLength(0); i++)
            {
                if (CurSelection == i)
                {
                    TCODUtility.PrintString(x, i + y, MenuText[i], TCODColor.black, TCODColor.white);
                }
                else
                {
                    TCODUtility.PrintString(x, i + y, MenuText[i], TCODColor.grey, TCODColor.black);
                }
            }
        }


        public int IncrementSelection()
        {
            CurSelection++;
            CurSelection = CurSelection % MenuText.GetLength(0);

            return (CurSelection);
        }

        public int DecrementSelection()
        {
            CurSelection--;
            if (CurSelection < 0)
            {
                CurSelection = MenuText.GetLength(0) - 1;
            }
            return (CurSelection);
        }

        public int SetSelection(int CurSelection)
        {
            this.CurSelection = CurSelection;
            return (CurSelection);
        }

        public int GetSelection()
        {
            return (CurSelection);
        }
    }
}
