﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using libtcod;

namespace RoguelikeCharacterBuilder
{
    /// <summary>
    /// Generic GUI message window.
    /// </summary>
    class MessageWindow
    {
        private int DisplayAtCol, DisplayAtRow;
        private int DisplayNumLines;
        private int SaveNumLines;

        private Queue<string> MessageList;

        public MessageWindow(int DisplayAtCol, int DisplayAtRow, int DisplayNumLines, int SaveNumLines)
        {
            this.DisplayAtCol = DisplayAtCol;
            this.DisplayAtRow = DisplayAtRow;
            this.DisplayNumLines = DisplayNumLines;
            this.SaveNumLines = SaveNumLines;

            MessageList = new Queue<string>();
        }

        public void Display()
        {
            TCODConsole.root.printFrame(DisplayAtCol - 1, DisplayAtRow, 60, DisplayNumLines + 2);
            for (int i = 0; i < Math.Min(DisplayNumLines, MessageList.Count); i++)
            {
                TCODUtility.PrintString(DisplayAtCol, DisplayAtRow + DisplayNumLines - i, MessageList.ElementAt(MessageList.Count - 1 - i), 
                                    TCODColor.white, TCODColor.black);
            }
        }

        public void AddMsg(string NewMessage)
        {
            MessageList.Enqueue(NewMessage);
            if (MessageList.Count > SaveNumLines)
            {
                MessageList.Dequeue();
            }
        }
    }
}
