/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVTypes.h"
#include "REVCam.h"
#include "REVDefinitions.h"
//Global data
CAMERA * defCam;
extern ROOT * mainRoot;

//Public functions
CAMERA * defaultCam() { return defCam; }

//Internal functions
void initCams()
{
	defCam = (CAMERA*)malloc(sizeof(CAMERA));
	initNode((NODE*)defCam, NT_CAMERA, 0);
}

void updtMtx(CAMERA * cam, Mtx view)
{
	Mtx modMtx;
	getAbsMtx((NODE*)cam, modMtx);
	Vector temp = vector(modMtx[0][1], modMtx[1][1], modMtx[2][1]);
	Vector pos = vector(modMtx[0][3], modMtx[1][3], modMtx[2][3]);
	guVecAdd(&temp,&pos,&temp);
	guLookAt(view, &pos,&vector(modMtx[0][2], modMtx[1][2], modMtx[2][2]),&temp);
}
