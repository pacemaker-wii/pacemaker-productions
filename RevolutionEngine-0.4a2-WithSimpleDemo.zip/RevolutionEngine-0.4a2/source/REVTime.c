/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVTime.h"

//Global data
f32 frame_time = 0;
f32 current_time = 0;
f32 last_frame = 0;
f32 timeSpeed = 1.0; 

//Public functions
void setTimeSpeed(f32 speed)
{
	timeSpeed = speed;
}

f32 frameTime()
{
	return frame_time;
}

f32 gameTime()
{
	return frame_time * timeSpeed;
}

//Internal functions
void updtTime()
{
	current_time = (f32)(ticks_to_millisecs(gettime()));
	if(last_frame) frame_time = current_time - last_frame;
	else frame_time = 0;
	last_frame = current_time;
	frame_time /= 1000.0;
}
