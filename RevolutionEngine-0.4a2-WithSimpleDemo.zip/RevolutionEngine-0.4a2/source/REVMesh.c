/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVMesh.h"
#include "REVDefinitions.h"
#include "REVCntMgr.h"
#include "REVQuat.h"

//Definitions
#define LINESIZE 60
#define LoaderVersion 0.1

//Global data
extern CNTMGR * mainCntMgr;

//Public functions
MODEL * loadRms(const char * fileName)
{
	//First we look for the mesh in the content Manager
	Vector * tNml;
	MODEL * model = mainCntMgr->modelList;
	MESH * mesh;
	UVSET * uv;
	while(model)
	{
		if(!strcmp(fileName, model->name))
			return model;
		model = model->next;
	}
	//We actually load the mesh
	model = (MODEL*)malloc(sizeof(MODEL));
	FILE * f = fopen(fileName, "rt");
	if(!f)
	{
		free(model);
		return NULL;
	}
	model->type = MT_STATIC;//set mesh type to rms
	model->flags = 0;
	model->nMeshes = 1;
	model->nUVSets = 1;
	model->meshes = (MESH*)malloc(sizeof(MESH));
	mesh = model->meshes;
	mesh->uvSets = (UVSET*)malloc(sizeof(UVSET));
	uv = mesh->uvSets;
	strcpy(model->name, fileName);//We fill the mesh name
	char linebuffer[LINESIZE];
	char * datatype;
	f32 version = 0;
	u16 verts = 0, texts = 0, normals = 0, faces = 0;
	
	mesh->nVertices = 0;
	mesh->nNormals = 0;
	uv->nUVs = 0;
	mesh->nTris = 0;
	mesh->nQuads = 0;
	
	//Una vez declarado todo lo que vamos a usar empezamos a explorar el archivo.
	while(!feof(f))
	{
		fgets(linebuffer, LINESIZE, f);
		if(!feof(f))
		{
			datatype = strtok(linebuffer," ");
			if(datatype[0] != '#')//Si una linea empieza por # es que es un comentario, por tanto no se procesa
			{//En caso contrario
				if(datatype[0] == 'm')//Estamos ante la informacion de version de archivo
				{
					version = atof(strtok(NULL, " "));
				}
				if(datatype[0] == 'q')
				{
					if(datatype[1] == 'v')
					{
						mesh->nVertices = atoi(strtok(NULL, " "));
						mesh->vertices = (f32*)memalign(32, mesh->nVertices*sizeof(f32)*3);
					}
					if(datatype[1] == 'n')
					{
						mesh->nNormals = atoi(strtok(NULL, " "));
						mesh->normals = (f32*)memalign(32, mesh->nNormals*sizeof(f32)*3);
					}
					if(datatype[1] == 't')
					{
						uv->nUVs = atoi(strtok(NULL, " "));
						uv->uvs = (f32*)memalign(32, uv->nUVs*sizeof(f32)*2);
					}
					if(datatype[1] == 'f')
					{
						mesh->nTris = atoi(strtok(NULL, " "));
						mesh->vList = (u16*)memalign(32, mesh->nTris*sizeof(u16)*3);
						mesh->nList = (u16*)memalign(32, mesh->nTris*sizeof(u16)*3);
						uv->uvList = (u16*)memalign(32, mesh->nTris*sizeof(u16)*3);
					}
				}
				if(datatype[0] == 'v')
				{if(verts < mesh->nVertices){
					mesh->vertices[verts*3] = (f32)atof(strtok(NULL, " "));
					mesh->vertices[verts*3+1] = (f32)atof(strtok(NULL, " "));
					mesh->vertices[verts*3+2] = (f32)atof(strtok(NULL, " "));
					verts ++;
				}}
				if(datatype[0] == 'n')
				{if(normals < mesh->nNormals){
					mesh->normals[normals*3] = (f32)atof(strtok(NULL, " "));
					mesh->normals[normals*3+1] = (f32)atof(strtok(NULL, " "));
					mesh->normals[normals*3+2] = (f32)atof(strtok(NULL, " "));
					normals ++;
				}}
				if(datatype[0] == 't')
				{ if(texts < uv->nUVs){
					uv->uvs[texts*2] = (f32)atof(strtok(NULL, " "));
					uv->uvs[texts*2+1] = (f32)atof(strtok(NULL, " "));
					texts ++;
				}}
				if(datatype[0] == 'f')
				{if(faces < mesh->nTris){
					mesh->vList[faces*3+2] = atoi(strtok(NULL, "/"));
					mesh->nList[faces*3+2] = atoi(strtok(NULL, "/"));
					uv->uvList[faces*3+2] = atoi(strtok(NULL, " "));
					
					mesh->vList[faces*3+1] = atoi(strtok(NULL, "/"));
					mesh->nList[faces*3+1] = atoi(strtok(NULL, "/"));
					uv->uvList[faces*3+1] = atoi(strtok(NULL, " "));
					
					mesh->vList[faces*3+0] = atoi(strtok(NULL, "/"));
					mesh->nList[faces*3+0] = atoi(strtok(NULL, "/"));
					uv->uvList[faces*3+0] = atoi(strtok(NULL, " "));
					faces++;
				}}
			}
		}
	}//////*/
	fclose(f);
	//normalize normals
	for(normals=0;normals<mesh->nNormals;normals++)
	{
		tNml = (Vector*)(&mesh->normals[3*normals]);
		guVecNormalize(tNml);
	}
	DCFlushRange(mesh->vertices, mesh->nVertices*sizeof(f32)*3);
	DCFlushRange(mesh->normals, mesh->nNormals*sizeof(f32)*3);
	DCFlushRange(uv->uvs, uv->nUVs*sizeof(f32)*2);
	
	mesh->diffuse = (GXColor*)memalign(32, sizeof(GXColor)*mesh->nNormals);
	//now we add the mesh to the content manager
	model->next = mainCntMgr->modelList;
	mainCntMgr->modelList = model;
	return model;
}

void modelScale(MODEL* model, Vector scale)
{
	u32 i, j;
	for(j = 0; j<model->nMeshes; j++)
	{
		for(i=0;i<model->meshes[j].nVertices;i++)
		{
			model->meshes[j].vertices[3*i] *= scale.x;
			model->meshes[j].vertices[3*i+1] *= scale.y;
			model->meshes[j].vertices[3*i+2] *= scale.z;
		}
		DCFlushRange(model->meshes[j].vertices, model->meshes[j].nVertices*sizeof(f32)*3);
	}
}

void modelScaleUniform(MODEL* model, f32 scale)
{
	u32 i, j;
	for(j = 0; j< model->nMeshes; j++)
	{
		for(i = 0; i < model->meshes[j].nVertices * 3; i++)
		{
			model->meshes[j].vertices[i] *= scale;
		}
		DCFlushRange(model->meshes[j].vertices, model->meshes[j].nVertices*sizeof(f32)*3);
	}
}

f32 modelGetSize(MODEL * model)
{
	u32 i, j;
	f32 size = 0, tSize;
	Vector * vert;
	for(j = 0; j<model->nMeshes; j++)
	{
		vert = (Vector*)model->meshes[j].vertices;
		for(i=0;i<model->meshes[j].nVertices;i++)
		{
			if((tSize = guVecSqModule(&vert[i])) > size)
			size = tSize;
		}
	}
	return sqrt(size);
}

MODEL * loadRmd(const char * filename)
{
	u16 version;
	u8 i, j;
	MODEL * model = (MODEL*)malloc(sizeof(MODEL));
	MESH * mesh;
	UVSET * uv;
	if(!model)
		return NULL;
	FILE * f = fopen(filename, "rb");
	if(!f)
	{
		free(model);
		return NULL;
	}
	fread(&version, sizeof(u16), 1, f);
	if(version != 1)
	{
		fclose(f);
		free(model);
		return NULL;
	}
	fread(&model->type, sizeof(u8), 1, f);
	fread(&model->nUVSets, sizeof(u8), 1, f);
	fread(&model->nMeshes, sizeof(u8), 1, f);
	model->meshes = (MESH*)malloc(sizeof(MESH)*model->nMeshes);
	for(i = 0; i < model->nMeshes; i++)
	{
		mesh = &model->meshes[i];
		fread(&mesh->nVertices, sizeof(u16), 1, f);
		fread(&mesh->nNormals, sizeof(u16), 1, f);
		fread(&mesh->nTris, sizeof(u16), 1, f);
		fread(&mesh->nQuads, sizeof(u16), 1, f);
		mesh->vertices = (f32*)memalign(32, 3*mesh->nVertices*sizeof(float));
		mesh->normals = (f32*)memalign(32, 3*mesh->nNormals*sizeof(float));
		mesh->vList = (u16*)memalign(32, sizeof(u16)*(3*mesh->nTris+4*mesh->nQuads));
		mesh->nList = (u16*)memalign(32, sizeof(u16)*(3*mesh->nTris+4*mesh->nQuads));
		mesh->uvSets = (UVSET*)malloc(sizeof(UVSET)*model->nUVSets);
		fread(&mesh->vertices, sizeof(f32), 3*mesh->nVertices, f);
		fread(&mesh->normals, sizeof(f32), 3*mesh->nNormals, f);
		fread(&mesh->vList, sizeof(u16), 3*mesh->nTris+4*mesh->nQuads, f);
		fread(&mesh->nList, sizeof(u16), 3*mesh->nTris+4*mesh->nQuads, f);
		for(j = 0; j < model->nUVSets; j++)
		{
			uv = &mesh->uvSets[j];
			fread(&uv->nUVs, sizeof(u16), 1, f);
			uv->uvs = (f32*)memalign(32, sizeof(f32)*uv->nUVs);
			uv->uvList = (u16*)memalign(32, sizeof(u16)*(3*mesh->nTris+4*mesh->nQuads));
			fread(&uv->uvs, sizeof(f32), uv->nUVs, f);
			fread(&uv->uvList, sizeof(u16), 3*mesh->nTris+4*mesh->nQuads, f);
			DCFlushRange(uv->uvs, uv->nUVs*sizeof(f32)*2);
		}
		DCFlushRange(mesh->vertices, mesh->nVertices*sizeof(f32)*3);
		DCFlushRange(mesh->normals, mesh->nNormals*sizeof(f32)*3);
		mesh->diffuse = (GXColor*)memalign(32, sizeof(GXColor)*mesh->nNormals);
	}
	fclose(f);
	return model;
}
