/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVDefinitions.h"
#include "REVViewports.h"
#include "REVTypes.h"

//global data
extern ROOT * mainRoot;

void setViewPort(VIEWPORT * view)
{
	GX_SetViewport(view->x,view->y,view->sx,view->sy,0,1);
	GX_SetScissor(view->x,view->y,view->sx,view->sy);
}

VIEWPORT * newViewport(f32 x, f32 y, f32 sx, f32 sy, u8 layer, CAMERA * cam, u8 flags)
{
	VIEWPORT * tv = (VIEWPORT*)malloc(sizeof(VIEWPORT));
	tv->x = x;
	tv->y = y;
	tv->sx = sx;
	tv->sy = sy;
	tv->cam = cam;
	tv->next = mainRoot->mainViewport;
	mainRoot->mainViewport = tv;
	tv->flags = flags;
	tv->layer = layer;
	return tv;
}
