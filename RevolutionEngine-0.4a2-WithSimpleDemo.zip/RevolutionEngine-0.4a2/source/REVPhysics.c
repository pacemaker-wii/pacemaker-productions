/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVTypes.h"
#include "REVTime.h"
#include "REVObject.h"

//Global data
extern ROOT * mainRoot;

//Internal prototypes
f32 vecModule(Vector a);
f32 vecSqModule(Vector a);
void updateState(OBJECT * a);

//Public functions
BODY * pointBd()
{
	BODY * tb = (BODY*)malloc(sizeof(BODY));
	tb->type = BT_Point;
	tb->mass = 1.0;
	tb->bouncy = 1.0;
	tb->friction = 0.0;
	return tb;
}

BODY * sphereBd(f32 radius)
{
	SBODY * tb = (SBODY*)malloc(sizeof(SBODY));
	tb->type = BT_Sphere;
	tb->mass = 1.0;
	tb->bouncy = 1.0;
	tb->friction = 0.0;
	tb->radius = radius;
	return (BODY*)tb;
}

BODY * cubeBd(f32 side)
{
	BBODY * tb = (BBODY*)malloc(sizeof(BBODY*));
	tb->type = BT_Box;
	tb->mass = 1.0;
	tb->bouncy = 1.0;
	tb->friction = 0.0;
	tb->width = side;
	tb->length = side;
	tb->height = side;
	return (BODY*)tb;
}

BODY * boxBd(f32 width, f32 length, f32 height)
{
	BBODY * tb = (BBODY*)malloc(sizeof(BBODY*));
	tb->type = BT_Box;
	tb->mass = 1.0;
	tb->bouncy = 1.0;
	tb->friction = 0.0;
	tb->width = width;
	tb->length = length;
	tb->height = height;
	return (BODY*)tb;
}

u8 collide(struct REV_Object * a, struct REV_Object * b)//So much simplified, no movement calculated
{
	Vector relPos;
	if((!a->body)||(!b->body)) return 0;
	switch(a->body->type)
	{
		case BT_Point:
		{
			switch(b->body->type)
			{
				case BT_Point:
					return 0;//Particles do not collide each other
				case BT_Sphere://Static only
				{
					guVecSub(&a->node.pos, &b->node.pos, &relPos);
					if(vecSqModule(relPos) <= (((SBODY*)b->body)->radius)*(((SBODY*)b->body)->radius))
					return 1;
					return 0;
				}
			}
		}
		case BT_Sphere:
		{
			switch(b->body->type)
			{
				case BT_Point:
					return collide(b,a);
				case BT_Sphere://Static only
					guVecSub(&a->node.pos, &b->node.pos, &relPos);
					if(vecSqModule(relPos) <= (((SBODY*)b->body)->radius + ((SBODY*)a->body)->radius)
											  *(((SBODY*)b->body)->radius + ((SBODY*)a->body)->radius))
					return 1;
					return 0;
			}
		}
	}
	return 0;
}

//Internal functions
f32 vecModule(Vector a)
{
	return sqrt(a.x*a.x+a.y*a.y+a.z*a.z);
}

f32 vecSqModule(Vector a)
{
	return a.x*a.x+a.y*a.y+a.z*a.z;
}

void updateSpace(void)
{
	
}

void updateState(OBJECT * a)
{
	Mtx Aux;
	NODE * acum = &a->node;
	Vector Angle;
	guMtxTransApply(acum->modMtx, acum->modMtx, -acum->pos.x, -acum->pos.y, -acum->pos.z);
	acum->pos.x += acum->spd.x * gameTime();
	acum->pos.y += acum->spd.y * gameTime();
	acum->pos.z += acum->spd.z * gameTime();
	Angle.x = acum->asp.x * gameTime();
	Angle.y = acum->asp.y * gameTime();
	Angle.z = acum->asp.z * gameTime();
	guMtxRotDeg(Aux, 'y', Angle.y);
	guMtxConcat(Aux, acum->modMtx, acum->modMtx);
	guMtxRotDeg(Aux, 'x', Angle.x);
	guMtxConcat(Aux, acum->modMtx, acum->modMtx);
	guMtxRotDeg(Aux, 'z', Angle.z);
	guMtxConcat(Aux, acum->modMtx, acum->modMtx);
	guMtxTransApply(acum->modMtx, acum->modMtx, acum->pos.x, acum->pos.y, acum->pos.z);
}
