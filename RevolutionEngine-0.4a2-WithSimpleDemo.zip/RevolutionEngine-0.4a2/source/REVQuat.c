/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVQuat.h"

//Internal functions
void computeW(Quaternion * a)
{
	f32 t = 1.0 - (a->x * a->x + a->y * a->y + a->z * a->z);
	if(t>0.0)
		a->w = -sqrt(t);
	else a->w = 0.0;
}

void quatRotatePoint(Quaternion * q, Vector * src, Vector * dst)
{
	Quaternion inv, tmp, final;
	inv.x = -q->x;
	inv.y = -q->y;
	inv.z = -q->z;
	inv.w = q->w;
	quatNormalize(&inv);
	quatVecMult(&inv, src, &tmp);
	quatCrossProduct(&tmp, q, &final);
	dst->x = final.x;
	dst->y = final.y;
	dst->z = final.z;
}

void quatNormalize(Quaternion * q)
{
	f32 invmag, mag = (q->x*q->x)+(q->y*q->y)+(q->z*q->z)+(q->w*q->w);
	if(mag > 0)
	{
		invmag = 1/sqrt(mag);
		q->x *= invmag;
		q->y *= invmag;
		q->z *= invmag;
		q->w *= invmag;
	}
}

void quatCrossProduct(Quaternion * a, Quaternion * b, Quaternion * ab)
{
	ab->w = (a->w * b->w) - (a->x * b->x) - (a->y * b->y) - (a->z * b->z);
	ab->x = (a->x * b->w) + (a->w * b->x) + (a->y * b->z) - (a->z * b->y);
	ab->y = (a->y * b->w) + (a->w * b->y) + (a->z * b->x) - (a->x * b->z);
	ab->z = (a->z * b->w) + (a->w * b->z) + (a->x * b->y) - (a->y * b->x);
}

void quatVecMult(Quaternion * q, Vector * v, Quaternion * dst)
{
	dst->w = - (q->x * v->x) - (q->y * v->y) - (q->z * v->z);
	dst->x =   (q->w * v->x) + (q->y * v->z) - (q->z * v->y);
	dst->y =   (q->w * v->y) + (q->z * v->x) - (q->x * v->z);
	dst->z =   (q->w * v->z) + (q->x * v->y) - (q->y * v->x);
}

f32 guVecModule(Vector * v)
{
	return sqrt(v->x*v->x+v->y*v->y+v->z*v->z);
}

f32 guVecSqModule(Vector * v)
{
	return v->x*v->x+v->y*v->y+v->z*v->z;
}
