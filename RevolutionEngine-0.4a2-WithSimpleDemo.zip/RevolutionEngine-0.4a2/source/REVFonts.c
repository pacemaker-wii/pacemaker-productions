/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVFonts.h"

//data structures
typedef struct REV_Font
{
	ftgxCharData * fstChar;
	u8 size;
	struct REV_Font * next;
}FNT;

//Global data
FT_Library ftlibrary;
FT_Face face;
FT_GlyphSlot slot;

FNT * fstFnt, *auxFnt;

extern char fontface[];
extern int fontsize;

//Internal prototypes
ftgxCharData * findChar(u8 key, u8 size);
ftgxCharData * newChar(u8 key);
static wchar_t* charToWideChar(char* p);

//Internal functions

void REV_fontsInit()
{
	FT_Init_FreeType (&ftlibrary);
	FT_New_Memory_Face (ftlibrary, (FT_Byte *) fontface, fontsize, 0, &face);
	setfontsize (16);
	slot = face->glyph;
	fstFnt = NULL;
	auxFnt = NULL;
}

void setfontsize (u8 pixels)
{
	FT_Set_Pixel_Sizes (face, 0, pixels);
}

void drawText(TEXT * text)
{
	u16 len = strlen(text->text);
	u16 i, x_pos = text->node.x;
	u16 textureWidth, textureHeight;
	GXTexObj glyphTexture;
	ftgxCharData* glyphData;
	GXColor clr = text->clr;
	
	setfontsize(text->size);
	for(i=0;i<len;i++)
	{
		glyphData = findChar(text->text[i], text->size);
		if(!glyphData)
		glyphData = newChar(text->text[i]);
		
		if(glyphData)
		{
			Mtx pnlMtx;
			GX_InitTexObj(&glyphTexture, glyphData->glyphDataTexture, glyphData->textureWidth, glyphData->textureHeight, GX_TF_RGBA8, GX_CLAMP, GX_CLAMP, GX_FALSE);
			guMtxIdentity(pnlMtx);
			guMtxTransApply(pnlMtx, pnlMtx, x_pos, text->node.y - glyphData->renderOffsetY, 0.0);
			GX_LoadPosMtxImm(pnlMtx, GX_PNMTX0);
			textureWidth = glyphData->textureWidth;
			textureHeight = glyphData->textureHeight;
			GX_LoadTexObj(&glyphTexture, GX_TEXMAP0);
			GX_Begin(GX_QUADS, GX_VTXFMT0, 4);
				GX_Position3f32(0.0,0.0,-5.0);
				GX_Color4u8(clr.r,clr.g,clr.b,clr.a);
				GX_TexCoord2f32(0.0,0.0);
				
				GX_Position3f32(textureWidth,0.0,-5.0);
				GX_Color4u8(clr.r,clr.g,clr.b,clr.a);
				GX_TexCoord2f32(1.0,0.0);
				
				GX_Position3f32(textureWidth,textureHeight,-5.0);
				GX_Color4u8(clr.r,clr.g,clr.b,clr.a);
				GX_TexCoord2f32(1.0,1.0);
				
				GX_Position3f32(0.0,textureHeight,-5.0);
				GX_Color4u8(clr.r,clr.g,clr.b,clr.a);
				GX_TexCoord2f32(0.0,1.0);
			GX_End();
			x_pos += glyphData->glyphAdvanceX;
		}
	}
}

u16 adjustTextureWidth(u16 textureWidth, u8 textureFormat)
{
	u16 alignment;
	
	switch(textureFormat) {
		case GX_TF_I4:		/* 8x8 Tiles - 4-bit Intensity */
		case GX_TF_I8:		/* 8x4 Tiles - 8-bit Intensity */
		case GX_TF_IA4:		/* 8x4 Tiles - 4-bit Intensity, , 4-bit Alpha */
			alignment = 8;
			break;

		case GX_TF_IA8:		/* 4x4 Tiles - 8-bit Intensity, 8-bit Alpha */
		case GX_TF_RGB565:	/* 4x4 Tiles - RGB565 Format */
		case GX_TF_RGB5A3:	/* 4x4 Tiles - RGB5A3 Format */
		case GX_TF_RGBA8:	/* 4x4 Tiles - RGBA8 Dual Cache Line Format */
		default:
			alignment = 4;
			break;
	}
	return textureWidth % alignment == 0 ? textureWidth : alignment + textureWidth - (textureWidth % alignment);

}

u16 adjustTextureHeight(u16 textureHeight, u8 textureFormat)
{
	u16 alignment;
	
	switch(textureFormat) {
		case GX_TF_I4:		/* 8x8 Tiles - 4-bit Intensity */
			alignment = 8;
			break;

		case GX_TF_I8:		/* 8x4 Tiles - 8-bit Intensity */
		case GX_TF_IA4:		/* 8x4 Tiles - 4-bit Intensity, , 4-bit Alpha */
		case GX_TF_IA8:		/* 4x4 Tiles - 8-bit Intensity, 8-bit Alpha */
		case GX_TF_RGB565:	/* 4x4 Tiles - RGB565 Format */
		case GX_TF_RGB5A3:	/* 4x4 Tiles - RGB5A3 Format */
		case GX_TF_RGBA8:	/* 4x4 Tiles - RGBA8 Dual Cache Line Format */
		default:
			alignment = 4;
			break;
	}
	return textureHeight % alignment == 0 ? textureHeight : alignment + textureHeight - (textureHeight % alignment);

}

void loadGlyphData(FT_Bitmap * bmp, ftgxCharData * charData)
{
	u16 imagePosY, imagePosX;
	u32 * glyphData = (u32 *)memalign(32, charData->textureWidth * charData->textureHeight * 4);
	memset(glyphData, 0x00, charData->textureWidth * charData->textureHeight * 4);
	
	for (imagePosY = 0; imagePosY < bmp->rows; imagePosY++) {
		for (imagePosX = 0; imagePosX < bmp->width; imagePosX++) {
			u32 pixel = (u32) bmp->buffer[imagePosY * bmp->width + imagePosX];
			glyphData[imagePosY * charData->textureWidth + imagePosX] = 0x00000000 | (pixel << 24) | (pixel << 16) | (pixel << 8) | pixel;
		}
	}
	
	charData->glyphDataTexture = convertBufferToRGBA8(glyphData, charData->textureWidth, charData->textureHeight);
	
	free(glyphData);
}

ftgxCharData * newChar(u8 key)
{
	u16 textureWidth = 0, textureHeight = 0;
	u32 gIndex = FT_Get_Char_Index( face, *charToWideChar(((char*)(&key))));
	ftgxCharData * auxChar = (ftgxCharData*)malloc(sizeof(ftgxCharData));
	auxChar->key = key;
	auxChar->next = auxFnt->fstChar;
	auxFnt->fstChar = auxChar;
	if (!FT_Load_Glyph(face, gIndex, FT_LOAD_DEFAULT ))
	{
		FT_Render_Glyph( slot, FT_RENDER_MODE_NORMAL );
		if(slot->format == FT_GLYPH_FORMAT_BITMAP)
		{
			FT_Bitmap *glyphBitmap = &slot->bitmap;
			textureWidth = adjustTextureWidth(glyphBitmap->width, GX_TF_RGBA8);
			textureHeight = adjustTextureHeight(glyphBitmap->rows, GX_TF_RGBA8);
			
			auxChar->glyphAdvanceX = slot->advance.x >> 6;
			auxChar->glyphIndex = gIndex;
			auxChar->textureWidth = textureWidth;
			auxChar->textureHeight = textureHeight;
			auxChar->renderOffsetY = slot->bitmap_top;
			auxChar->renderOffsetMax = slot->bitmap_top;
			auxChar->renderOffsetMin = textureHeight - slot->bitmap_top;
			auxChar->glyphDataTexture = NULL;
			
			loadGlyphData(glyphBitmap, auxChar);
			
			return auxChar;
		}
	}
	free(auxChar);
	return NULL;
}

ftgxCharData * findChar(u8 key, u8 size)
{
	auxFnt = fstFnt;
	while(auxFnt)
	{
		if(auxFnt->size == size) break;
		auxFnt = auxFnt->next;
	}
	if(!auxFnt)
	{
		auxFnt = (FNT*)malloc(sizeof(FNT));
		auxFnt->next = fstFnt;
		fstFnt = auxFnt;
		auxFnt->size = size;
		auxFnt->fstChar = NULL;
	}
	ftgxCharData * auxChar = auxFnt->fstChar;
	while(auxChar)
	{
		if(auxChar->key == key) return auxChar;
		auxChar = auxChar->next;
	}
	return NULL;
}

static wchar_t* charToWideChar(char* p)
{
      wchar_t * strWChar;
      strWChar = (wchar_t*)malloc(sizeof(wchar_t)*(strlen(p) + 1));

      char *tempSrc = p;
      wchar_t * tempDest = strWChar;
      while((*tempDest++ = *tempSrc++));

      return strWChar;
}
