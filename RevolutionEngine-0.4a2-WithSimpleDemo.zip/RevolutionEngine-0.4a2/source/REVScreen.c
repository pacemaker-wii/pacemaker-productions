/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVScreen.h"
#include "REVFonts.h"
#include "REVTypes.h"

//data structures
typedef struct REV_Tracker2D
{
	N2D * target;
	struct REV_Tracker2D * next;
	Mtx m;
}T2D;

//global data
extern ROOT * mainRoot;
extern void *frameBuffer[2];
extern u32	fb;
IRPOINTER cursor[4];
WPADData * wiimoteDt[4];
T2D * q2D = NULL;

//Functions prototypes
void renderChilds(N2D * node, Mtx m);
void renderN2D(N2D * node, Mtx m);
void addBtn(BUTTON * btn);
//void renderPnl(PANEL * pnl);
void addN2D(N2D * node, Mtx m);

//Public functions
void setIrPointer(u8 id, N2D * node, u8 layer, u8 mode)
{
	cursor[id].node = node;
	cursor[id].layer = layer;
	if(mode) pointerOn(id);
	else pointerOff(id);
}

void pointerOn(u8 id)
{
	WPAD_SetDataFormat(id, WPAD_FMT_BTNS_ACC_IR);
	cursor[id].mode = OnMode;
}

void pointerOff(u8 id)
{
	WPAD_SetDataFormat(id, WPAD_FMT_BTNS_ACC);
	cursor[id].mode = OffMode;
}

void pointerPos(u8 ID,u16 *x,u16 *y)
{
	*x = cursor[ID].x;
	*y = cursor[ID].y;
}

PANEL * newPnl(GXTexObj * img, f32 x, f32 y, f32 sx, f32 sy, u8 layer, u8 flags)
{
	PANEL * pnl = (PANEL*)malloc(sizeof(PANEL));
	initN2D(&pnl->node, NT_PANEL, flags);
	pnl->node.x = x;
	pnl->node.y = y;
	pnl->node.ang = 0.0f;
	pnl->layer = layer;
	pnl->img = img;
	pnl->sx = sx;
	pnl->sy = sy;
	pnl->clr = C_WHITE;
	return pnl;
}

BUTTON * newBtn(GXTexObj * img, f32 x, f32 y, f32 sx, f32 sy, u8 layer, u8 flags)
{
	BUTTON * btn = (BUTTON*)malloc(sizeof(BUTTON));
	btn->onClick = NULL;
	initN2D(&btn->node, NT_BUTTON, flags);
	btn->layer = layer;
	btn->img = img;
	btn->node.x = x;
	btn->node.y = y;
	btn->node.ang = 0.0f;
	btn->sx = sx;
	btn->sy = sy;
	btn->clr = C_WHITE;
	addBtn(btn);
	return btn;
}

TEXT * newText(char * text, f32 x, f32 y, u32 size, u8 layer, u8 flags)
{
	TEXT * tt = (TEXT*)malloc(sizeof(TEXT));
	initN2D(&tt->node, NT_TEXT, flags);
	tt->size = size;
	tt->node.x = x;
	tt->node.y = y;
	tt->clr = C_WHITE;
	strcpy(tt->text, text);
	return tt;
}

WINDOW * newWnd(GXTexObj * img, f32 x, f32 y, f32 sx, f32 sy, f32 xs, f32 ys, f32 xe, f32 ye, u8 layer, u8 flags)
{
	WINDOW * w = (WINDOW*)malloc(sizeof(WINDOW));
	initN2D(&w->node, NT_WINDOW, flags);
	w->layer = layer;
	w->img = img;
	w->node.x = x;
	w->node.y = y;
	w->clr = C_WHITE;
	w->xs = xs;
	w->ys = ys;
	w->xe = xe;
	w->ye = ye;
	w->sx = sx;
	w->sy = sy;
	return w;
}

void screenshot(const char * filename)
{
    IMGCTX pngContext;
    pngContext = PNGU_SelectImageFromDevice(filename);
    PNGU_EncodeFromYCbYCr(pngContext, 640, 480, frameBuffer[fb], 0);
    PNGU_ReleaseImageContext(pngContext);
}

//Internal functions
void init2D(void)
{
	u8 i;
	for(i = 0; i < 4; i++)
	{
		cursor[i].mode = OffMode;
		cursor[i].node = NULL;
	}
}

void update2D(void)
{
	BUTTON * auxBtn;
	void (*auxFn)(u8, BUTTON*);
	u8 i;
	for(i = 0; i < 4; i++)
	{
		if(cursor[i].mode && cursor[i].node)
		{
			wiimoteDt[i] = WPAD_Data(i);
			if(wiimoteDt[i]->ir.valid)
			{
				cursor[i].node->x = wiimoteDt[i]->ir.x;
				cursor[i].node->y = wiimoteDt[i]->ir.y;
				cursor[i].node->ang = wiimoteDt[i]->orient.roll * 0.017453;//Convert to radians (*pi/180)
				cursor[i].node->flags = VisibleF;
			}
			else cursor[i].node->flags &= ~VisibleF;
			//Check buttons
			auxBtn = mainRoot->fstBtn;
			while(auxBtn)
			{
				if(auxBtn->node.flags & VisibleF)
				{
					if((cursor[i].node->x > auxBtn->node.x)&&(cursor[i].node->x < (auxBtn->node.x + auxBtn->sx)))
					if((cursor[i].node->y > auxBtn->node.y)&&(cursor[i].node->y < (auxBtn->node.y + auxBtn->sy)))
					if(WPAD_ButtonsDown(i) & WPAD_BUTTON_A)
					{
						if((auxFn = auxBtn->onClick))
						auxFn(i, auxBtn);
					}
				}
				auxBtn = auxBtn->next;
			}
		}
	}
}

void addBtn(BUTTON * btn)
{
	btn->next = mainRoot->fstBtn;
	mainRoot->fstBtn = btn;
}

void render2d(void)
{
	Mtx m;
	T2D * aux;
	guMtxIdentity(m);
	//create the render list
	renderChilds(mainRoot->rootN2D, m);
	aux = q2D;
	while(aux)
	{
		q2D = aux->next;
		renderN2D(aux->target, aux->m);
		free(aux);
		aux = q2D;
	}
}

void renderChilds(N2D * node, Mtx m)
{
	Vector z = (Vector){0.0,0.0,1.0};
	N2D * aux;
	Mtx a;
	if(node->flags & VisibleF)
	{
		if(node->type)
		addN2D(node, m);
		if((aux = node->child))
		{
			guMtxCopy(m, a);
			guMtxRotAxisRad(a, &z, node->ang);
			guMtxTransApply(a, a, node->x, node->y, 0.0);
			while(aux)
			{
				renderChilds(aux, a);
				aux = aux->next;
			}
		}
	}
}

void addN2D(N2D * node, Mtx m)
{
	T2D * n = (T2D*)malloc(sizeof(T2D));
	n->target = node;
	guMtxCopy(m, n->m);
	T2D * t = q2D;
	PANEL * p = (PANEL*)node;
	if(t)
	{
		while(t->next)
		{
			if(p->layer > ((PANEL*)t->next->target)->layer)
				t = t->next;
			else break;
		}
		if(p->layer > ((PANEL*)t->target)->layer)
		{
			n->next = t->next;
			t->next = n;
		}
		else
		{
			n->next = q2D;
			q2D = n;
		}
	}
	else {q2D = n;n->next = NULL;}
}

void renderN2D(N2D * node, Mtx m)
{
	PANEL * pnl;
	TEXT * txt;
	Vector z = (Vector){0.0,0.0,1.0};
	Mtx auxm;
	GXColor clr;
	f32 hx, hy;
	guMtxCopy(m, auxm);
	switch(node->type)
	{
		case NT_BUTTON:
		case NT_PANEL:
		{
			pnl = (PANEL*)node;
			clr = pnl->clr;
			if(pnl->img)
			{
				GX_LoadTexObj(pnl->img, GX_TEXMAP0);
				GX_SetTevOp(GX_TEVSTAGE0, GX_MODULATE);
			}
			else GX_SetTevOp(GX_TEVSTAGE0, GX_PASSCLR);
			guMtxRotAxisRad(auxm, &z, node->ang);
			guMtxTransApply(auxm, auxm, node->x, node->y, 0.0);
			GX_LoadPosMtxImm(auxm, GX_PNMTX0);
			if(node->flags & CenterF)
			{
				hx = pnl->sx * 0.5f;
				hy = pnl->sy * 0.5f;
				GX_Begin(GX_QUADS, GX_VTXFMT0, 4);
					GX_Position3f32(-hx, -hy, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(0.0, 0.0);
					
					GX_Position3f32(hx, -hy, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(1.0, 0.0);
					
					GX_Position3f32(hx, hy, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(1.0, 1.0);
					
					GX_Position3f32(-hx, hy, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(0.0, 1.0);
				GX_End();
			}
			else
			{
				GX_Begin(GX_QUADS, GX_VTXFMT0, 4);
					GX_Position3f32(0.0, 0.0, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(0.0, 0.0);
					
					GX_Position3f32(pnl->sx, 0.0, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(1.0, 0.0);
					
					GX_Position3f32(pnl->sx, pnl->sy, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(1.0, 1.0);
					
					GX_Position3f32(0.0, pnl->sy, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(0.0, 1.0);
				GX_End();
			}
			break;
		}
		case NT_WINDOW:
		{
			WINDOW * w = (WINDOW*)node;
			clr = w->clr;
			if(w->img)
			{
				GX_LoadTexObj(w->img, GX_TEXMAP0);
				GX_SetTevOp(GX_TEVSTAGE0, GX_MODULATE);
			}
			else GX_SetTevOp(GX_TEVSTAGE0, GX_PASSCLR);
			guMtxRotAxisRad(auxm, &z, node->ang);
			guMtxTransApply(auxm, auxm, node->x, node->y, 0.0);
			GX_LoadPosMtxImm(auxm, GX_PNMTX0);
			if(node->flags & CenterF)
			{
				hx = w->sx * 0.5f;
				hy = w->sy * 0.5f;
				GX_Begin(GX_QUADS, GX_VTXFMT0, 4);
					GX_Position3f32(-hx, -hy, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(w->xs, w->ys);
					
					GX_Position3f32(hx, -hy, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(w->xe, w->ys);
					
					GX_Position3f32(hx, hy, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(w->xe, w->ye);
					
					GX_Position3f32(-hx, hy, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(w->xs, w->ye);
				GX_End();
			}
			else
			{
				GX_Begin(GX_QUADS, GX_VTXFMT0, 4);
					GX_Position3f32(0.0, 0.0, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(w->xs, w->ys);
					
					GX_Position3f32(w->sx, 0.0, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(w->xe, w->ys);
					
					GX_Position3f32(w->sx, w->sy, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(w->xe, w->ye);
					
					GX_Position3f32(0.0, w->sy, -5.0);
					GX_Color4u8(clr.r, clr.g, clr.b, clr.a);
					GX_TexCoord2f32(w->xs, w->ye);
				GX_End();
			}
			break;
		}
		case NT_TEXT:
		{
			GX_SetTevOp(GX_TEVSTAGE0, GX_MODULATE);
			txt = (TEXT*)node;
			drawText(txt);
			break;
		}
	}
}

u32 * convertBufferToRGBA8(u32 * rgbaBuffer, u16 bufferWidth, u16 bufferHeight)
{
	u32 bufferSize = (bufferWidth * bufferHeight) << 2;
	u32 * dataBufferRGBA8 = (u32 *)memalign(32, bufferSize);
	memset(dataBufferRGBA8, 0x00, bufferSize);

	u8 *src = (u8 *)rgbaBuffer;
	u8 *dst = (u8 *)dataBufferRGBA8;
	
	u16 block, i, c, ar, gb;

	for(block = 0; block < bufferHeight; block += 4) {
		for(i = 0; i < bufferWidth; i += 4) {
			for (c = 0; c < 4; c++) {
				for (ar = 0; ar < 4; ar++) {
					*dst++ = src[(((i + ar) + ((block + c) * bufferWidth)) * 4) + 3];
					*dst++ = src[((i + ar) + ((block + c) * bufferWidth)) * 4];
				}
			}
			for (c = 0; c < 4; c++) {
				for (gb = 0; gb < 4; gb++) {
					*dst++ = src[(((i + gb) + ((block + c) * bufferWidth)) * 4) + 1];
					*dst++ = src[(((i + gb) + ((block + c) * bufferWidth)) * 4) + 2];
				}
			}
		}
	}
	DCFlushRange(dataBufferRGBA8, bufferSize);

	return dataBufferRGBA8;
}
