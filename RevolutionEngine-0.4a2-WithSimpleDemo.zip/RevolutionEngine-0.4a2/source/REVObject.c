/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVObject.h"
#include "REVTypes.h"

//Definitions
#define Phantom 0//physical modes

#define OBJ_DEF_CLR ((GXColor){255,255,255,255})

//Golbal data
extern ROOT * mainRoot;

//Public functions
OBJECT * newObj(MODEL * model, void * material, BODY * body, Vector pos, Vector ang, u8 flags)
{
	Mtx Aux;
	OBJECT * nObj = (OBJECT*)malloc(sizeof(OBJECT));
	nObj->model = model;
	nObj->body = body;
	nObj->material = material;
	initNode((NODE*)nObj, NT_OBJECT, flags);
	nObj->node.pos = pos;
	nObj->node.mode = Phantom;
	nObj->node.type = NT_OBJECT;
	nObj->clr = OBJ_DEF_CLR;
	nObj->flags = flags;
	//now we init the physical state
	guMtxIdentity(nObj->node.modMtx);
	guMtxRotDeg(Aux, 'y', ang.y);
	guMtxConcat(Aux, nObj->node.modMtx, nObj->node.modMtx);
	guMtxRotDeg(Aux, 'x', ang.x);
	guMtxConcat(Aux, nObj->node.modMtx, nObj->node.modMtx);
	guMtxRotDeg(Aux, 'z', ang.z);
	guMtxConcat(Aux, nObj->node.modMtx, nObj->node.modMtx);
	guMtxTransApply(nObj->node.modMtx, nObj->node.modMtx, pos.x, pos.y, pos.z);
	return nObj;
}
