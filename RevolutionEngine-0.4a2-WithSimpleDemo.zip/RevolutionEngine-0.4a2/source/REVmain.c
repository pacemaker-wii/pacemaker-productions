/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
//
//Sample App.
//by PaceMaker
/////////////////////////////////////////////////

// Include Revolution Engine's main header file
#include "REV.h"

/*
	Notes:

	
	The models (*.rms) and images (*.png) must be
	in the root of the SD Card.

!!!! Too many hard coded constants.

*/

#define min(a,b) ((a) < (b) ? (a) : (b))


#define MAX_FRAME_COUNT		400
#define MAX_FRAME_COUNT_F	400.0f

// Define this to use materials.
#define ENABLE_MATERIALS


// Global Variables.
TEXT * TitleText = NULL;
TEXT * SomeInfoText = NULL;
OBJECT * theChairObject = NULL;
OBJECT * theCubeObject = NULL;
WINDOW * theAPowerBarWindow = NULL;
WINDOW * theBPowerBarWindow = NULL;
int nAFrameCounter = 0;
int nBFrameCounter = 0;
TEXT * DisplayAndDeleteText = NULL;


/*
	Helper function to load a model (.rms file), scale it, and place it at a location/rotation.
*/
OBJECT * LoadModelAndCreateObject (char * szFileName, Vector scale, Vector location, Vector rotation, GXColor color)
{
	// Load the plane model.
	MODEL * themodel= loadRms(szFileName);
	if (! themodel)
	{
		return (NULL);
	}

	// Scale up the model by the scale factor.
	modelScale (themodel, scale);
	
	// Create the OBJECT (a model with material, body, location and rotation).
	OBJECT * theobject = newObj(themodel, NULL, NULL, location,rotation,VisibleF);
	
	// Set the solid color of the object
	theobject->clr = color;

	return (theobject);
}


void AddTexture (OBJECT * ob, GXColor diffuseColor, GXColor specularColor, char * szTextureFileName)
{
#ifdef ENABLE_MATERIALS
	BMATERIAL * theMaterial = basicMat(diffuseColor, specularColor);
	if (szTextureFileName)
	{
		theMaterial->diffuseMap = loadPng(szTextureFileName);
	}
	ob->material = theMaterial;
#endif
}


/*
	This function is called when the Exit button is pressed.
	The Exit button is something we will create on the screen in Create2DObjects().
*/
void ExitButtonCallBack (u8 pointer, struct REV_Button * btn)
{
	// Exit.
	exit (0);
}



/*
	Create all of the 2D objects here.
	2D objects are buttons, text, Wiimote pointers, etc.
*/
bool Create2DObjects (void)
{
	// Create the Title text.
	// Save a global pointer to it so we can change it's location later.
	TitleText = newText("PM's Revolution Engine Demo for 0.4a2", 120, 100, 24, 10, VisibleF);
	TitleText->clr = (GXColor) {51, 204, 255, 255};

	// X at the middle to help me in visual debugging.
	newText("x", 320, 240, 12, 10, VisibleF);


	// Create an empty text object.  Text objects are 2D.
	// The strings are empty so we can add data later.
	// All text objects can hold 100 characters.
	SomeInfoText = newText(" ", 120, 350, 22, 10, VisibleF);
	

	/////////////////////////////
	// Create an exit button.
	/////////////////////////////
	// First Load the Image
	GXTexObj * mybuttonimg = pngFor2D ("exitButton.png");
	if (mybuttonimg)
	{
		// Create the exit button
		BUTTON * mybutton = newBtn(mybuttonimg, 450, 400, 160, 60, 0, VisibleF);
		// Register a function callback.
		// This function is called when the button is pressed.
		mybutton->onClick = ExitButtonCallBack;
	}
	

	///////////////////////////////////
	// Create Wiimote pointer objects.
	///////////////////////////////////
	// First load the pointer image.
	GXTexObj * mycursorimg = pngFor2D ("pointer02.png");
	// Create a panel, which is just a picture we can place on the screen.
	PANEL * mycursorpanel = newPnl(mycursorimg, 0, 0, 32, 32, 0, VisibleF);
	// Associate the panel with the first Wii Remote
	setIrPointer(0 /* Wii Remote 0 */, &mycursorpanel->node, 0, OnMode);
	
	
	
	//////////////////////////////////
	// Create the power bar 'window'.
	// A Rev Engine 'window' is a image that you only show part of
	// for example a life bar or a map.
	//////////////////////////////////
	// First Load the Image
	GXTexObj * mypowerbarimg = pngFor2D ("powerbar.png");
	if (mypowerbarimg)
	{
		// Create the window
		// Parameters are: XY Location, XY Size, Starting location in the image (0-1.0), Ending location (0-1.0)
		// Some of these parameters are overridden below based on user inputs.
		theAPowerBarWindow = newWnd(mypowerbarimg, 100, 400, 320, 26, 0.0, 0.0, 0.5, 1.0, 0, VisibleF);
		theBPowerBarWindow = newWnd(mypowerbarimg, 100, 426, 320, 26, 0.0, 0.0, 0.5, 1.0, 0, VisibleF);
	}

	//////////////////////////////////////
	// Create the power bar outline panel.
	//////////////////////////////////////
	// First Load the Image
	GXTexObj * mypowerbaroutlineimg = pngFor2D ("powerbaroutline.png");
	if (mypowerbaroutlineimg)
	{
		// Create the panel
		newPnl(mypowerbaroutlineimg, 100, 400, 320, 26, 0, VisibleF);
		newPnl(mypowerbaroutlineimg, 100, 426, 320, 26, 0, VisibleF);
	}


	
	
	
	return (true);
}	



/*
	Create all of the 3D objects here.
	This includes planes, cubes, etc.
*/

bool Create3DObjects (void)
{
	
	// Load the chair model.
	theChairObject = LoadModelAndCreateObject ("model.rms", (Vector) {1, 1, 1}, (Vector) {0.0, 2.5, 0.0}, (Vector) {90.0, 0.0, 0.0}, C_RED);
	if (theChairObject)
	{
		AddTexture (theChairObject, C_BLUE, C_WHITE, "ChairTexture.png");
	}
	else
	{
		newText("model.rms not found!", 120, 180, 32, 10, VisibleF);
	}


	// Load the plane model (not an airplane, but a 2D plane in 3D space).
	OBJECT * thePlaneObject = LoadModelAndCreateObject ("plane.rms", (Vector) {8, 8, 8}, (Vector) {0.0, 0.0, 0.0}, (Vector) {0.0, 0.0, 0.0}, (GXColor) {128, 128, 128, 255});
	if (thePlaneObject)
	{
		// Add a special texture.
		AddTexture (thePlaneObject, C_BLACK, C_WHITE, NULL);
	}
	else
	{
		newText("plane.rms not found!", 120, 232, 32, 10, VisibleF);
	}


	theCubeObject = LoadModelAndCreateObject ("cube.rms", (Vector) {1, 1, 1}, (Vector) {3.0, 3.0, 0.0}, (Vector) {0.0, 0.0, 0.0}, C_WHITE);
	if (theCubeObject)
	{
		// Add a special texture.
		AddTexture (theCubeObject, C_BLUE, C_WHITE, "sand.png");
	}
	else
	{
		newText("cube.rms not found!", 120, 264, 32, 10, VisibleF);
	}


	// Load the hidden model.
	OBJECT * hiddenobject = LoadModelAndCreateObject ("Cylinder.rms", (Vector) {0.5, 0.5, 10}, (Vector) {0.0, 6.0, 0.0}, (Vector) {0.0, 0.0, 0.0}, C_WHITE);
	if (hiddenobject)
	{
		AddTexture (hiddenobject, C_BLUE, C_WHITE, "rock.png");
	}
	else
	{
		newText("Cylinder.rms not found!", 120, 232, 32, 10, VisibleF);
	}

	// Load the light model.
	//!!!! This object isn't visible with current camera setup. :(
	OBJECT * lightobject = LoadModelAndCreateObject ("sphere.rms", (Vector) {1.0, 1.0, 1.0}, (Vector) {0, 0, -15}, (Vector) {0.0, 0.0, 0.0}, C_WHITE);
	if (lightobject)
	{
		AddTexture (lightobject, C_WHITE, C_WHITE, NULL);
	}
	else
	{
		newText("sphere.rms not found!", 120, 232, 32, 10, VisibleF);
	}



	/*
		Setup camera position and angle.
		Set the camera high and looking down.

		With the default Camera:
			+Y is into the screen
			+X is to the right
			+Z is up
	*/
	setPos(& defaultCam()->node, (Vector){0, 0, 10});
	setAng (& defaultCam()->node, (Vector){270, 0, 0 });	// In Degrees.
	
	
	
	/*
		Create mood lighting.
		//!!!! What to do with this stuff?
	*/
	/*LIGHT * myLight = */ newLight((Vector) {0, 0, -15}, (GXColor) {164, 164, 164, 255}, 1);
	//!!!! Need to have an object where the light is?
	//setAmbLight(C_BLUE);


	return (true);
}


void CreateViewPorts (void)
{
VIEWPORT * miniViewPort;
CAMERA * miniCam;

	// Create a camera and initialize it.
	//!!!! This should be a RevEngine function call.
	miniCam = (CAMERA*)malloc(sizeof(CAMERA));
	initNode((NODE*)miniCam, NT_CAMERA, 0);

	// I think these are relative to the defaultCam that we attach to later.
	setPos(& miniCam->node, (Vector){0, -3, 0});
	setAng (& miniCam->node, (Vector){0, 0, 0 });	// In Degrees.

	// Create a mini view port. in the upper left of the screen.
	miniViewPort = newViewport(515, 25, 100, 100, 1, miniCam, VisibleF);
	
	// Attach the miniCam to the default cam so they move in sync, but offset as defined above.
	attachNode (&defaultCam()->node, &miniCam->node);
}



/*
	Move an object around in a circle and rotate it so it always
	has the same side facing in.
	
	The circle is centered at 0,0 with the radius specified below.
	
	Each call will advance the object around the circle.
*/
void StepObject (OBJECT * ob)
{
static int nCurStep;
int nDegrees;
double Radius;
float x, y, z;

	// Increment the step.
	nCurStep ++;
	
	// Determine degrees from current step.
	nDegrees = nCurStep % 360;
	
	// The Radius.
	Radius = ((nCurStep % 3500) / 1000.0f); /*3.5 is max*/
	
	// Calculate the X and y positions.  Z will always be zero.
	x = Radius * cos ((nDegrees) * 3.14159 / 180);	// In Radians
	y = Radius * sin ((nDegrees) * 3.14159 / 180);
	z = (x * y) * (x * y) / 4;
	
	// These functions set the absolute position and angle.
	setPos(& ob->node, (Vector){x, y, z});
	setAng (& ob->node, (Vector){0, 0, nDegrees});	// In Degrees.

	// Set the color and alpha
	ob->clr = (GXColor) {255, 255, 255, min (nCurStep / 2, 255)};
	
	// Put some useful? text into our info object.	//!!!!
	//sprintf (SomeInfoText -> text, "[%04d](%4.3f, %4.3f, %4.3f) angle (%d)", nDegrees, x, y, 0.0f, (nDegrees % 360));

}


/*
	Read user input and increment some counters.
	nAFrameCounter is for the (A) button.
	nBFramecounter is for the (B) button.
	
	Minimum is 0 and Maximum is MAX_FRAME_COUNT.
	The number increases when the button is held down.
	The number decreases when the button is not pressed.
*/
void IncrementFrameCounters (void)
{

	if ((PAD_ButtonsHeld (0) & PAD_BUTTON_A) || (WPAD_ButtonsHeld (0) & WPAD_BUTTON_A))
	{
		//!!!!sprintf (SomeInfoText -> text, "+++ (%d)", nAFrameCounter);
		nAFrameCounter ++;
		if (nAFrameCounter > MAX_FRAME_COUNT)
		{
			nAFrameCounter = MAX_FRAME_COUNT;
		}
	}
	else
	{
		//!!!!sprintf (SomeInfoText -> text, "--- (%d)", nAFrameCounter);
		nAFrameCounter --;
		if (nAFrameCounter < 0)
		{
			nAFrameCounter = 0;
		}
	}

	if ((PAD_ButtonsHeld (0) & PAD_BUTTON_B) || (WPAD_ButtonsHeld (0) & WPAD_BUTTON_B))
	{
		nBFrameCounter ++;
		if (nBFrameCounter > MAX_FRAME_COUNT)
		{
			nBFrameCounter = MAX_FRAME_COUNT;
		}
	}
	else
	{
		nBFrameCounter --;
		if (nBFrameCounter < 0)
		{
			nBFrameCounter = 0;
		}
	}

}

void ToggleDisplayDeleteText (void)
{
static int nCurStep = 0;

	nCurStep ++;
	nCurStep = nCurStep % 430;
	
	if (DisplayAndDeleteText == NULL)
	{
		DisplayAndDeleteText = 	newText("Display/Delete text", 25, 25 + nCurStep, 12, 10, VisibleF);
		DisplayAndDeleteText->clr = (GXColor){255, 255, 255, 64};
	}
	else
	{
		delN2D(&DisplayAndDeleteText->node);
		DisplayAndDeleteText = NULL;
	}
}


/*
	The main entry point.
*/
int main()
{	
	//Initialization Code, Video, GC Pads, Wiimotes and Revolution Engine
	REV_Init();
	// Here you should put your Application Init Code
	/////////////////////////////////////////////////

	// Create our objects.
	// We only really care if the 3D objects weren't created properly.
	bool bLoadSucceeded;
	bLoadSucceeded = Create2DObjects ();
	bLoadSucceeded = Create3DObjects ();
	CreateViewPorts ();



	/////////////////////////
	//Main Loop
	/////////////////////////
	while(1)
	{
		REV_PreProcess();	// Update Wiimote Information
		if(WPAD_ButtonsDown(0) & WPAD_BUTTON_HOME)
		{
			REV_Exit();//if user pushed home, we go homeMenu
		}
		
		///////////////////////////////////////////
		// here you should place your main loop code
		// In general don't create objects here
		///////////////////////////////////////////



		// Scroll the text and wrap around.
		TitleText -> node . x += 321;
		TitleText -> node . x = (int)TitleText -> node . x % 960 - 320;

		// If the 3d Objects loaded correctly, we can manipulate them here.
		if (bLoadSucceeded)
		{
			// Rotate the chair object in the Z axis.
			rotate(& theChairObject->node, (Vector){0.0, 0.0, 0.2});

			// Revolve the cylinder.
			StepObject (theCubeObject);
		}
		
		
		/*
			Read user input and increment frame counters.
		*/
		IncrementFrameCounters ();

		/*
			Update the power bar to reflect the A Frame Counter.
		*/
		theAPowerBarWindow->xe= (nAFrameCounter * nAFrameCounter) / (MAX_FRAME_COUNT_F * MAX_FRAME_COUNT_F);
		theAPowerBarWindow->sx= ((nAFrameCounter * nAFrameCounter) / (MAX_FRAME_COUNT_F * MAX_FRAME_COUNT_F)) * 320.0f;

		/*
			Update the power bar to reflect the B Frame Counter.
		*/
		theBPowerBarWindow->xe= (nBFrameCounter * nBFrameCounter) / (MAX_FRAME_COUNT_F * MAX_FRAME_COUNT_F);
		theBPowerBarWindow->sx= ((nBFrameCounter * nBFrameCounter) / (MAX_FRAME_COUNT_F * MAX_FRAME_COUNT_F)) * 320.0f;

		
		/*
			Move the camera based on the user input.
		*/
		float z = 10.0f - 9.99f * ((nAFrameCounter * nAFrameCounter) / (MAX_FRAME_COUNT_F * MAX_FRAME_COUNT_F));
		float y = 0.0f - 3.0f * ((nAFrameCounter * nAFrameCounter) / (MAX_FRAME_COUNT_F * MAX_FRAME_COUNT_F));
		setPos (&defaultCam()->node, (Vector){0, y, z});

		float angle = 270 + (nAFrameCounter * nAFrameCounter / (MAX_FRAME_COUNT * MAX_FRAME_COUNT / 90.0f));
		setAng (& defaultCam()->node, (Vector){angle, 0, 0 });	// In Degrees.


		

		/*
			Change light to be more reddish based on the B Frame Counter.
		*/
		setAmbLight((GXColor){255, 255 - nBFrameCounter / 4, 255 - nBFrameCounter / 2, 255});


		/*
			Testing creating and deleting 2D text objects.
		*/
		ToggleDisplayDeleteText ();


		// Display fps
		sprintf (SomeInfoText -> text, "%3.3f fps", frameTime() * 60 * 60);

		///////////////////////////////
		REV_Process();//This is the Function that makes all the magic
		///////////////////////////////
		//Calling REV_Process() at the end of your main loop does all the work. Easy, isn't it?
		///////////////////////////////
	}
}
