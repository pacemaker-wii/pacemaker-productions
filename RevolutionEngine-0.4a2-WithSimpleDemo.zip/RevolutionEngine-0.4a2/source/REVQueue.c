/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>

#include "REVQueue.h"

//Internal functions
ELEMENT * newElement()
{
	ELEMENT * el = (ELEMENT*)malloc(sizeof(ELEMENT));
	el->next = NULL;
	el->type = 0;
	el->flags = 0;
	return el;
}
