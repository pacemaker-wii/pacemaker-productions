/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVMaterial.h"
#include "REVCntMgr.h"

//Global data
extern CNTMGR * mainCntMgr;

//Public functions
GXTexObj * pngFor2D(const char * filename)
{
	//First we look into the content manager, if the texture is alredy loaded,
	//we return it instead of loading again
	IMGMAP * auxMap = mainCntMgr->mapList;
	if(mainCntMgr&&mainCntMgr->mapList)
	{
		while(auxMap)
		{
			if(!strcmp(filename, auxMap->name))//if the name is the same
				return auxMap->map;//return it's texture map
			//else
			auxMap = auxMap->next;//check for the next map
		}
	}
	FILE * temp = fopen(filename, "rb");
	if(!temp)
		return NULL;
	else fclose(temp);
	auxMap = (IMGMAP*)malloc(sizeof(IMGMAP));//we create a new map tracker
	strcpy(auxMap->name, filename);//fill its name
	auxMap->next = mainCntMgr->mapList;
	mainCntMgr->mapList = auxMap;//We add it to the list
	//We actually load the file
	GXTexObj * map = (GXTexObj*)memalign(32, sizeof(GXTexObj));
	PNGUPROP imgProp;
	IMGCTX ctx = PNGU_SelectImageFromDevice(filename);
	PNGU_GetImageProperties(ctx,&imgProp);
	void * data = memalign(32, imgProp.imgWidth * imgProp.imgHeight * 4);
	GX_InitTexObj (map, data, imgProp.imgWidth, imgProp.imgHeight, GX_TF_RGBA8, GX_CLAMP, GX_CLAMP, GX_FALSE);
	PNGU_DecodeTo4x4RGBA8 (ctx, imgProp.imgWidth, imgProp.imgHeight, data, 255);
	PNGU_ReleaseImageContext (ctx);
	DCFlushRange (data, imgProp.imgWidth * imgProp.imgHeight * 4);
	auxMap->map = map;//Assign the loaded image to the new map
	return map;//And return the texture
}

GXTexObj * loadPng(const char * filename)
{
	//First we look into the content manager, if the texture is alredy loaded,
	//we return it instead of loading again
	IMGMAP * auxMap = mainCntMgr->mapList;
	if(mainCntMgr&&mainCntMgr->mapList)
	{
		while(auxMap)
		{
			if(!strcmp(filename, auxMap->name))//if the name is the same
				return auxMap->map;//return it's texture map
			//else
			auxMap = auxMap->next;//check for the next map
		}
	}
	FILE * temp = fopen(filename, "rb");
	if(!temp)
		return NULL;
	else fclose(temp);
	auxMap = (IMGMAP*)malloc(sizeof(IMGMAP));//we create a new map tracker
	strcpy(auxMap->name, filename);//fill its name
	auxMap->next = mainCntMgr->mapList;
	mainCntMgr->mapList = auxMap;//We add it to the list
	//We actually load the file
	GXTexObj * map = (GXTexObj*)memalign(32, sizeof(GXTexObj));
	PNGUPROP imgProp;
	IMGCTX ctx = PNGU_SelectImageFromDevice(filename);
	PNGU_GetImageProperties(ctx,&imgProp);
	void * data = memalign(32, imgProp.imgWidth * imgProp.imgHeight * 4);
	GX_InitTexObj (map, data, imgProp.imgWidth, imgProp.imgHeight, GX_TF_RGBA8, GX_MIRROR, GX_MIRROR, GX_FALSE);
	PNGU_DecodeTo4x4RGBA8 (ctx, imgProp.imgWidth, imgProp.imgHeight, data, 255);
	PNGU_ReleaseImageContext (ctx);
	DCFlushRange (data, imgProp.imgWidth * imgProp.imgHeight * 4);
	auxMap->map = map;//Assign the loaded image to the new map
	return map;//And return the texture
}

BMATERIAL * basicMat(GXColor diffuseClr, GXColor specularClr)
{
	BMATERIAL * nMat = (BMATERIAL*)memalign(32,sizeof(BMATERIAL));
	nMat->diffuseMap = NULL;
	nMat->specularMap = NULL;
	nMat->specularity = 1.0;
	nMat->next = NULL;
	nMat->diffuseClr = diffuseClr;
	nMat->specularClr = specularClr;
	nMat->flags = 0;
	nMat->type = MT_BASIC;
	nMat->difUV = 0;
	nMat->specUV = 0;
	nMat->lUV = 0;
	return nMat;
}

MATERIAL * maskedMat(GXTexObj * baseMap, GXTexObj *topMap, GXTexObj * mask)
{
	MMATERIAL * nMat = (MMATERIAL*)malloc(sizeof(MMATERIAL));
	nMat->type = 1;
	nMat->flags = 0;
	nMat->mask = mask;
	nMat->baseMap = baseMap;
	nMat->topMap = topMap;
	nMat->topClr = C_WHITE;
	nMat->baseClr = C_WHITE;
	return (MATERIAL*)nMat;
}
