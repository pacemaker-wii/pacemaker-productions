/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVTypes.h"

//Global data
extern ROOT * mainRoot;
GXColor ambientLight = {140,140,140,255};

LIGHT * newLight(Vector direction, GXColor clr, u8 flags)
{
	LIGHT * nL = (LIGHT*)malloc(sizeof(LIGHT));
	nL->direction = direction;
	nL->next = mainRoot->fstLight;
	mainRoot->fstLight = nL;
	nL->clr = clr;
	nL->type = LIGHT_DIR;
	nL->flags = flags;
	return nL;
}

GXColor getAmbLight()
{
	return ambientLight;
}

void setAmbLight(GXColor clr)
{
	ambientLight = clr;
}

void specularLightsClr(Mtx absMtx,f32 specularity, MESH * mesh, u16 vIdx, u16 nIdx, u8 *r,u8 * g,u8 * b,u8 * a, Vector camPos)
{
	LIGHT * auxLight = mainRoot->fstLight;
	f32 exp, cosA, r0 = 0,g0 = 0,b0 = 0,r1,g1,b1, a0;
	Vector lDir, normal, tNormal, *list, vDir, pos, tPos, half;
	while(auxLight)
	{
		if(auxLight->flags)
		{
		r1 = auxLight->clr.r;
		g1 = auxLight->clr.g;
		b1 = auxLight->clr.b;
		//Get Light Direction
		switch(auxLight->type)
		{
			case LIGHT_DIR:
			{
				lDir = auxLight->direction;
				break;
			}
		}
		guVecNormalize(&lDir);
		//Get Normal
		list = (Vector*)mesh->normals;
		tNormal = list[nIdx];
		guVecMultiplySR(absMtx,&tNormal,&normal);
		//Compute view direction
		list = (Vector*)mesh->vertices;
		tPos = list[vIdx];
		guVecMultiply(absMtx,&tPos,&pos);
		guVecSub(&pos, &camPos, &vDir);
		guVecNormalize(&vDir);
		//Compute half-angle vector
		guVecAdd(&vDir, &lDir, &half);
		guVecNormalize(&half);
		if((cosA = -guVecDotProduct(&half,&normal)) > 0)
		{
			exp = pow(cosA, specularity);
			r1 *= exp;
			g1 *= exp;
			b1 *= exp;
			r0 += r1;
			g0 += g1;
			b0 += b1;
		}}
		/////
		auxLight = auxLight->next;
	}
	if(r0 < 255)
	*r = (u8)r0;else *r = 255;
	if(g0 < 255)
	*g = (u8)g0;else *g = 255;
	if(b0 < 255)
	*b = (u8)b0;else *b = 255;
	a0 = (*r+*g+*b)*0.333333f;//Have to improve this conversion
	*a = (u8)a0;
}

void diffuseLightModel(Mtx absMtx, MODEL * model)
{
	u16 i, j;
	LIGHT * auxLight;
	MESH * mesh;
	f32 cosA, r0,g0,b0,r1,g1,b1;
	Vector lDir, normal, tNormal, *list;
	for(j = 0; j<model->nMeshes; j++)
	{
		mesh = &model->meshes[j];
		list = (Vector*)mesh->normals;
		for(i=0;i<mesh->nNormals;i++)
		{
			r0 = ambientLight.r;
			g0 = ambientLight.g;
			b0 = ambientLight.b;
			auxLight = mainRoot->fstLight;
			while(auxLight)
			{
				if(auxLight->flags){
				r1 = auxLight->clr.r;
				g1 = auxLight->clr.g;
				b1 = auxLight->clr.b;
				//Get Light Direction
				switch(auxLight->type)
				{
					case LIGHT_DIR:
					{
						lDir = auxLight->direction;
						break;
					}
				}
				guVecNormalize(&lDir);
				tNormal = list[i];
				guVecMultiplySR(absMtx,&tNormal,&normal);
				//Calculate attenuation
				if((cosA = -guVecDotProduct(&normal, &lDir)) > 0)
				{
					r1*=cosA;
					g1*=cosA;
					b1*=cosA;
					//Add light clr
					r0 += r1;
					g0 += g1;
					b0 += b1;
				}}
				/////
				auxLight = auxLight->next;
			}
			if(r0 < 255)
			mesh->diffuse[i].r = (u8)r0;else mesh->diffuse[i].r = 255;
			if(g0 < 255)
			mesh->diffuse[i].g = (u8)g0;else mesh->diffuse[i].g = 255;
			if(b0 < 255)
			mesh->diffuse[i].b = (u8)b0;else mesh->diffuse[i].b = 255;
		}
		DCFlushRange(mesh->diffuse, mesh->nNormals*sizeof(GXColor));
	}
}
