/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVCntMgr.h"

//Global data
CNTMGR * mainCntMgr;

//Public Functions
void initCntMgr(void)
{
	mainCntMgr = (CNTMGR*)malloc(sizeof(CNTMGR));
	mainCntMgr->matList = NULL;
	mainCntMgr->modelList = NULL;
	mainCntMgr->bodyList = NULL;
	mainCntMgr->mapList = NULL;
}

void cleanContent(void)
{
}
