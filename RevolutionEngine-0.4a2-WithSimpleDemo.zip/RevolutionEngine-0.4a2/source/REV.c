
	/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVTypes.h"
#include "REVCntMgr.h"
#include "REVScreen.h"
#include "REVDefinitions.h"
#include "REVCam.h"
#include "REVTime.h"
#include "REVPhysics.h"
#include "REVFonts.h"
#include "REVLights.h"
#include "REVNodes.h"

//definitions
#define DEFAULT_FIFO_SIZE	(256*1024)

//Global data
static void *frameBuffer[2] = { NULL, NULL};
GXRModeObj *rmode;
Mtx view; // view Matrix
Mtx model, modelview;
u16 w, h;
Mtx perspective;
u32	fb = 0; 	// initial framebuffer index
GXColor background = {0, 0, 0, 0xff};
CAMERA * tCamera;
TRACKER * sQueue;//a Queue for Solid Objects
TRACKER * tTrack;
TRACKER * tQueue;//a Queue for transparent Objects
ZTRACKER * zQueue;//an ordered Queue for transparent Objects
ZTRACKER * tzTrack;
ZTRACKER * auxT;
u32 tCount;
Vector camPos;
ROOT * mainRoot;

//Internal Prototypes
void REV_Render(OBJECT * auxObj);
void newRoot(u16 w, u16 h);
void delRoot();
void setUp3d();
void setUp2d();

//Public functions
u32 getTriangleCount()
{
	return tCount;
}

void REV_Init()
{
	f32 yscale;
	u32 xfbHeight;
	u8 i;
	
	u32	fb = 0; 	// initial framebuffer index
	VIDEO_Init();
	PAD_Init();
	WPAD_Init();
	rmode = VIDEO_GetPreferredMode(NULL);
	
	// allocate 2 framebuffers for double buffering
	frameBuffer[0] = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
	frameBuffer[1] = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));

	VIDEO_Configure(rmode);
	VIDEO_SetNextFramebuffer(frameBuffer[fb]);
	VIDEO_ClearFrameBuffer (rmode, frameBuffer[0], 0);
	VIDEO_ClearFrameBuffer (rmode, frameBuffer[1], 0);
	VIDEO_SetBlack(FALSE);
	VIDEO_Flush();
	VIDEO_WaitVSync();
	if(rmode->viTVMode&VI_NON_INTERLACE) VIDEO_WaitVSync();

	//fat init default
	fatInitDefault ();
	// setup the fifo and then init the flipper
	void *gp_fifo = NULL;
	gp_fifo = memalign(32,DEFAULT_FIFO_SIZE);
	memset(gp_fifo,0,DEFAULT_FIFO_SIZE);
 
	GX_Init(gp_fifo,DEFAULT_FIFO_SIZE);
 
	// clears the bg to color and clears the z buffer
	GX_SetCopyClear(background, 0x00ffffff);
	
	GX_SetViewport(0,0,rmode->fbWidth,rmode->efbHeight,0,1);
	yscale = GX_GetYScaleFactor(rmode->efbHeight,rmode->xfbHeight);
	xfbHeight = GX_SetDispCopyYScale(yscale);
	GX_SetScissor(0,0,rmode->fbWidth,rmode->efbHeight);
	GX_SetDispCopySrc(0,0,rmode->fbWidth,rmode->efbHeight);
	GX_SetDispCopyDst(rmode->fbWidth,xfbHeight);
	GX_SetCopyFilter(rmode->aa,rmode->sample_pattern,GX_TRUE,rmode->vfilter);
	GX_SetFieldMode(rmode->field_rendering,((rmode->viHeight==2*rmode->xfbHeight)?GX_ENABLE:GX_DISABLE));
 
	GX_SetCullMode(GX_CULL_BACK);
	GX_CopyDisp(frameBuffer[fb],GX_TRUE);
	GX_SetDispCopyGamma(GX_GM_1_0);
	
	w = rmode->viWidth;
    h = rmode->viHeight;
	
	GX_SetBlendMode(GX_BM_BLEND, GX_BL_SRCALPHA, GX_BL_INVSRCALPHA, GX_LO_CLEAR);
	GX_SetColorUpdate(GX_ENABLE);
	GX_SetAlphaUpdate(GX_ENABLE);
	GX_SetZCompLoc(GX_FALSE);
	/////////////////////////////
	newRoot(w,h);//We Init mainRoot
	initCams();
	mainRoot->mainViewport = newViewport(0,0,w,h,10,defaultCam(),VisibleF);
	for(i = 0; i < 4; i++)
	WPAD_SetVRes(i,w,h);
	init2D();
	initCntMgr();//We Init the contents manager
	REV_fontsInit();//FreeType Init
	//Lighting
	srand48(gettime());
}

void REV_PreProcess()
{
	WPAD_ScanPads();
	PAD_ScanPads();
	update2D();
}

void clasify(NODE * node)
{
	OBJECT * auxObj;
	NODE * auxN = node;
	while(auxN)
	{
		if(auxN->flags & VisibleF)
		{
			if(auxN->child)
				clasify(auxN->child);
			if(auxN->type == NT_OBJECT)//If it's an object
			{//Clasify it into the lists
				auxObj = (OBJECT*)auxN;
				if(auxObj->model && (auxObj->flags & VisibleF))//We don't care about invisible objects
				{
					tTrack = (TRACKER*)malloc(sizeof(TRACKER));
					tTrack->target = auxObj;
					if(auxObj->material)
					{
						if((!(((MATERIAL*)auxObj->material)->flags & AlfaF))&&(auxObj->clr.a == 255))
						{
							tTrack->next = sQueue;
							sQueue = tTrack;
						}
						else
						{
							tTrack->next = tQueue;
							tQueue = tTrack;
						}
					}
					else
					{
						if(auxObj->clr.a == 255)//Solid Object
						{
							tTrack->next = sQueue;
							sQueue = tTrack;
						}
						else//Transparent Object
						{
							tTrack->next = tQueue;
							tQueue = tTrack;
						}
					}
				}
			}
		}
		auxN = auxN->next;
	}
}

void REV_Process()
{
	//Global data
	VIEWPORT * tView = mainRoot->mainViewport;
	sQueue = NULL;//a Queue for Solid Objects
	tQueue = NULL;//a Queue for transparent Objects
	zQueue = NULL;//an ordered Queue for transparent Objects
	tzTrack = NULL;
	auxT = NULL;
	Vector v;
	tCount = 0;
	Mtx camMtx;
	//Update World
	updtTime();//Update time
	updateSpace();//Now space
	//Clasify objects into lists depending on their visibility
	clasify(mainRoot->rootNode->child);
	//Lists created
	while(tView)//for each viewport, draw it
	{
		if(tView->flags & VisibleF)
		{
			setViewPort(tView);
			guPerspective(perspective, 45, (f32)(tView->sx/tView->sy), 0.01F, 10000.0F);
			GX_LoadProjectionMtx(perspective, GX_PERSPECTIVE);
			tCamera = tView->cam;
			getAbsMtx((NODE*)tCamera, camMtx);
			camPos = vector(camMtx[0][3], camMtx[1][3], camMtx[2][3]);
			updtMtx(tCamera, view);
			setUp3d();
			//Draw solid objects
			for(tTrack = sQueue; tTrack; tTrack = tTrack->next)
				REV_Render(tTrack->target);
			//Now we order the transparent Queue from the current point on view
			for(tTrack = tQueue; tTrack; tTrack = tTrack->next)
			{
				tzTrack = (ZTRACKER*)malloc(sizeof(ZTRACKER));
				tzTrack->target = tTrack->target;
				tzTrack->next = NULL;
				guVecMultiply(view, &tzTrack->target->node.pos, &v);
				tzTrack->distance = -v.z;
				auxT = zQueue;
				if(zQueue)
				{
					while(auxT->next)
					{
						if(tzTrack->distance < auxT->next->distance)
							auxT = auxT->next;
						else break;
					}
					if(tzTrack->distance < auxT->distance)
					{
						tzTrack->next = auxT->next;
						auxT->next = tzTrack;
					}
					else
					{
						tzTrack->next = zQueue;
						zQueue = tzTrack;
					}
				}
				else
				{
					zQueue = tzTrack;
				}
			}
			//And draw the ordered transparent Objects
			for(tzTrack = zQueue; tzTrack; tzTrack = tzTrack->next)
			{
				//Back faces first
				GX_SetCullMode(GX_CULL_FRONT);
				REV_Render(tzTrack->target);
				//And then front faces
				GX_SetCullMode(GX_CULL_BACK);
				REV_Render(tzTrack->target);
			}
		}
		tView = tView->next;
	}
	//And finally we delete all our temporary stuff
	//Solid Queue
	while(sQueue)
	{
		tTrack = sQueue;
		sQueue = sQueue->next;
		free(tTrack);
	}
	//Transparent Queue
	while(tQueue)
	{
		tTrack = tQueue;
		tQueue = tQueue->next;
		free(tTrack);
	}
	//Ordered trnasparent Queue
	while(zQueue)
	{
		tzTrack = zQueue;
		zQueue = zQueue->next;
		free(tzTrack);
	}
	//3D done
	GX_SetViewport(0,0,rmode->fbWidth,rmode->efbHeight,0,1);
	GX_SetScissor(0,0,rmode->fbWidth,rmode->efbHeight);
	setUp2d();
	render2d();
	//frame ending
	GX_DrawDone();
	fb ^= 1;		// flip framebuffer
	GX_SetColorUpdate(GX_TRUE);
	GX_CopyDisp(frameBuffer[fb],GX_TRUE);

	VIDEO_SetNextFramebuffer(frameBuffer[fb]);
 
	VIDEO_Flush();

	VIDEO_WaitVSync();
}

void REV_Exit()
{
	exit(0);
}
//Internal Functions
void REV_Render(OBJECT * auxObj)
{
	u16 i, j, k;
	u8 r,g,b,a, dmp=0, smp=0;
	MODEL * model;
	MESH * mesh;
	MATERIAL * mat;
	Mtx absMtx;
	getAbsMtx((NODE*)auxObj,absMtx);
	if(((MODEL*)auxObj->model)->type == MT_STATIC)
	{
		model = auxObj->model;
		diffuseLightModel(absMtx, model);
		guMtxConcat(view,absMtx,modelview);
		GX_LoadPosMtxImm(modelview, GX_PNMTX0);
		GX_ClearVtxDesc();
		GX_SetVtxDesc(GX_VA_POS, GX_INDEX16);
		if((mat = auxObj->material))
		{
			switch(mat->type)
			{
				case MT_BASIC:
				{
					BMATERIAL * bmat = (BMATERIAL*)mat;
					GX_SetVtxDesc(GX_VA_CLR0, GX_INDEX16);//Diffuse lighting
					GX_SetVtxDesc(GX_VA_CLR1, GX_DIRECT);//Specular lighting
					GX_SetNumChans(2);
					GX_SetNumTevStages(3);
					GX_SetTevKColor(GX_KCOLOR0,auxObj->clr);//Object color, modulates final output
					GX_SetTevKColorSel(GX_TEVSTAGE2, GX_TEV_KCSEL_K0);
					GX_SetTevKAlphaSel(GX_TEVSTAGE2, GX_TEV_KASEL_K0_A);
					if((model->nUVSets)&&(bmat->diffuseMap||bmat->specularMap))
					{
						//TEVSTAGE 0
						if(bmat->diffuseMap)
						{
							dmp = 1;
							GX_SetVtxDesc(GX_VA_TEX0, GX_INDEX16);
							GX_LoadTexObj(bmat->diffuseMap, GX_TEXMAP0);
							GX_SetTevColorIn(GX_TEVSTAGE0, GX_CC_ZERO, GX_CC_RASC, GX_CC_TEXC, GX_CC_ZERO);
							GX_SetTevAlphaIn(GX_TEVSTAGE0, GX_CA_ZERO, GX_CA_ZERO, GX_CA_ZERO, GX_CA_TEXA);
							GX_SetTevOrder(GX_TEVSTAGE0, GX_TEXCOORD0, GX_TEXMAP0, GX_COLOR0A0);
						}
						else
						{
							dmp = 0;
							GX_SetTevKColor(GX_KCOLOR1, bmat->diffuseClr);
							GX_SetTevKColorSel(GX_TEVSTAGE0, GX_TEV_KCSEL_K1);
							GX_SetTevKAlphaSel(GX_TEVSTAGE0, GX_TEV_KASEL_K1_A);
							GX_SetTevColorIn(GX_TEVSTAGE0, GX_CC_ZERO, GX_CC_RASC, GX_CC_KONST, GX_CC_ZERO);
							GX_SetTevAlphaIn(GX_TEVSTAGE0, GX_CA_ZERO, GX_CA_ZERO, GX_CA_ZERO, GX_CA_KONST);
							GX_SetTevOrder(GX_TEVSTAGE0, GX_TEXCOORDNULL, GX_TEXMAP_NULL, GX_COLOR0A0);
						}
						GX_SetTevColorOp(GX_TEVSTAGE0, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_ENABLE, GX_TEVPREV);
						GX_SetTevAlphaOp(GX_TEVSTAGE0, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_ENABLE, GX_TEVPREV);
						//TEVSTAGE 1
						if(bmat->specularMap)
						{
							smp = 1;
							GX_SetVtxDesc(GX_VA_TEX1, GX_INDEX16);
							GX_LoadTexObj(bmat->specularMap, GX_TEXMAP1);
							GX_SetTevColorIn(GX_TEVSTAGE1, GX_CC_ZERO, GX_CC_RASC, GX_CC_TEXC, GX_CC_ZERO);
							GX_SetTevAlphaIn(GX_TEVSTAGE1, GX_CA_ZERO, GX_CA_RASA, GX_CA_TEXA, GX_CA_ZERO);
							GX_SetTevOrder(GX_TEVSTAGE1, GX_TEXCOORD1, GX_TEXMAP1, GX_COLOR1A1);
						}
						else
						{
							smp = 0;
							GX_SetTevKColor(GX_KCOLOR2, bmat->specularClr);
							GX_SetTevKColorSel(GX_TEVSTAGE1, GX_TEV_KCSEL_K2);
							GX_SetTevKAlphaSel(GX_TEVSTAGE1, GX_TEV_KASEL_K2_A);
							GX_SetTevColorIn(GX_TEVSTAGE1, GX_CC_ZERO, GX_CC_RASC, GX_CC_KONST, GX_CC_ZERO);
							GX_SetTevAlphaIn(GX_TEVSTAGE1, GX_CA_ZERO, GX_CA_RASA, GX_CA_KONST, GX_CA_ZERO);
							GX_SetTevOrder(GX_TEVSTAGE1, GX_TEXCOORDNULL, GX_TEXMAP_NULL, GX_COLOR1A1);
						}
						GX_SetTevColorOp(GX_TEVSTAGE1, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_ENABLE, GX_TEVREG0);
						GX_SetTevAlphaOp(GX_TEVSTAGE1, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_ENABLE, GX_TEVREG0);
						//TEVSTAGE 2
						GX_SetTevColorIn(GX_TEVSTAGE2, GX_CC_CPREV, GX_CC_C0, GX_CC_A0, GX_CC_ZERO);
						GX_SetTevAlphaIn(GX_TEVSTAGE2, GX_CA_A0, GX_CA_ZERO, GX_CA_APREV, GX_CA_APREV);
						GX_SetTevColorOp(GX_TEVSTAGE2, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_ENABLE, GX_TEVPREV);
						GX_SetTevAlphaOp(GX_TEVSTAGE2, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_ENABLE, GX_TEVPREV);
						for(i = 0; i < model->nMeshes; i++)
						{
							mesh = &model->meshes[i];
							GX_SetArray(GX_VA_POS, mesh->vertices, 3*sizeof(f32));
							GX_SetArray(GX_VA_CLR0, mesh->diffuse, sizeof(GXColor));
							if(dmp)
							GX_SetArray(GX_VA_TEX0, mesh->uvSets[0].uvs, 2*sizeof(f32));
							if(smp)
							GX_SetArray(GX_VA_TEX1, mesh->uvSets[0].uvs, 2*sizeof(f32));
							GX_Begin(GX_TRIANGLES, GX_VTXFMT0, 3*mesh->nTris);
							for(j = 0; j < mesh->nTris; j++)
							{
								for(k = 0; k<3; k++)
								{
									GX_Position1x16(mesh->vList[j*3+k]);
									GX_Color1x16(mesh->nList[3*j+k]);
									specularLightsClr(absMtx,bmat->specularity,
										mesh, mesh->vList[j*3+k], mesh->nList[3*j+k],
										&r,&g,&b,&a, camPos);
									GX_Color4u8(r,g,b,a);
									if(dmp)
									GX_TexCoord1x16(mesh->uvSets[0].uvList[3*j+k]);
									if(smp)
									GX_TexCoord1x16(mesh->uvSets[0].uvList[3*j+k]);
								}
							}
							GX_End();
							GX_Begin(GX_QUADS, GX_VTXFMT0, 4*mesh->nQuads);
							for(j = 0; j < mesh->nQuads; j++)
							{
								for(k = 0; k < 4; k++)
								{
									GX_Position1x16(mesh->vList[j*3+k]);
									GX_Color1x16(mesh->nList[3*j+k]);
									specularLightsClr(absMtx,bmat->specularity,
										mesh, mesh->vList[j*3+k], mesh->nList[3*j+k],
										&r,&g,&b,&a, camPos);
									GX_Color4u8(r,g,b,a);
									if(dmp)
									GX_TexCoord1x16(mesh->uvSets[0].uvList[3*j+k]);
									if(smp)
									GX_TexCoord1x16(mesh->uvSets[0].uvList[3*j+k]);
								}
							}
							GX_End();
						}
					}
					else
					{
						GX_SetTevKColor(GX_KCOLOR1, bmat->diffuseClr);
						GX_SetTevKColorSel(GX_TEVSTAGE0, GX_TEV_KCSEL_K1);
						GX_SetTevKAlphaSel(GX_TEVSTAGE0, GX_TEV_KASEL_K1_A);
						GX_SetTevKColor(GX_KCOLOR2, bmat->specularClr);
						GX_SetTevKColorSel(GX_TEVSTAGE1, GX_TEV_KCSEL_K2);
						GX_SetTevKAlphaSel(GX_TEVSTAGE1, GX_TEV_KASEL_K2_A);
						//TEVSTAGE 0
						GX_SetTevColorIn(GX_TEVSTAGE0, GX_CC_ZERO, GX_CC_RASC, GX_CC_KONST, GX_CC_ZERO);
						GX_SetTevAlphaIn(GX_TEVSTAGE0, GX_CA_ZERO, GX_CA_ZERO, GX_CA_ZERO, GX_CA_KONST);
						GX_SetTevColorOp(GX_TEVSTAGE0, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_ENABLE, GX_TEVREG1);
						GX_SetTevAlphaOp(GX_TEVSTAGE0, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_ENABLE, GX_TEVREG1);
						GX_SetTevOrder(GX_TEVSTAGE0, GX_TEXCOORDNULL, GX_TEXMAP_NULL, GX_COLOR0A0);
						//TEVSTAGE 1
						GX_SetTevColorIn(GX_TEVSTAGE1, GX_CC_ZERO, GX_CC_RASC, GX_CC_KONST, GX_CC_ZERO);
						GX_SetTevAlphaIn(GX_TEVSTAGE1, GX_CA_ZERO, GX_CA_RASA, GX_CA_KONST, GX_CA_ZERO);
						GX_SetTevColorOp(GX_TEVSTAGE1, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_ENABLE, GX_TEVREG0);
						GX_SetTevAlphaOp(GX_TEVSTAGE1, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_ENABLE, GX_TEVREG0);
						GX_SetTevOrder(GX_TEVSTAGE1, GX_TEXCOORDNULL, GX_TEXMAP_NULL, GX_COLOR1A1);
						//TEVSTAGE 2
						GX_SetTevColorIn(GX_TEVSTAGE2, GX_CC_C1, GX_CC_C0, GX_CC_A0, GX_CC_ZERO);
						GX_SetTevAlphaIn(GX_TEVSTAGE2, GX_CA_A0, GX_CA_ZERO, GX_CA_A1, GX_CA_A1);
						GX_SetTevColorOp(GX_TEVSTAGE2, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_ENABLE, GX_TEVPREV);
						GX_SetTevAlphaOp(GX_TEVSTAGE2, GX_TEV_ADD, GX_TB_ZERO, GX_CS_SCALE_1, GX_ENABLE, GX_TEVPREV);
						for(i = 0; i < model->nMeshes; i++)
						{
							mesh = &model->meshes[i];
							GX_SetArray(GX_VA_POS, mesh->vertices, 3*sizeof(f32));
							GX_SetArray(GX_VA_CLR0, mesh->diffuse, sizeof(GXColor));
							GX_Begin(GX_TRIANGLES, GX_VTXFMT0, 3*mesh->nTris);
							for(j = 0; j < mesh->nTris; j++)
							{
								for(k = 0; k<3; k++)
								{
									GX_Position1x16(mesh->vList[j*3+k]);
									GX_Color1x16(mesh->nList[3*j+k]);
									specularLightsClr(absMtx,bmat->specularity,
										mesh, mesh->vList[j*3+k], mesh->nList[3*j+k],
										&r,&g,&b,&a, camPos);
									GX_Color4u8(r,g,b,a);
								}
							}
							GX_End();
							GX_Begin(GX_QUADS, GX_VTXFMT0, 4*mesh->nQuads);
							for(j = 0; j < mesh->nQuads; j++)
							{
								for(k = 0; k < 4; k++)
								{
									GX_Position1x16(mesh->vList[j*3+k]);
									GX_Color1x16(mesh->nList[3*j+k]);
									specularLightsClr(absMtx,bmat->specularity,
										mesh, mesh->vList[j*3+k], mesh->nList[3*j+k],
										&r,&g,&b,&a, camPos);
									GX_Color4u8(r,g,b,a);
								}
							}
							GX_End();
						}
					}
				}
			}
		}
		else
		{
			GX_SetVtxDesc(GX_VA_CLR0, GX_INDEX16);
			GX_SetNumChans(1);
		
			GX_SetTevColor(GX_TEVREG0,auxObj->clr);
			GX_SetNumTevStages(1);
			GX_SetTevOp(GX_TEVSTAGE0, GX_MODULATE);
			GX_SetTevColorIn(GX_TEVSTAGE0, GX_CC_ZERO, GX_CC_RASC, GX_CC_C0, GX_CC_ZERO);
			GX_SetTevAlphaIn(GX_TEVSTAGE0, GX_CA_ZERO, GX_CA_ZERO, GX_CA_ZERO, GX_CA_A0);
			GX_SetTevOrder(GX_TEVSTAGE0, GX_TEXCOORDNULL, GX_TEXMAP_NULL, GX_COLOR0A0);
			
			for(i = 0; i < model->nMeshes; i++)
			{
				mesh = &model->meshes[i];
				GX_SetArray(GX_VA_POS, mesh->vertices, 3*sizeof(f32));
				GX_SetArray(GX_VA_CLR0, mesh->diffuse, sizeof(GXColor));
				GX_Begin(GX_TRIANGLES, GX_VTXFMT0, 3*mesh->nTris);
				for(j = 0; j<mesh->nTris; j++)
				{
					for(k = 0; k<3; k++)
					{
						GX_Position1x16(mesh->vList[j*3+k]);
						GX_Color1x16(mesh->nList[3*j+k]);
					}
				}
				GX_End();
				GX_Begin(GX_QUADS, GX_VTXFMT0, 4*mesh->nQuads);
				for(j = 0; j<mesh->nQuads; j++)
				{
					for(k = 3*mesh->nTris; k<3*mesh->nTris+4; k++)
					{
						GX_Position1x16(mesh->vList[j*4+k]);
						GX_Color1x16(mesh->nList[4*j+k]);
					}
				}
				GX_End();
			}
		}
	}
}

void newRoot(u16 w, u16 h)
{
	mainRoot = (ROOT*)malloc(sizeof(ROOT));
	mainRoot->fstLight = NULL;
	mainRoot->fstBtn = NULL;
	mainRoot->mainViewport = NULL;
	//Create the root node in the 3D subsystem
	mainRoot->rootNode = (NODE*)malloc(sizeof(NODE));
	mainRoot->rootNode->type = NT_NODE;
	mainRoot->rootNode->flags = 0;
	mainRoot->rootNode->pos = nullVector;
	mainRoot->rootNode->spd = nullVector;
	mainRoot->rootNode->asp = nullVector;
	guMtxIdentity(mainRoot->rootNode->modMtx);
	mainRoot->rootNode->mode = 0;
	mainRoot->rootNode->next = NULL;
	mainRoot->rootNode->child = NULL;
	mainRoot->rootNode->parent = NULL;
	//Create the root node in the 2D subsystem
	mainRoot->rootN2D = (N2D*)malloc(sizeof(N2D));
	mainRoot->rootN2D->type = NT_NODE;
	mainRoot->rootN2D->flags = VisibleF;
	mainRoot->rootN2D->parent = NULL;
	mainRoot->rootN2D->next = NULL;
	mainRoot->rootN2D->child = NULL;
	mainRoot->rootN2D->ang = 0;
	mainRoot->rootN2D->x = 0;
	mainRoot->rootN2D->y = 0;
}

void delRoot()
{
	//delete all objects
	free(mainRoot);
}

void setUp3d()
{
	GX_InvalidateTexAll();
	
	//Atributes format
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS, GX_POS_XYZ, GX_F32, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_CLR0, GX_CLR_RGBA, GX_RGBA8, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_CLR1, GX_CLR_RGBA, GX_RGBA8, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX0, GX_TEX_ST, GX_F32, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX1, GX_TEX_ST, GX_F32, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX2, GX_TEX_ST, GX_F32, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX3, GX_TEX_ST, GX_F32, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX4, GX_TEX_ST, GX_F32, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX5, GX_TEX_ST, GX_F32, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX6, GX_TEX_ST, GX_F32, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX7, GX_TEX_ST, GX_F32, 0);
	
	//Z and tev
	GX_SetZMode (GX_TRUE, GX_LEQUAL, GX_TRUE);
	GX_SetNumTexGens(1);
	GX_SetCullMode(GX_CULL_BACK);
}

void setUp2d()
{
	GX_ClearVtxDesc();
	GX_InvalidateTexAll();
	GX_SetVtxDesc(GX_VA_POS, GX_DIRECT);
 	GX_SetVtxDesc(GX_VA_CLR0, GX_DIRECT);
 	GX_SetVtxDesc(GX_VA_TEX0, GX_DIRECT);
	
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_POS, GX_POS_XYZ, GX_F32, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_CLR0, GX_CLR_RGBA, GX_RGBA8, 0);
	GX_SetVtxAttrFmt(GX_VTXFMT0, GX_VA_TEX0, GX_TEX_ST, GX_F32, 0);
	
	GX_SetZMode (GX_FALSE, GX_LEQUAL, GX_TRUE);
	GX_SetNumChans(1);
	GX_SetNumTexGens(1);
	GX_SetNumTevStages(1);
	GX_SetTevOrder(GX_TEVSTAGE0, GX_TEXCOORD0, GX_TEXMAP0, GX_COLOR0A0);
	GX_SetCullMode(GX_CULL_NONE);
	
	guOrtho(perspective,0,480,0,639,1.0,300.0);
	GX_LoadProjectionMtx(perspective, GX_ORTHOGRAPHIC);
}
