/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
//Internal header files
#include "REVNodes.h"
#include "REVTypes.h"
#include "REVDefinitions.h"

//External data
extern ROOT * mainRoot;

//2D Node functions
N2D * node2d(u8 flags)
{
	N2D * node = (N2D*)malloc(sizeof(N2D));
	node->type = NT_NODE;
	node->flags = flags;
	node->next = mainRoot->rootN2D->child;
	node->child = NULL;
	node->parent = mainRoot->rootN2D;
	node->x = 0;
	node->y = 0;
	node->ang = 0;
	return node;
}

void initN2D(N2D * node, u8 type, u8 flags)
{
	node->type = type;
	node->flags = flags;
	node->next = mainRoot->rootN2D->child;
	node->child = NULL;
	node->parent = mainRoot->rootN2D;
	mainRoot->rootN2D->child = node;
	node->x = 0;
	node->y = 0;
	node->ang = 0;
}

void attachN2D(N2D * parent, N2D * child)
{
	N2D * auxN;
	if(child->parent)
	{
		auxN = child->parent->child;
		if(auxN == child)
		{
			child->parent->child = child->next;
		}
		else
		{
			while(auxN->next)
			{
				if(auxN->next == child) break;
				auxN = auxN->next;
			}
			auxN->next = child->next;
		}
	}
	child->next = parent->child;
	parent->child = child;
	child->parent = parent;
}

void delN2D(N2D * node)
{
	N2D * auxN;
	if(node->parent)
	{
		auxN= node->parent->child;
		if(auxN == node)
		{
			node->parent->child = node->next;
		}
		else
		{
			while(auxN->next)
			{
				if(auxN->next == node) break;
				auxN = auxN->next;
			}
			auxN->next = node->next;
		}
	}
	if(node->type == NT_BUTTON)
	{
		if(mainRoot->fstBtn == (BUTTON*)node)
		mainRoot->fstBtn = ((BUTTON*)node)->next;
		else
		{
			BUTTON * auxB = mainRoot->fstBtn;
			while(auxB->next != (BUTTON*)node)
			auxB = auxB->next;
			auxB->next = ((BUTTON*)node)->next;
		}
	}
	free(node);
}

//3D Node functions
NODE * newNode(u8 flags)
{
	NODE * n = (NODE*)malloc(sizeof(NODE));
	n->type = NT_NODE;
	n->flags = flags;
	n->pos = nullVector;
	n->spd = nullVector;
	n->asp = nullVector;
	guMtxIdentity(n->modMtx);
	n->mode = 0;
	n->next = mainRoot->rootNode->child;
	n->child = NULL;
	n->parent = mainRoot->rootNode;
	mainRoot->rootNode->child = n;
	return n;
}

void initNode(NODE * n, u8 type, u8 flags)
{
	n->type = type;
	n->flags = flags;
	n->pos = nullVector;
	n->spd = nullVector;
	n->asp = nullVector;
	guMtxIdentity(n->modMtx);
	n->mode = 0;
	n->next = mainRoot->rootNode->child;
	n->child = NULL;
	n->parent = mainRoot->rootNode;
	mainRoot->rootNode->child = n;
}

void delNode(NODE * node)
{
	NODE * auxN;
	if(node->parent)
	{
		auxN= node->parent->child;
		if(auxN == node)
		{
			node->parent->child = node->next;
		}
		else
		{
			while(auxN->next)
			{
				if(auxN->next == node) break;
				auxN = auxN->next;
			}
			auxN->next = node->next;
		}
	}
	free(node);
}

void move(NODE * node, Vector rel, Vector abs)
{
	Vector pos0;
	guVecMultiplySR(node->modMtx, &rel, &pos0);
	pos0.x += abs.x;
	pos0.y += abs.y;
	pos0.z += abs.z;
	guMtxTransApply(node->modMtx, node->modMtx, pos0.x, pos0.y, pos0.z);
	guVecAdd(&node->pos, &pos0, &node->pos);
}

void rotate(NODE * node, Vector ang)
{
	Vector pos0 = node->pos;
	Mtx Aux;
	guMtxTransApply(node->modMtx, node->modMtx, -pos0.x, -pos0.y, -pos0.z);
	guMtxRotDeg(Aux, 'y', ang.y);
	guMtxConcat(Aux, node->modMtx, node->modMtx);
	guMtxRotDeg(Aux, 'x', ang.x);
	guMtxConcat(Aux, node->modMtx, node->modMtx);
	guMtxRotDeg(Aux, 'z', ang.z);
	guMtxConcat(Aux, node->modMtx, node->modMtx);
	guMtxTransApply(node->modMtx, node->modMtx, pos0.x, pos0.y, pos0.z);
}

void rotateByAxis(NODE * node, Vector * axis, f32 angle)
{
	guMtxTransApply(node->modMtx, node->modMtx, -node->pos.x, -node->pos.y, -node->pos.z);
	guMtxRotAxisDeg(node->modMtx,axis,angle);
	guMtxTransApply(node->modMtx, node->modMtx, node->pos.x, node->pos.y, node->pos.z);
}

void rotateAroundPoint(NODE * node, Vector * axis, Vector * point, f32 angle)
{
	guMtxTransApply(node->modMtx, node->modMtx, -point->x, -point->y, -point->z);
	guMtxRotAxisDeg(node->modMtx,axis,angle);
	guMtxTransApply(node->modMtx, node->modMtx, point->x, point->y, point->z);
}

void setPos(NODE * node, Vector pos)
{
	Vector Pos0 = {pos.x - node->pos.x, pos.y - node->pos.y, pos.z - node->pos.z};
	guMtxTransApply(node->modMtx, node->modMtx, Pos0.x, Pos0.y, Pos0.z);
	node->pos = pos;
}

void setAng(NODE * node, Vector angle)
{
	Vector pos  = node->pos;
	Mtx aux;
	guMtxIdentity(node->modMtx);
	guMtxRotDeg(aux, 'y', angle.y);
	guMtxConcat(aux, node->modMtx, node->modMtx);
	guMtxRotDeg(aux, 'x', angle.x);
	guMtxConcat(aux, node->modMtx, node->modMtx);
	guMtxRotDeg(aux, 'z', angle.z);
	guMtxConcat(aux, node->modMtx, node->modMtx);
	guMtxTransApply(node->modMtx, node->modMtx, pos.x, pos.y, pos.z);
}

void setSpeed(NODE * node, Vector linear, Vector angular)
{
	node->spd = linear;
	node->asp = angular;
}

void attachNode(NODE * parent, NODE * child)
{
	NODE * auxN;
	if(child->parent)
	{
		auxN= child->parent->child;
		if(auxN == child)
		{
			child->parent->child = child->next;
		}
		else
		{
			while(auxN->next)
			{
				if(auxN->next == child) break;
				auxN = auxN->next;
			}
			auxN->next = child->next;
		}
	}
	child->parent = parent;
	child->next = parent->child;
	parent->child = child;
}

void getAbsMtx(NODE * node, Mtx m)
{
	guMtxCopy(node->modMtx, m);
	NODE * auxN = node;
	while(auxN->parent->parent)
	{
		guMtxConcat(auxN->parent->modMtx, m, m);
		auxN = auxN->parent;
	}
}
