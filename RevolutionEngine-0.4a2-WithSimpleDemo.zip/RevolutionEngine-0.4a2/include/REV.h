/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_H
#define REV_H

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>
#include <sys/dir.h>
#include <sys/statvfs.h>
#include <unistd.h>

//Internall header files
#include "REVTime.h"
#include "REVtypes.h"
#include "REVCntMgr.h"
#include "REVScreen.h"
#include "REVDefinitions.h"
#include "REVCam.h"
#include "REVQuat.h"
#include "REVPhysics.h"
#include "REVLights.h"

//Functions
/***REV_Init***/
/*
Description:Inits the engine
Arguments: None
Returns: Nothing
*/
u32 getTriangleCount();

void REV_Init();

void REV_PreProcess();
/***REV_Process***/
/*
Description:Call this function at the end of every frame and it will
			do everything (Physics, rendering, illumination, etc...)
Arguments: None
Returns: Nothing
*/
void REV_Process();

/***REV_Exit***/
/*
Description: Call this function to close your application and go back to the loader
Arguments: None
Returns: Nothing
*/
void REV_Exit();

#endif
