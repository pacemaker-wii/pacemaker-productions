/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_VIEWPORTS_H
#define REV_VIEWPORTS_H

//Header files
#include "REVCam.h"

//structures
typedef struct REV_Viewport
{
	u8 flags, layer;
	f32 x, y, sx, sy;
	CAMERA * cam;
	struct REV_Viewport * next;
}VIEWPORT;

//Public functions
void setViewPort(VIEWPORT * view);

/***newViewport***/
VIEWPORT * newViewport(f32 x, f32 y, f32 sx, f32 sy, u8 layer, CAMERA * cam, u8 flags);

#endif
