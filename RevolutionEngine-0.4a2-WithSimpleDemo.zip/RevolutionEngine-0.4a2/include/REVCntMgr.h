/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_CNTMGR_H
#define REV_CNTMGR_H

//Header files
#include "REVMaterial.h"
#include "REVMesh.h"
#include "REVPhysics.h"

////////////Structures
typedef struct REV_ContentMangager{
MATERIAL * matList;//List of loaded materials
IMGMAP * mapList;//List of loaded image maps
MODEL * modelList;//List of loaded static meshes
BODY * bodyList;//List of loaded bodies (Physics)
}CNTMGR;

////////////functions

/***initCntMgr***/
/*
Description: Creates and initialises the contents manager
Arguments: None
Returns: Nothing
*/
void initCntMgr(void);
/***cleanContent***/
/*
Description: Cleans from memory all the loaded content
Arguments: None
Returns: Nothing
*/
void cleanContent(void);

#endif

