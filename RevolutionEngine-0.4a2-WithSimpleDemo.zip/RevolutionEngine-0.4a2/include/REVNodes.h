/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_NODES_H
#define REV_NODES_H

//Definitions
  //Node Types
#define NT_NODE 	0
#define NT_LIGHT 	1
#define NT_CAMERA	2
#define NT_OBJECT	3

#define NT_PANEL	1
#define NT_TEXT		2
#define NT_BUTTON	3
#define NT_WINDOW	4

//Structures
typedef struct REV_Node
{
	struct REV_Node * next;
	struct REV_Node * child;
	struct REV_Node * parent;
	u8 type, flags;
	Vector pos, spd, asp;//Position, speed and angular speed
	Mtx modMtx;//Position and rotation matrix
	u8 mode;
}NODE;

typedef struct REV_2dNode
{
	struct REV_2dNode * next;
	struct REV_2dNode * child;
	struct REV_2dNode * parent;
	u8 type, flags;
	f32 x, y, ang;
}N2D;

//2D node functions
/*node2d*/
//creates a new 2D blank node
N2D * node2d(u8 flags);

//Sets an existing node back to blank
void initN2D(N2D * node, u8 type, u8 flags);

void attachN2D(N2D * parent, N2D * child);

void delN2D(N2D * node);

#define deattachN2D(a) attachN2D(mainRoot->rootN2D, a)

//3D node functions
NODE * newNode(u8 flags);
void initNode(NODE * node, u8 type, u8 flags);//reset a NODE, unnecessary for new NODEs

void attachNode(NODE * parent, NODE * child);
void delNode(NODE * node);

#define deattachNode(a) attachNode(mainRoot->rootNode, a)

void move(NODE * node, Vector rel, Vector abs);
void rotate(NODE * node, Vector ang);
void rotateByAxis(NODE * node, Vector * axis, f32 angle);
void rotateAroundPoint(NODE * node, Vector * axis, Vector * point, f32 angle);
void setPos(NODE * node, Vector pos);
void setAng(NODE * node, Vector angle);
void setSpeed(NODE * node, Vector linear, Vector angular);

void attach(NODE * parent, NODE * child);
void deattach(NODE * n);

void getAbsMtx(NODE * node, Mtx m);

#endif

