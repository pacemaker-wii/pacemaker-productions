/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_QUAT_H
#define REV_QUAT_H

//External header files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <ogcsys.h>
#include <gccore.h>
#include <math.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <pngu.h>
#include <time.h>
#include <ogc/lwp_watchdog.h>

//Internal functions
void computeW(Quaternion * a);
void quatRotatePoint(Quaternion * q, Vector * src, Vector * dst);
void quatNormalize(Quaternion * q);
void quatCrossProduct(Quaternion * a, Quaternion * b, Quaternion * ab);
void quatVecMult(Quaternion * q, Vector * v, Quaternion * dst);
f32 guVecModule(Vector * v);
f32 guVecSqModule(Vector * v);

#endif
