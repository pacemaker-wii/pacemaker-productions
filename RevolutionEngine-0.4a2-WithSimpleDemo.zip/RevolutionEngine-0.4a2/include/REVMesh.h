/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_MESH_H
#define REV_MESH_H

//Internal header files
#include "REVDefinitions.h"
#include "REVQuat.h"

//Structures
typedef struct REV_Model
{
	u8 type;
	char name[nameSize];
	struct REV_Model * next;
}STMODEL;

typedef struct REV_UVSet
{
	u16 nUVs;
	f32 * uvs;
	u16 * uvList;
}UVSET;

typedef struct REV_StaticMesh
{
	u16 nVertices;
	f32 * vertices;
	u16 * vList;
	u16 nNormals;
	f32 * normals;
	u16 * nList;
	UVSET * uvSets;
	u16 nTris;
	u16 nQuads;
	GXColor * diffuse;
}MESH;

typedef struct REV_StaticModel
{
	u8 type;//static, bones, framed
	u8 flags;
	char name[nameSize];
	struct REV_StaticModel * next;
	u8 nMeshes;
	u8 nUVSets;
	MESH * meshes;
}MODEL;

//Public functions
MODEL * loadRms(const char * fileName);

/***loadRsm***/
/*
Description: Load models in Revolution static model binary format, the best way to load static models
Arguments: the file to be loaded as a model
Returns: Pointer to the model
*/
MODEL * loadRsm(const char * fileName);

/***modelScale***/
/*
Description: Resizes a model
Arguments:
-Pointer to the model you want to resize
-Vector containing the scale factor for each axis
Returns: nothing
*/
void modelScale(MODEL* model, Vector scale);

/***modelScaleUniform***/
/*
Description: Resizes a model by the same scale in both 3 xyz directions
Arguments:
-Pointer to the model you want to resize
-Scale Factor
Returns: nothing
*/
void modelScaleUniform(MODEL* model, f32 scale);
f32 modelGetSize(MODEL * model);

MODEL * loadRmd(const char * filename);

#endif
