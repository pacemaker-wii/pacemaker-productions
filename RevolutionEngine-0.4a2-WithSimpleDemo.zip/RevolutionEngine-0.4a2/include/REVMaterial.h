/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_MATERIAL_H
#define REV_MATERIAL_H

//Material types
#define MT_BASIC	0
#define MT_MASKED	1

typedef struct REV_Tiling_Info
{
	f32 u, v, u0, v0, angle;
}TILEINFO;

typedef struct REV_ImageMap{
	char name[20];
	struct REV_ImageMap * next;
	GXTexObj * map;
	f32 uTile, vTile, uOffset, vOffset, angle;
}IMGMAP;

typedef struct REV_Material{
	char name[20];
	u8 type, flags;
	struct REV_Material * next;
} MATERIAL;

typedef struct REV_BasicMaterial{
	char name[20];
	u8 type, flags;
	struct REV_Material * next;
	GXColor diffuseClr, specularClr;
	f32 specularity;
	u8 difUV, specUV, lUV;
	GXTexObj * diffuseMap, * specularMap, *lightMap;
}BMATERIAL;

typedef struct REV_MaskedMaterial
{
	char name[20];
	u8 type, flags;
	struct REV_Material * next;
	GXTexObj * mask;
	GXTexObj * baseMap, *topMap;
	GXColor baseClr, topClr;
}MMATERIAL;

//Public functions
/***loadPng***/
/*
Description: load a png file into a Texture Object and tells the content manager.
	if the file was alredy loaded, returns a pointer to it instead of loading again.
Arguments: name of the png file to be loaded
Returns: Pointer to the texture Object;
*/
GXTexObj * loadPng(const char * filename);
GXTexObj * pngFor2D(const char * filename);

/***newMat***/
/*
Description: Creates a material using the given map as diffuse map
Arguments: diffuse map
Returns: Pointer to the new material
*/
BMATERIAL * basicMat(GXColor diffuse, GXColor specular);
MATERIAL * newMaskedMat(GXTexObj * base, GXTexObj *top, GXTexObj * mask);

#endif
