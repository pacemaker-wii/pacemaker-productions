/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_LIGHTS_H
#define REV_LIGHTS_H

//Definitions
#define LIGHT_DIR	0
#define LIGHT_POINT	1

//Structures
typedef struct REV_Light
{
	u8 type, flags;
	GXColor clr;
	Vector direction;
	struct REV_Light * next;
}LIGHT;

//Public functions
LIGHT * newLight(Vector direction, GXColor clr, u8 flags);
GXColor getAmbLight();
void setAmbLight(GXColor clr);

//Private functions
void specularLightsClr(Mtx absMtx,f32 specularity, MESH * mesh, u16 vIdx, u16 nIdx, u8 *r,u8 * g,u8 * b,u8 * a, Vector camPos);

void diffuseLightModel(Mtx absMtx, MODEL * model);
void specularLightModel(Mtx absMtx, MODEL * model);

#endif
