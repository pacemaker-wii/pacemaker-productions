/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_OBJECT_H
#define REV_OBJECT_H

//header files
#include "REVMesh.h"
#include "REVMaterial.h"
#include "REVPhysics.h"
#include "REVNodes.h"

//Structures
typedef struct REV_Object
{
	NODE node;//Physical state (Position, speed, etc...)
	u8 flags;
	MODEL * model;//3d model
	void * material;//texture material
	struct REV_Body * body;//Physical properties (bouncyness, weight, etc...)
	GXColor clr;//the base color of the object.
}OBJECT;

typedef struct REV_Object_Tracker
{
	struct REV_Object_Tracker * next;
	OBJECT * target;
}TRACKER;

typedef struct REV_Object_ZTracker
{
	struct REV_Object_ZTracker * next;
	OBJECT * target;
	f32 distance;
}ZTRACKER;

//Public functions
OBJECT * newObj(MODEL * model, void * material, BODY * body, Vector pos, Vector ang, u8 flags);

u8 collide(struct REV_Object * a, struct REV_Object * b);

#endif
