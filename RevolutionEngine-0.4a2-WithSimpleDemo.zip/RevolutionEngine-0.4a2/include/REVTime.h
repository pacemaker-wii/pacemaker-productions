/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_TIME_H
#define REV_TIME_H

//Public functions
//Set the ratio betwen game time speed and real time
void setTimeSpeed(f32 speed);

//Returns the game time elapsed by last frame
f32 gameTime(void);

//Returns the real time elapsed by last frame
f32 frameTime(void);

//Internal Functions
void updtTime();

#endif
