/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_SCREEN_H
#define REV_SCREEN_H

#define TEXTS_SIZE 100

#include "REVNodes.h"

//Structures
typedef struct REV_Ir_Pointer
{
	N2D * node;
	u8 mode, layer;
	f32 angle;
	u16 x, y;
}IRPOINTER;

typedef struct REV_Panel
{
	N2D node;
	u8 layer;
	GXColor clr;
	GXTexObj * img;
	f32 sx, sy;
}PANEL;

typedef struct REV_Text
{
	N2D node;
	u8 layer;
	GXColor clr;
	u8 size;
	char text[TEXTS_SIZE];
}TEXT;

typedef struct REV_Button
{
	N2D node;
	u8 layer;
	GXColor clr;
	GXTexObj * img;
	f32 sx, sy;
	void (*onClick)(u8 pointer, struct REV_Button * btn);
	struct REV_Button * next;
}BUTTON;

typedef struct REV_Window
{
	N2D node;
	u8 layer;
	GXColor clr;
	GXTexObj * img;
	f32 xs, ys, xe, ye, sx, sy;//Offsets and size
}WINDOW;

//definitions
#define OffMode	0
#define OnMode	1

//Public functions
/***newPnl***/
/*
Description: Creates a new Panel onto the screen
Parameters:
-Img: The image to be shown
-x, y: Initial position on the screen
-sx, sy: size of the panel
-layer: Layer number
-flags: behaviour flags
Returns: A pointer to the new panel
*/
void setIrPointer(u8 ID, N2D * node, u8 layer, u8 mode);
void pointerOn(u8 ID);
void pointerOff(u8 ID);
void pointerPos(u8 ID, u16 *x, u16 *y);
PANEL * newPnl(GXTexObj * img, f32 x, f32 y, f32 sx, f32 sy, u8 layer, u8 flags);
TEXT * newText(char * text, f32 x, f32 y, u32 size, u8 layer, u8 flags);
BUTTON * newBtn(GXTexObj * img, f32 x, f32 y, f32 sx, f32 sy, u8 layer, u8 flags);
WINDOW * newWnd(GXTexObj * img, f32 x, f32 y, f32 sx, f32 sy, f32 xs, f32 ys, f32 xe, f32 ye, u8 layer, u8 flags);

void screenshot(const char * filename);

//Internal functions
void init2D(void);
void update2D(void);
void render2d(void);
u32 * convertBufferToRGBA8(u32 * rgbaBuffer, u16 bufferWidth, u16 bufferHeight);

#endif
