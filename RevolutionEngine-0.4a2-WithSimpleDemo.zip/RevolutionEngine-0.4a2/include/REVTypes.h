/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_TYPES_H
#define REV_TYPES_H

//Header files
#include "REVNodes.h"
#include "REVObject.h"
#include "REVViewports.h"
#include "REVScreen.h"
#include "REVLights.h"

//Structures
typedef struct REV_Root
{
	NODE * rootNode;
	N2D * rootN2D;
	BUTTON * fstBtn;
	VIEWPORT * mainViewport;
	LIGHT * fstLight;
}ROOT;

#endif
