/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_PARTICLES_H
#define REV_PARTICLES_H

typedef struct REV_Particle
{
	void * next;
	u8 type, flags;
	Vector pos;
	Vector spd;
	GXColor clr;
	f32 energy;
	f32 size;
}PARTICLE;

typedef struct REV_ParticleSystem
{
	u8 type, flags;
	PARTICLE * list;
	GXColor sClr, eClr;
	f32 sSize, eSize;
	f32 energy;
	Vector Spd;
	f32 variance;
}PARTSYS;

PARTSYS * newPointPS(u8 flags);
PARTSYS * newPlanePS(u8 flags);
void updatePS(PARTSYS * ps);
void renderPS(PARTSYS * ps);

#endif
