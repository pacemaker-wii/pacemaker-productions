/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_DEFS_H
#define REV_DEFS_H

//definitions
#define VisibleF	1
#define AlfaF		2
#define CenterF		4

#define OffF	0
#define OnF		1

#define nameSize 20

#define MT_STATIC		0
#define MT_ANIMATED		1

#define MD5_VERSION		10

//Body types
#define BT_Point	0
#define BT_Sphere	1
#define BT_Box		2

//Usefull or Easy to Use macros
#define nullVector ((Vector){0.0f, 0.0f, 0.0f})
#define vector(a, b, c) ((Vector){a, b, c})

#define rgb(a, b, c) ((GXColor){a, b, c, 255})
#define rgba(a, b, c, d) ((GXColor){a, b, c, d})

//Colors
#define C_WHITE		((GXColor){255, 255, 255, 255})
#define C_BLACK		((GXColor){0, 0, 0, 255})
#define C_RED		((GXColor){255, 0, 0, 255})
#define C_GREEN		((GXColor){0, 255, 0, 255})
#define C_BLUE		((GXColor){0, 0, 255, 255})
#define C_YELLOW	((GXColor){255, 255, 0, 255})
#define C_PURPLE	((GXColor){255, 0, 255, 255})

#endif
