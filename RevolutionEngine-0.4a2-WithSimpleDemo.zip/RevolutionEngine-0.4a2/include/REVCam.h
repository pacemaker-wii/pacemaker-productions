/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_CAMERAS_H
#define REV_CAMERAS_H

#include "REVNodes.h"

//structures
typedef struct REV_Camera
{
	NODE node;
}CAMERA;

//Public functions
/***defaultCam***/
//Returns a pointer to the default Camera
CAMERA * defaultCam();

//Internal functions
void initCams(void);
void updtMtx(CAMERA * cam, Mtx view);
#endif
