/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_QUEUE_H
#define REV_QUEUE_H

typedef struct REV_Element
{
	struct REV_Element * next;
	u8 type, flags;
}ELEMENT;

ELEMENT * newElement();

#endif
