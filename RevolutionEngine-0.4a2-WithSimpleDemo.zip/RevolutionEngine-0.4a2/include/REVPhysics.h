/////////////////////////////////////////////////
//Revolution Engine.
//by Technik
/////////////////////////////////////////////////

#ifndef REV_PHYSICS_H
#define REV_PHYSICS_H

//Internal header files

//structures
typedef struct REV_Body
{
	f32 mass, bouncy, friction;
	u8 type;
}BODY;

typedef struct REV_Sphere_Body
{
	f32 mass, bouncy, friction;
	u8 type;
	f32 radius;
}SBODY;

typedef struct REV_Box_Body
{
	f32 mass, bouncy, friction;
	u8 type;
	f32 width, length, height;
}BBODY;

//Public functions
BODY * pointBd();//Point body
BODY * sphereBd(f32 radius);//Sphere body
BODY * cubeBd(f32 side);//Cube body
BODY * boxBd(f32 width, f32 length, f32 height);//box body

//Internal functions
void updateSpace(void);

#endif
