/*
 *  File:       libwii.cc
 *  Summary:    Functions for Wii console support
 *  Written by: Jeff Johnson
 */

#include <stdio.h>
#include <sys/stat.h>

#include <wiisprite.h>
#include <wiiuse/wpad.h>
#include <fat.h> 

#include "ImageServer.h"
#include "wsp_Console.h"
#include "OnScreenKeyboard.h"
#include "ScrollingMenu.h"
#include "WiiController.h"
#include "Window.h"
#include "MenuCapture.h"

// Stone Soup, crawl_view extern.
#undef MIN
#undef MAX
#include "defines.h"
#include "cio.h"
//#include "libwii.h"	// Included with above includes.



// Global so all objects can access it.
wsp::GameWindow * gwd;
ImageServer isImageServer;
wsp_Console * wspConsole;
OnScreenKeyboard OnScreenKeyboardOb;
WiiController WiiControllerOb;
WiiWindow TextWindow;



// Local Global objects.
static wsp::Sprite BackgroundSprite;
static wsp::Sprite * DCSS_tile_titleSprite;
static wsp::Sprite CursorPointerSprite;
static int nCurrentColor = MSGCOL_WHITE;
static ScrollingMenu CommonStandardMenu;
static ScrollingMenu RareStandardMenu;
static ScrollingMenu ContextMenu;
static MenuCapture ContextMenuCapture;

static const char * CommonStandardMenuItems  [] = {
										"c - butcher",
										"d - drop",
										"e - eat",
										"f - fire",
										"g - pickup",
										"i - inventory",
										"o - explore",
										"p - pray",
										"q - quaff",
										"r - read",
										"s - search",
										"t - shout",
										"v - evoke",
										"z - cast spell",
										"Z - Zap Wand",
										"< - Go Upstairs",
										"> - Go Downstairs",
										"pc - pray/butcher",
										"' - Repeat Command",
										"y - yes",
										"n - no"
									};

static const char * RareStandardMenuItems  [] = {
										"a - abilities",
										"m - skills",
										"w - wield",
										"x - look around",
										"A - Mutations",
										"E - Experience",
										"I - Display Spells",
										"M - Memorize Spell",
										"P - Wear Jewelry",
										"Q - Quiver Item",
										"R - Remove Jewelry",
										"S - Save Game",
										"T - Takeoff Armor",
										"V - Full View",
										"W - Wear Armor",
										"X - Display Map",
										". - Wait",
										"; - Inspect Floor",
										"` - Repeat Command",
										"\x10 - Msg Log",
										"y - up left",
										"u - up right",
										"b - down left",
										"n - down right"
									};

static const char * DefaultContextMenuItems  [] = {
										"y - yes",
										"n - no",
										"q - quit",
										"\x1b - escape",
										"\r - enter",
										"  - space"
										};


/*
	Draw the splash screen  and wait for (A) to be pressed.
*/
void DisplaySplashScreenAndWait (void)
{

	while (1)
	{
		/*
			Check WiiRemote.
		*/
		WiiControllerOb.ScanControllers ();


		/*
			Render visible windows...
		*/
		DCSS_tile_titleSprite->Draw ();

		/*
			Check buttons.
		*/
		if (WPAD_ButtonsHeld (0) & WPAD_BUTTON_A)
		{
			return;
		}

		/*
			Show cursor.
		*/
		if (WiiControllerOb.IsIRDataValid())
		{
			CursorPointerSprite.SetPosition (WiiControllerOb.WiiRemoteData()->ir.x, WiiControllerOb.WiiRemoteData()->ir.y);
			CursorPointerSprite.Draw ();
		}


	#ifndef PRODUCTION
		// printf support
		wspConsole->RenderConsole ();
	#endif

		// Put the back buffer into the screen.
		gwd->Flush();
	}
}



static int FindAvailMemKilos (void)
{
int nKilos = 6 * 1024;
void * p;

	while (nKilos > 0)
	{
		p = malloc (nKilos * 1024);
		if (! p)
		{
			nKilos -= 16;
		}
		else
		{
			free (p);
			return (nKilos);
		}
	}

	return (0);
}



void DrawAndInputForMenu (ScrollingMenu & Menu)
{
	Menu.Draw ();

	if (WPAD_ButtonsDown (0) & WPAD_BUTTON_2)
	{
		int nSelected = Menu.ProcessInput (ScrollingMenu::INPUT_SELECT);
		OnScreenKeyboardOb.ForceKeyPress (nSelected);
	}
	else if (WPAD_ButtonsDown (0) & WPAD_BUTTON_RIGHT)
	{
		Menu.ProcessInput (ScrollingMenu::INPUT_UP);
	}
	else if (WPAD_ButtonsDown (0) & WPAD_BUTTON_LEFT)
	{
		Menu.ProcessInput (ScrollingMenu::INPUT_DOWN);
	}
	else if ((WPAD_ButtonsHeld (0) & WPAD_BUTTON_RIGHT) && !Menu.IsMenuScrolling())
	{
		Menu.ProcessInput (ScrollingMenu::INPUT_UP);
	}
	else if ((WPAD_ButtonsHeld (0) & WPAD_BUTTON_LEFT) && !Menu.IsMenuScrolling())
	{
		Menu.ProcessInput (ScrollingMenu::INPUT_DOWN);
	}
}

/*
	Per Frame Updates.  i.e. Draw the screen.

	Input can be directed at OSK, Popup Menu or normal input (e.g. 'hjkl' movement)
*/
void UpdateFrame (int nFrames)
{
int i;

int nKilos;


	nKilos = FindAvailMemKilos ();

	for (i = 0; i < nFrames; i ++)
	{
		/*
			Check WiiRemote.
		*/
		WiiControllerOb.ScanControllers ();


		/*
			Render visible windows...
		*/
		BackgroundSprite.Draw();
		TextWindow.DebugNumber (nKilos);
		TextWindow.Draw ();
		
		// If pointed at the screen, allow OSK.
		if (WiiControllerOb.IsIRDataValid())
		{
			OnScreenKeyboardOb.Draw (WiiControllerOb.WiiRemoteData()->ir.x, WiiControllerOb.WiiRemoteData()->ir.y);
		}
		// If not pointed at the screen, try context menu.
		else if (CommonStandardMenu.IsMenuEnabled ())
		{
			DrawAndInputForMenu (CommonStandardMenu);
		}
		else if (RareStandardMenu.IsMenuEnabled ())
		{
			DrawAndInputForMenu (RareStandardMenu);
		}
		else if (ContextMenu.IsMenuEnabled ())
		{
			DrawAndInputForMenu (ContextMenu);
		}
		
		/*
			Check buttons and show cursor.
		*/
		// Home to Exit
		if (WPAD_ButtonsHeld (0) & WPAD_BUTTON_HOME)
		{
			exit (0);
		}

		// (B) Space
		if (WPAD_ButtonsDown (0) & WPAD_BUTTON_B)
		{
			OnScreenKeyboardOb.ForceKeyPress (' ');
		}

		// (1) Open/Close Standard Menu
		if (WPAD_ButtonsDown (0) & WPAD_BUTTON_1)
		{
			CommonStandardMenu.ToggleEnableMenu ();
			if (CommonStandardMenu.IsMenuEnabled ())
			{
				RareStandardMenu.EnableMenu (false);
				ContextMenu.EnableMenu (false);
			}
		}

		// (+) Open/Close Standard Menu
		if (WPAD_ButtonsDown (0) & WPAD_BUTTON_PLUS)
		{
			RareStandardMenu.ToggleEnableMenu ();
			if (RareStandardMenu.IsMenuEnabled ())
			{
				CommonStandardMenu.EnableMenu (false);
				ContextMenu.EnableMenu (false);
			}
		}

		// (-) Open/Close Context Menu
		if (WPAD_ButtonsDown (0) & WPAD_BUTTON_MINUS)
		{
			ContextMenu.ToggleEnableMenu ();
			if (ContextMenu.IsMenuEnabled ())
			{
				RareStandardMenu.EnableMenu (false);
				CommonStandardMenu.EnableMenu (false);

				if (ContextMenuCapture.GetNumMenuItems () == 0)
				{
					ContextMenu.SetupMenu (DefaultContextMenuItems, sizeof (DefaultContextMenuItems) / (sizeof (char *)));
				}
				else
				{
					ContextMenu.SetupMenu (ContextMenuCapture.GetCapturedMenu (), ContextMenuCapture.GetNumMenuItems ());
				}
			}
		}


		if (! (CommonStandardMenu.IsMenuEnabled () || RareStandardMenu.IsMenuEnabled () || ContextMenu.IsMenuEnabled ()))
		{
			// (2) is like a SHIFT key
			if (WPAD_ButtonsHeld (0) & WPAD_BUTTON_2)
			{
				// (2) and D-Pad to run.
				if (WPAD_ButtonsDown (0) & WPAD_BUTTON_UP)
				{
					OnScreenKeyboardOb.ForceKeyPress ('H');
				}
				if (WPAD_ButtonsDown (0) & WPAD_BUTTON_DOWN)
				{
					OnScreenKeyboardOb.ForceKeyPress ('L');
				}
				if (WPAD_ButtonsDown (0) & WPAD_BUTTON_LEFT)
				{
					OnScreenKeyboardOb.ForceKeyPress ('J');
				}
				if (WPAD_ButtonsDown (0) & WPAD_BUTTON_RIGHT)
				{
					OnScreenKeyboardOb.ForceKeyPress ('K');
				}
			}
			else
			{
				// D Pad to move.
				if (WPAD_ButtonsDown (0) & WPAD_BUTTON_UP)
				{
					OnScreenKeyboardOb.ForceKeyPress ('h');
				}
				if (WPAD_ButtonsDown (0) & WPAD_BUTTON_DOWN)
				{
					OnScreenKeyboardOb.ForceKeyPress ('l');
				}
				if (WPAD_ButtonsDown (0) & WPAD_BUTTON_LEFT)
				{
					OnScreenKeyboardOb.ForceKeyPress ('j');
				}
				if (WPAD_ButtonsDown (0) & WPAD_BUTTON_RIGHT)
				{
					OnScreenKeyboardOb.ForceKeyPress ('k');
				}
			}
		}
		
		// Are we pointing at the screen?
		if (WiiControllerOb.IsIRDataValid())
		{
			// (A) can push an OSK button.
			if (WPAD_ButtonsDown (0) & WPAD_BUTTON_A)
			{
				OnScreenKeyboardOb.CheckForKeyPress (WiiControllerOb.WiiRemoteData()->ir.x, WiiControllerOb.WiiRemoteData()->ir.y);
			}

			CursorPointerSprite.SetPosition (WiiControllerOb.WiiRemoteData()->ir.x, WiiControllerOb.WiiRemoteData()->ir.y);
			CursorPointerSprite.Draw ();
		}
		else
		{
			// (A) without OSK is repeat command.
			if (WPAD_ButtonsDown (0) & WPAD_BUTTON_A)
			{
				OnScreenKeyboardOb.ForceKeyPress ('`');
			}
		}


	#ifndef PRODUCTION
		// printf support
		wspConsole->RenderConsole ();
	#endif

		// Put the back buffer into the screen.
		gwd->Flush();
	}
}





/*
	malloc Test
*/
static void TestMalloc (void)
{
void * p[128];
int nMegs;

	p[0] = malloc (16);
	cprintf ("First Malloc at: 0x%x\n", p[0]);
	free (p[0]);
	cprintf ("First Malloc Freed\n");

	p[1] = malloc (16);
	cprintf ("Second Malloc at: 0x%x\n", p[1]);
	free (p[1]);

	nMegs = 100;
	while (1)
	{
		p[2] = malloc (nMegs * 1024 * 1024);
		if (! p [2])
		{
			cprintf ("Malloc of %d megs failed...", nMegs);
			nMegs --;
		}
		else
		{
			cprintf ("Malloc of %d megs SUCCEEDED!\n", nMegs);
			free (p [2]);
			break;
		}
	}

}




void PrintMemAvail (void)
{
int nKilos = 6 * 1024;
void * p;

	while (nKilos > 0)
	{
		p = malloc (nKilos * 1024);
		if (! p)
		{
			nKilos -= 16;
		}
		else
		{
			cprintf ("Malloc ~ %d kbytes avail.\n", nKilos);
			free (p);
			return;
		}
	}

	cprintf ("Malloc < 1Kbyte avail.\n");
}




static void TestTextWindow (void)
{
	clrscr ();
	cprintf ("Testing Text Window.\n");
	cprintf ("Very Long line:\n");
	cprintf ("0123456789----------0123456789----------0123456789----------0123456789-1-3-5-7-9\n");
	cprintf ("\\n and \\r R\r N \n");
	cprintf ("Backspace xxx\b\b\b\n");
	

	getch ();
	
	#define PrintColor(x) textcolor(x); cprintf( #x "\n");
	PrintColor (MSGCOL_BLACK);

    PrintColor (MSGCOL_BLUE);
    PrintColor (MSGCOL_GREEN);
    PrintColor (MSGCOL_CYAN);
    PrintColor (MSGCOL_RED);
    PrintColor (MSGCOL_MAGENTA);
    PrintColor (MSGCOL_BROWN);
    PrintColor (MSGCOL_LIGHTGREY);
    PrintColor (MSGCOL_DARKGREY);
    PrintColor (MSGCOL_LIGHTBLUE);
    PrintColor (MSGCOL_LIGHTGREEN);
    PrintColor (MSGCOL_LIGHTCYAN);
    PrintColor (MSGCOL_LIGHTMAGENTA);
    PrintColor (MSGCOL_YELLOW);
    PrintColor (MSGCOL_WHITE);
    PrintColor (MSGCOL_DEFAULT);             // use default colour
    PrintColor (MSGCOL_ALTERNATE);           // use secondary default colour scheme
    PrintColor (MSGCOL_MUTED);               // don't print messages
    PrintColor (MSGCOL_PLAIN);


	getch ();

	for (int i = 0; i < 22; i ++)
	{
		cprintf ("Scrolling Check\n");
	}

	getch ();

	for (int i = 0; i < 220; i ++)
	{
		cprintf ("More Scrolling Check\n");
	}
	

	clrscr ();

    gotoxy_sys(1, 1);
	cprintf ("X is at 1, 1\nNextLineStuff\nXXX");

	for (int n = 4; n < 20; n ++)
	{
		gotoxy_sys(n, n);
		cprintf ("X is at %d, %d", n, n);
	}

    gotoxy_sys(1, 3);
	cprintf ("X is at 1, 3");

	cprintf ("\n");
	cprintf ("More stuff after a new line...Cursor should be here ->");
	
	getch ();

	cprintf ("Done...\n");
}


static void TestPopupMenu (void)
{
char ch;

	clrscr ();
	cprintf ("Testing Context Menu.\n");

#if 0
	CommonStandardMenu.EnableMenu (true);
	cprintf ("Waiting for a key...");
	ch = getch ();
	cprintf ("Got key %c\n", ch);
	CommonStandardMenu.EnableMenu (false);

	RareStandardMenu.EnableMenu (true);
	cprintf ("Waiting for a key...");
	ch = getch ();
	cprintf ("Got key %c\n", ch);
	RareStandardMenu.EnableMenu (false);
#endif

	ContextMenu.EnableMenu (true);
	cprintf ("Waiting for a key...");
	ch = getch ();
	cprintf ("Got key %c\n", ch);
	ContextMenu.EnableMenu (false);

	while (kbhit ())
	{
		ch = getch ();
		cprintf ("Got key %c\n", ch);
	}
}


static void TestContextMenu (void)
{
char ch;

	clrscr ();
	cprintf ("Testing Context Menu.\n");
	cprintf ("x - item a\n");
	cprintf ("b - item b\n");
	cprintf ("c - item c\n");
	cprintf ("d - item d\n");
	cprintf ("e - item e\n");
	cprintf ("f - item f\n");
	cprintf ("g - item g\n");
	cprintf ("h - item h\n");
	cprintf ("i - item i\n");
	cprintf ("j - item j\n");
	
	
	ContextMenu.ToggleEnableMenu ();
	if (ContextMenu.IsMenuEnabled ())
	{
		cprintf ("Using Captured Context Menu\n");
		ContextMenu.SetupMenu (ContextMenuCapture.GetCapturedMenu (), ContextMenuCapture.GetNumMenuItems ());
	}
	
	
	cprintf ("Waiting for a key...");
	ch = getch ();
	cprintf ("Got key %c\n", ch);
}

/*
	Initialize Wii specific stuff.
	Required to be done first before any File I/O or Screen I/O.
*/
void WiiInitialize (void)
{
	/*
		Global Game Objects
	*/
	gwd = new wsp::GameWindow ();
	gwd->InitVideo();
	gwd->SetBackground((GXColor){ 0, 0, 128, 255 });
	gwd->Flush();

	// Object to hold all of the images
	//  so they won't be loaded into memory twice.
	if (! isImageServer.Initialize ())
	{
		gwd->SetBackground((GXColor){ 255, 0, 0, 255 });
		gwd->Flush();
		// Error initializing ImageServer....program will now hang.
		while (1);
	}

	// Set background to black after initializations have succeeded.
	gwd->SetBackground((GXColor){ 255, 255, 255, 255 });

#ifndef PRODUCTION
	wspConsole = new wsp_Console();
	wspConsole->InitConsole ();
#endif

	// File I/O Initialization.
	if (!fatInitDefault())
	{
	    printf("\n\nfatInitDefault failure\n");
	    cprintf("fatInitDefault failure\n");
	}
	
	chdir ("/StoneSoup");


	WiiControllerOb.Initialize (wsp::GameWindow::GetWidth(), wsp::GameWindow::GetHeight());

	BackgroundSprite.SetImage (isImageServer.GetBackgroundImage ());
	DCSS_tile_titleSprite = new wsp::Sprite();
	DCSS_tile_titleSprite->SetImage (isImageServer.GetDCSS_tile_titleImage ());

	CursorPointerSprite.SetImage (isImageServer.GetHandPointerImage ());
	CursorPointerSprite.SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);
	CursorPointerSprite.SetTransparency (200);


	TextWindow.Initialize (OVERSCAN_X_OFFSET, OVERSCAN_Y_OFFSET, USABLE_ROWS, USABLE_COLUMNS);
	OnScreenKeyboardOb.Initialize ();
	CommonStandardMenu.Initialize ();
	RareStandardMenu.Initialize ();
	ContextMenu.Initialize ();

	CommonStandardMenu.SetupMenu (CommonStandardMenuItems, sizeof (CommonStandardMenuItems) / (sizeof (char *)));
	RareStandardMenu.SetupMenu (RareStandardMenuItems, sizeof (RareStandardMenuItems) / (sizeof (char *)));
	ContextMenu.SetupMenu (DefaultContextMenuItems, sizeof (DefaultContextMenuItems) / (sizeof (char *)));

	cprintf ("Wii Specific Initialization Complete...\n");
	PrintMemAvail();

	UpdateFrame (1);

#ifndef SAFE_FOR_DOLPHIN_EMULATOR
	DisplaySplashScreenAndWait ();
#endif

	// Free up memory from the title splash screen.
	delete (DCSS_tile_titleSprite);
	isImageServer.DestroyDCSS_tile_titleImage ();


	//!!!!TestTextWindow ();
	//!!!!TestPopupMenu ();
	//!!!!TestContextMenu ();
	//!!!!TestMalloc ();

#if 0
	cprintf ("Hit a Key to continue...");
	PrintMemAvail();
	getch ();
	cprintf ("o.k. continuing.\n");
#endif
}






/*****************************************************************************
*****************************************************************************

	The following functions are the defined interface to the outside world.

*****************************************************************************
******************************************************************************/




/*******************************

	Screen Routines.

********************************/


/*
	Clear screen e.g. "ESC[2J"
*/
int clrscr()
{
	ContextMenuCapture.Start ();
	TextWindow.Clear ();
	UpdateFrame (1);
    return (0);
}


/*
	Put text to the screen at the XY coodinates.
	The coordinates describe a box.
	buf is an array of {'_char' , '_color' } pairs.
	_char and _color are data type 'char'
*/
void puttext(int x1, int y1, int x2, int y2, const screen_buffer_t *buf)
{

    for (int y = y1; y <= y2; ++y)
    {
        for (int x = x1; x <= x2; ++x)
        {
			TextWindow.Cursor (x, y);
			TextWindow.PutChar(buf [1], buf [0]);
            buf += 2;
        }
    }
}



/*
	A printf style function that sends
	its output to the cursor location
	with the current color.
	
	It should handle \t, \n and \r properly.
*/
void cprintf(const char *format, ...)
{
    va_list argp;
    char buffer[4096]; // one could hope it's enough

    va_start( argp, format );

    vsprintf(buffer, format, argp);
	ContextMenuCapture.TryAdd (buffer);
    TextWindow.PutStr (nCurrentColor, buffer);

    va_end(argp);
}



/*
	Return number of rows that the terminal has.
*/
int get_number_of_lines(void)
{
    return (USABLE_ROWS);
}

/*
	Return number of columns that the terminal has.
*/
int get_number_of_cols(void)
{
    return (USABLE_COLUMNS);
}

void textattr(int col)
{
	textcolor (col);
}

/*
	Save the text color for later use...
*/
void textcolor(int col)
{
	nCurrentColor = col;
}


/*
	Unused...
*/
void textbackground(int col)
{
}


/*
	Make sure everything is flushed to the screen.
*/
void update_screen(void)
{
	UpdateFrame (1);
}

/*
	Clear from current cursor to end of line.
*/
void clear_to_end_of_line(void)
{
	TextWindow.ClearToEndOfLine ();
}


/*
	Clear from current cursor to end of screen.
*/
void clear_to_end_of_screen(void)
{
	TextWindow.ClearToEndOfScreen ();
}


/*
	Put a character and a color at the current cursor location.
*/
void put_colour_ch(int colour, unsigned ch)
{
	TextWindow.PutChar (colour, ch);
}

/*
	Put a character with the current color at the current cursor location.
*/
int putch(unsigned char chr)
{
	TextWindow.PutChar (nCurrentColor, chr);
    return (chr);
}

/*
	Move Cursor to specified location.
	(1,1) is upper left.
*/
void gotoxy_sys(int x, int y)
{
	TextWindow.Cursor (x - 1, y - 1);
}

/*
	Return X (col) location of cursor
	1 is the first column.
*/
int wherex()
{
    return (TextWindow.GetCursorCol() + 1);
}


/*
	Return Y (row) location of cursor 
	1 is the first row.
*/
int wherey()
{
    return (TextWindow.GetCursorRow() + 1);
}


/*******************************

	Message Window Routines.

********************************/

/*
	Put a message ('s') at on the 'which_line' of the message window, with the appropriate 'color'.
	Force a 'newline' if requested.
	
	The message window is offset from the main text window by 'crawl_view.msgp.x' and 'crawl_view.msgp.y'
*/
void message_out(int which_line, int color, const char *s, int firstcol, bool newline)
{
	TextWindow.Cursor (firstcol + crawl_view.msgp.x, which_line + crawl_view.msgp.y);
	TextWindow.PutStr(color, s);
	if (newline)
	{
		TextWindow.Cursor (firstcol + crawl_view.msgp.x, which_line + crawl_view.msgp.y + 1);
	}	
	
	UpdateFrame (1);
}

/*
	Clear just the message window part of the display.
*/
void clear_message_window()
{
int x, y;

	for (x = crawl_view.msgp.x; x <  crawl_view.msgp.x + crawl_view.msgsz.x; x ++)
	{
		for (y = crawl_view.msgp.y; y <  crawl_view.msgp.y + crawl_view.msgsz.y; y ++)
		{
			TextWindow.ClearXY (x, y);
		}
	}
	
	UpdateFrame (1);
}




/*******************************

	Keyboard / Mouse Routines.

********************************/

/*
	Returns true if there are any keys left in the keyboard buffer.
*/
int kbhit(void)
{
    return (OnScreenKeyboardOb.bKeyInQueue ());
}

int m_getch(void)
{
	// This ignores the mouse.
    return (getch ());
}

int getch (void)
{
	ContextMenuCapture.End ();


#ifdef SAFE_FOR_DOLPHIN_EMULATOR
	UpdateFrame (1);
	return (' ');
#endif


	while (! OnScreenKeyboardOb.bKeyInQueue ())
	{
		UpdateFrame (1);
	}
	
    return (OnScreenKeyboardOb.GetChar ());
}


/*
	This is the '_' cursor for text entry.
	Set if it is visable or not.
*/
void set_cursor_enabled(bool enabled)
{
    TextWindow.SetCursorEnable (enabled);
}

/*
	This is the '_' cursor for text entry.
	Get if it is visable or not.
*/
bool is_cursor_enabled()
{
    return (TextWindow.GetCursorEnable ());
}


/*
	I think this sets if the mouse is visable.
*/
void set_mouse_enabled(bool enabled)
{
	//!!!!
}


/*******************************

	Misc Routines.

********************************/


void init_libwii(void)
{
	// Nothing yet.
	// This is called rather late in the initialization to be useful.
}

void deinit_libwii(void)
{
	// Nothing yet.
}

/*
	Delay in ms.
	
	Each Frame is 16ms (1/60) in the US.
*/
void delay( unsigned long time )
{
	UpdateFrame ((time / 16) + 1);
}




/* 
	Convert value to string 
	Taken from libunix.cc
*/
int itoa(int value, char *strptr, int radix)
{
    unsigned int bitmask = 32768;
    int ctr = 0;
    int startflag = 0;

    if (radix == 10)
    {
        sprintf(strptr, "%i", value);
    }
    if (radix == 2)             /* int to "binary string" */
    {
        while (bitmask)
        {
            if (value & bitmask)
            {
                startflag = 1;
                sprintf(strptr + ctr, "1");
            }
            else
            {
                if (startflag)
                    sprintf(strptr + ctr, "0");
            }

            bitmask = bitmask >> 1;
            if (startflag)
                ctr++;
        }

        if (!startflag)         /* Special case if value == 0 */
            sprintf((strptr + ctr++), "0");

        strptr[ctr] = (char) NULL;
    }
    return (1);                /* Me? Fail? Nah. */
}




/*
	Access doesn't exist in the DevKitPro libraries for the Wii.
	Here's a guess at a replacement.
	

	Three flavors of use from sqlite3.

	* int sqlite3UnixFileExists(const char *zFilename){   return access(zFilename, 0)==0;  }
    * if( access(azDirs[i], 07) ) continue;
	* access(zBuf,0)==0 
	
	
	__amode (aka how) can be:
		#define	F_OK	0 - Flag meaning test for existence of the file. 
		#define	R_OK	4 - Flag meaning test for read permission. 
		#define	W_OK	2 - Flag meaning test for write permission. 
		#define	X_OK	1 - Flag meaning test for execute/search permission. 


	return values are:
		The return value is 0 if the access is permitted, and -1 otherwise.

*/
extern "C" int access (const char *__path, int __amode )
{
struct stat  sbuf;
int nRetVal;

	nRetVal = stat (__path, & sbuf);

	if (nRetVal == 0)
	{
		return (0);
	}
	else
	{
		return (-1);
	}
	
}
