/*
 *  File:       libwii.h
 *  Written by: Jeff Johnson
 *
 *  Copied from libunix.h
 */

#ifndef LIBWII_H
#define LIBWII_H


void WiiInitialize (void);
void UpdateFrame (int nFrames);
int itoa(int value, char *strptr, int radix);

void PrintMemAvail (void);

/*
	Functions needed for ASCII and Tiles.
*/
void init_libwii(void);
void deinit_libwii(void);




/*
	Functions needed for ASCII only.
*/
#ifndef USE_TILE
typedef unsigned short screen_buffer_t;

void message_out(int mline, int colour, const char *str, int firstcol = 0,
                 bool newline = true);
void clear_message_window();

int get_number_of_lines();
int get_number_of_cols();

int clrscr(void);
void cprintf(const char *format,...);
void gotoxy_sys(int x, int y);
int kbhit(void);
int putch(unsigned char chr);
void put_colour_ch(int colour, unsigned ch);
int wherex(void);
int wherey(void);
void puttext(int x1, int y1, int x2, int y2, const screen_buffer_t *);
void update_screen(void);
void clear_to_end_of_line(void);
void clear_to_end_of_screen(void);

void delay(unsigned long time);
void textbackground(int bg);
void textcolor(int col);
void textattr(int col);

void set_cursor_enabled(bool enabled);
bool is_cursor_enabled();
inline void enable_smart_cursor(bool) { }
inline bool is_smart_cursor_enabled() { return (false); }

void set_mouse_enabled(bool enabled);

#ifndef _LIBWII_IMPLEMENTATION
/* Some stuff from curses, to remove compiling warnings.. */
extern "C"
{
    int getch(void);	//!!!! This doesn't seem right.
}
#endif	//_LIBWII_IMPLEMENTATION


#endif	// USE_TILE
#endif	// LIBWII_H
