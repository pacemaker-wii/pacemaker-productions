
// ImageServer to share image data.

/*
	To add a new image:
	
	1.  Add a DefineImage() MACRO in the ImageServer class.
	2.  Add DoImageLoadAll to Initialize() function.
	3.  Add appropriate include file.

*/

#define DefineImage(name) private: wsp::Image * p ##name## Image; \
		public:  inline wsp::Image * Get ##name## Image (void) { return p ##name## Image; } \
		public:  inline void Destroy ##name## Image (void) { p ##name## Image -> DestroyImage (); }


class ImageServer
{
private:

public:
	ImageServer ();
	~ImageServer ();

	bool Initialize (void);
	char szLastError [128];
	int nLastError;


	DefineImage(Background);

	DefineImage(CourierNewFont16White);
	DefineImage(CourierNewFont16Yellow);
	DefineImage(CourierNewFont16LightMagenta);
	DefineImage(CourierNewFont16LightCyan);
	DefineImage(CourierNewFont16LightGreen);
	DefineImage(CourierNewFont16LightBlue);
	DefineImage(CourierNewFont16Brown);
	DefineImage(CourierNewFont16DarkGrey);
	DefineImage(CourierNewFont16LightGrey);
	DefineImage(CourierNewFont16Magenta);
	DefineImage(CourierNewFont16Red);
	DefineImage(CourierNewFont16Cyan);
	DefineImage(CourierNewFont16Green);
	DefineImage(CourierNewFont16Blue);
	DefineImage(CourierNewFont16Black);

	DefineImage(CalcFont32);
	DefineImage(GaramondFont32);
	DefineImage(HandPointer);
	DefineImage(OnScreenKey);
	DefineImage(BlueDot);
	DefineImage(DCSS_tile_title);
	DefineImage(MenuBox);
};


extern ImageServer isImageServer;
