
// ImageServer to share image data.

#include <wiisprite.h>
#include "ImageServer.h"


#include "Sprites/Background.sprite.h"
#include "Sprites/CourierNewFont16White.sprite.h"
#include "Sprites/CourierNewFont16Yellow.sprite.h"
#include "Sprites/CourierNewFont16LightMagenta.sprite.h"
#include "Sprites/CourierNewFont16LightCyan.sprite.h"
#include "Sprites/CourierNewFont16LightGreen.sprite.h"
#include "Sprites/CourierNewFont16LightBlue.sprite.h"
#include "Sprites/CourierNewFont16Brown.sprite.h"
#include "Sprites/CourierNewFont16DarkGrey.sprite.h"
#include "Sprites/CourierNewFont16LightGrey.sprite.h"
#include "Sprites/CourierNewFont16Magenta.sprite.h"
#include "Sprites/CourierNewFont16Red.sprite.h"
#include "Sprites/CourierNewFont16Cyan.sprite.h"
#include "Sprites/CourierNewFont16Green.sprite.h"
#include "Sprites/CourierNewFont16Blue.sprite.h"
#include "Sprites/CourierNewFont16Black.sprite.h"
#include "Sprites/CalcFont32.sprite.h"
#include "Sprites/GaramondFont32.sprite.h"
#include "Sprites/HandPointer.sprite.h"
#include "Sprites/OnScreenKey.sprite.h"
#include "Sprites/BlueDot.sprite.h"
#include "Sprites/DCSS_tile_title.sprite.h"
#include "Sprites/MenuBox.sprite.h"



#define DoImageLoadAll(image_var) \
	p ## image_var ## Image = new wsp::Image (); \
	iStatus = p ## image_var ## Image ->LoadImage(image_var); \
	if (iStatus != wsp::IMG_LOAD_ERROR_NONE) \
	{ \
		sprintf (szLastError, "\n\n Image Load Error %s = (%d)\n", #image_var, iStatus); \
		nLastError = iStatus; \
		return (false); \
	}

ImageServer::ImageServer ()
{
}


ImageServer::~ImageServer ()
{
}


bool ImageServer::Initialize (void)
{
wsp::IMG_LOAD_ERROR iStatus;

	szLastError [0] = 0;
	nLastError = 0;

	DoImageLoadAll (Background);

	DoImageLoadAll (CourierNewFont16White);
	DoImageLoadAll (CourierNewFont16Yellow);
	DoImageLoadAll (CourierNewFont16LightMagenta);
	DoImageLoadAll (CourierNewFont16LightCyan);
	DoImageLoadAll (CourierNewFont16LightGreen);
	DoImageLoadAll (CourierNewFont16LightBlue);
	DoImageLoadAll (CourierNewFont16Brown);
	DoImageLoadAll (CourierNewFont16DarkGrey);
	DoImageLoadAll (CourierNewFont16LightGrey);
	DoImageLoadAll (CourierNewFont16Magenta);
	DoImageLoadAll (CourierNewFont16Red);
	DoImageLoadAll (CourierNewFont16Cyan);
	DoImageLoadAll (CourierNewFont16Green);
	DoImageLoadAll (CourierNewFont16Blue);
	DoImageLoadAll (CourierNewFont16Black);
	
	DoImageLoadAll (CalcFont32);
	DoImageLoadAll (GaramondFont32);
	DoImageLoadAll (HandPointer);
	DoImageLoadAll (OnScreenKey);
	DoImageLoadAll (BlueDot);
	DoImageLoadAll (DCSS_tile_title);
	DoImageLoadAll (MenuBox);

	return (true);
}

