/*
 *  File:       monspeak.h
 *  Summary:    Functions to handle speaking monsters
 *
 *  Modified for Crawl Reference by $Author: j-p-e-g $ on $Date: 2008-03-08 05:44:09 -0500 (Sat, 08 Mar 2008) $
 *
 *  Change History (most recent first):
 *
 *      <1>    01/09/00        BWR     Created
 */

#ifndef MONSPEAK_H
#define MONSPEAK_H

#include "externs.h"

bool mons_speaks(const monsters *monster);

#endif
