// BibPointFP.h: interface for the BibPointFP class.
//	This is the floating point version
//
//////////////////////////////////////////////////////////////////////

#pragma once

class BibPointFP
{
private:


public:
	BibPointFP (float x = 0, float y = 0, float z = 0);
	virtual ~BibPointFP();

	float x, y, z;


	void SetSize (float x, float y);
	void SetSize (float x, float y, float z);

	bool operator== (BibPointFP &other);

	// Vector operations.
	BibPointFP operator+ (BibPointFP &other);
	BibPointFP operator+ (BibPointFP other);
	BibPointFP operator- (BibPointFP &other);
	BibPointFP operator+ (float fScalar);
	BibPointFP operator- (float fScalar);
	BibPointFP operator/ (float nDenominator);
	BibPointFP operator* (float fScalar);
	float Dot (BibPointFP & other);
	float Magnitude (void);
	void Normalize (void);

	float DistanceSquared (BibPointFP & other);
	float Distance (BibPointFP & other);

};
