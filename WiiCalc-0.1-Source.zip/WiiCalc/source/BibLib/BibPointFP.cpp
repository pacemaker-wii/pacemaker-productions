// BibPointFP.cpp: implementation of the BibPointFP class.
//
//////////////////////////////////////////////////////////////////////

#include <math.h>

#include "BibPointFP.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

BibPointFP::BibPointFP(float inx, float iny, float inz)
{
	x = inx;
	y = iny;
	z = inz;
}


BibPointFP::~BibPointFP()
{

}



void BibPointFP::SetSize (float inx, float iny)
{
	x = inx;
	y = iny;
}

void BibPointFP::SetSize (float inx, float iny, float inz)
{
	x = inx;
	y = iny;
	z = inz;
}

bool BibPointFP::operator== (BibPointFP &other)
{
	return  (x == other.x) &&
			(y == other.y) &&
			(z == other.z);
}


BibPointFP BibPointFP::operator+ (BibPointFP &other)
{
	return BibPointFP (x + other . x, y + other . y, z + other . z);
}

BibPointFP BibPointFP::operator+ (BibPointFP other)
{
	return BibPointFP (x + other . x, y + other . y, z + other . z);
}


BibPointFP BibPointFP::operator- (BibPointFP &other)
{
	return BibPointFP (x - other . x, y - other . y, z - other . z);
}


BibPointFP BibPointFP::operator+ (float fScalar)
{
	return BibPointFP (x + fScalar, y + fScalar, z + fScalar);
}

BibPointFP BibPointFP::operator- (float fScalar)
{
	return BibPointFP (x - fScalar, y - fScalar, z - fScalar);
}


BibPointFP BibPointFP::operator/ (float fDenominator)
{
	return BibPointFP (x / fDenominator, y / fDenominator, z / fDenominator);
}


BibPointFP BibPointFP::operator* (float fScalar)
{
	return BibPointFP (x * fScalar, y * fScalar, z * fScalar);
}

float BibPointFP::Dot (BibPointFP & other)
{

    return (x*other.x + y*other.y + z*other.z);
}


float BibPointFP::Magnitude (void)
{
float fLen;

	fLen = (float) sqrt (x*x + y*y + z*z);
	return (fLen);
}

void BibPointFP::Normalize (void)
{
float fLen;

	fLen = Magnitude ();
	x = x / fLen;
	y = y / fLen;
	z = z / fLen;

//	ASSERT (Magnitude() > .99);
//	ASSERT (Magnitude() < 1.01);
}


float BibPointFP::DistanceSquared (BibPointFP & other)
{
	return ((other.x - x) * (other.x - x) + 
		    (other.y - y) * (other.y - y) + 
			(other.z - z) * (other.z - z));
}

float BibPointFP::Distance (BibPointFP & other)
{
	return (float) sqrt (DistanceSquared (other));
}

