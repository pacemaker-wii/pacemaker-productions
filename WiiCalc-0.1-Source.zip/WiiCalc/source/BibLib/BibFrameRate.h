/*

Frame Rate Independent Movement 

*/

#ifndef _BIBFRAMERATE_H
#define _BIBFRAMERATE_H

class BibFrameRate
{
private:

	float	targetfps;				// Units: Frames per Second
	long long llLastCurrentTicks;	// Units: Ticks
	long long llCurrentTicks;		// Units: Ticks
	long long llFlushLastTicks;		// Units: Ticks

	
	
public:
	float	fps;					// Units: Frames per Second
	float	fMinFPS;				// Units: Frames per Second
	float	fspeedfactor;			// Units: Frames (or usually fractions of frames)
	float	fFrameTimeDelta;		// Units: Seconds

	void	Init(float tfps);
	void	ReInit (void) { Init (targetfps); }	// Use when pausing, when delta time calculations won't be accurate.
	void	SetSpeedFactor();
	
	void	MeasPreFlush (void);
	void	MeasPostFlush (void);
	unsigned int GetFlushMicroSecs (void);
};

#endif
