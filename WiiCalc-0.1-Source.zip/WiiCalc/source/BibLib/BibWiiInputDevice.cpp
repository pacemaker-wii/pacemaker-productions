/*
	BibInputDevice - i.e. Wii Remote or GameCube Controller

*/

#include <string.h>
#include <string>
#include "BibWiiInputDevice.h"


//#define WII_INPUT_DEVICE_DEBUG_MESSAGES

#ifdef GCUBE_EMU
bool bEmuForceButton = false;
#endif


BibWiiInputDevice::BibWiiInputDevice ()
{
}

void BibWiiInputDevice::Initialize (int nWidth, int nHeight)
{
	nCurActionSet = 0;
	nNumActions = 0;

	for (int i = 0; i < ACTION_MAP_SIZE; i ++)
	{
		for (int j = 0; j < MAX_ACTION_SETS; j ++)
		{
			ActionMaps [j] [i].ButtonAction = 0;
			ActionMaps [j] [i].eController = CTRL_NONE;
		}
	}

#ifndef GCUBE_EMU
	// Wii Remote Initialization
	WPAD_Init();
	WPAD_SetDataFormat(WPAD_CHAN_ALL, WPAD_FMT_BTNS_ACC_IR);
	WPAD_SetVRes(WPAD_CHAN_ALL, nWidth, nHeight);
#endif
	// GameCube Controller Initialization
	PAD_Init ();
}

BibWiiInputDevice::~BibWiiInputDevice ()
{
}


void BibWiiInputDevice::ControlMotor (eControllerTypes eController, int pad, bool bIsOn)
{
#ifndef GCUBE_EMU
	if((pad<WPAD_CHAN_0) || (pad>WPAD_MAX_WIIMOTES))
		return;
	
	if (eController == CTRL_WII_REMOTE)
		WPAD_Rumble(pad, bIsOn);
	else if (eController == CTRL_GAMECUBE)
		PAD_ControlMotor(pad, bIsOn ? PAD_MOTOR_RUMBLE : PAD_MOTOR_STOP);
#endif
}


int BibWiiInputDevice::DefineAction (SingleAction da [MAX_ACTION_SETS])
{
int i;

	if ((nNumActions < 0) || (nNumActions >= ACTION_MAP_SIZE))
		return (-1);

	for (i = 0; i < MAX_ACTION_SETS; i ++)
	{
		ActionMaps [i] [nNumActions] . ButtonAction = da [i].ButtonAction;
		ActionMaps [i] [nNumActions] . eController = da [i].eController;
	}
	
	nNumActions ++;
	
	return (nNumActions - 1);
}


#ifdef WII_INPUT_DEVICE_DEBUG_MESSAGES
char szWiiInputDeviceMsg2 [128];
char szWiiInputDeviceMsg4 [128];
#endif

void BibWiiInputDevice::ScanInputDevice (void)
{
	PAD_ScanPads ();

#ifndef GCUBE_EMU
	
	WPAD_ReadPending(WPAD_CHAN_ALL, NULL);



#define MY_PAD 0
#ifdef WII_INPUT_DEVICE_DEBUG_MESSAGES
int res;
u32 type;
WPADData *wd;


	
	res = WPAD_Probe(MY_PAD, &type);
	// Find out general status.
	switch(res)
	{
		case WPAD_ERR_NO_CONTROLLER:
			sprintf(szWiiInputDeviceMsg2, "  Wiimote not connected\n");
			return;
		break;
		case WPAD_ERR_NOT_READY:
			sprintf(szWiiInputDeviceMsg2, "  Wiimote not ready\n");
			return;
		break;
		case WPAD_ERR_NONE:
			sprintf(szWiiInputDeviceMsg2, "  Wiimote ready\n");
		break;
		default:
			sprintf(szWiiInputDeviceMsg2, "  Unknown Wimote state %d\n",res);
			return;
		break;
 	}


	// Get Detailed readings
	if(res == WPAD_ERR_NONE)
	{
		wd = WPAD_Data(MY_PAD);
			
		if(wd->ir.valid)
		{
			sprintf(szWiiInputDeviceMsg2, "  Cursor: %.02f,%.02f @ %.02f deg, Dist %.02fm",wd->ir.x, wd->ir.y, wd->ir.angle, wd->ir.z);
		}
		else
		{
			sprintf(szWiiInputDeviceMsg2, "  No Cursor\n");
		}
		
		sprintf(szWiiInputDeviceMsg4, "  Accel: XYZ: %3d,%3d,%3d  Pitch: %.02f  Roll:  %.02f, Yaw: %.02f deg", wd->accel.x,wd->accel.y,wd->accel.z, wd->orient.pitch, wd->orient.roll, wd->orient.yaw);
	}
#endif
#endif
}

int BibWiiInputDevice::ActionDown (int nPadChan, int nActionNum)
{
	if ((nActionNum >=0) && (nActionNum < ACTION_MAP_SIZE))
	{
		switch (ActionMaps [nCurActionSet] [nActionNum] . eController)
		{
			case CTRL_WII_REMOTE:
			case CTRL_EXT_NUNCHUK:
			case CTRL_EXT_CLASSIC:
#ifdef GCUBE_EMU
				extern bool bEmuForceButton;
				return (bEmuForceButton);
#else
				return ((ActionMaps [nCurActionSet] [nActionNum] . ButtonAction & WPAD_ButtonsDown (nPadChan)) == ActionMaps [nCurActionSet] [nActionNum] . ButtonAction);
#endif
			break;
			
			case CTRL_GAMECUBE:
#ifdef GCUBE_EMU
				extern bool bEmuForceButton;
				return (bEmuForceButton);
#else
				return ((ActionMaps [nCurActionSet] [nActionNum] . ButtonAction & PAD_ButtonsDown (nPadChan)) == ActionMaps [nCurActionSet] [nActionNum] . ButtonAction);
#endif
			break;
			
			default:
				return (0);
			break;
		}
	}
	return (0);
}

int BibWiiInputDevice::ActionHeld (int nPadChan, int nActionNum)
{
	if ((nActionNum >=0) && (nActionNum < ACTION_MAP_SIZE))
	{
		switch (ActionMaps [nCurActionSet] [nActionNum] . eController)
		{
			case CTRL_WII_REMOTE:
			case CTRL_EXT_NUNCHUK:
			case CTRL_EXT_CLASSIC:
#ifdef GCUBE_EMU
				extern bool bEmuForceButton;
				return (bEmuForceButton);
#else
				return ((ActionMaps [nCurActionSet] [nActionNum] . ButtonAction & WPAD_ButtonsHeld (nPadChan)) == ActionMaps [nCurActionSet] [nActionNum] . ButtonAction);
#endif
			break;
			
			case CTRL_GAMECUBE:
#ifdef GCUBE_EMU
				extern bool bEmuForceButton;
				return (bEmuForceButton);
#else
				return ((ActionMaps [nCurActionSet] [nActionNum] . ButtonAction & PAD_ButtonsHeld (nPadChan)) == ActionMaps [nCurActionSet] [nActionNum] . ButtonAction);
#endif
			break;
			
			default:
				return (0);
			break;
		}
	}

	return (0);
}

int BibWiiInputDevice::ActionUp (int nPadChan, int nActionNum)
{
	if ((nActionNum >=0) && (nActionNum < ACTION_MAP_SIZE))
	{
		switch (ActionMaps [nCurActionSet] [nActionNum] . eController)
		{
			case CTRL_WII_REMOTE:
			case CTRL_EXT_NUNCHUK:
			case CTRL_EXT_CLASSIC:
#ifdef GCUBE_EMU
				extern bool bEmuForceButton;
				return (bEmuForceButton);
#else
				return ((ActionMaps [nCurActionSet] [nActionNum] . ButtonAction & WPAD_ButtonsUp (nPadChan)) == ActionMaps [nCurActionSet] [nActionNum] . ButtonAction);
#endif
			break;
			
			case CTRL_GAMECUBE:
#ifdef GCUBE_EMU
				extern bool bEmuForceButton;
				return (bEmuForceButton);
#else
				return ((ActionMaps [nCurActionSet] [nActionNum] . ButtonAction & PAD_ButtonsUp (nPadChan)) == ActionMaps [nCurActionSet] [nActionNum] . ButtonAction);
#endif
			break;
			
			default:
				return (0);
			break;
		}
	}

	return (0);
}


bool BibWiiInputDevice::IsPresent (eControllerTypes eController, int nPadChan)
{
#ifdef GCUBE_EMU
	if (nPadChan == 0)
		return (true);
#else
int res;
u32 type;
PADStatus PadStatus[PAD_CHANMAX];

	if ((nPadChan < 0) || (nPadChan > 3))
		return (false);

	switch (eController)
	{
		case CTRL_WII_REMOTE:
			res = WPAD_Probe(nPadChan, &type);

			// Did we find this Wii Remote?
			if (res == WPAD_ERR_NONE)
				return (true);
			else
				return (false);
		break;
		
		case CTRL_EXT_NUNCHUK:
			res = WPAD_Probe(nPadChan, &type);

			// Did we find this Wii Remote?
			if (res != WPAD_ERR_NONE)
				return (false);

			// What is attached to the Wii remote?
			if (type == EXP_NUNCHUK)
				return (true);
			else
				return (false);
		break;
		
		case CTRL_EXT_CLASSIC:
			res = WPAD_Probe(nPadChan, &type);

			// Did we find this Wii Remote?
			if (res != WPAD_ERR_NONE)
				return (false);

			// What is attached to the Wii remote?
			if (type == EXP_CLASSIC)
				return (true);
			else
				return (false);
		break;
		
		case CTRL_GUITAR_HERO_3:
			res = WPAD_Probe(nPadChan, &type);

			// Did we find this Wii Remote?
			if (res != WPAD_ERR_NONE)
				return (false);

			// What is attached to the Wii remote?
			if (type == EXP_GUITAR_HERO_3)
				return (true);
			else
				return (false);
		break;
		
		case CTRL_GAMECUBE:
			PAD_Read(&PadStatus[0]);
			
			// Any errors reading the pad?
			if (PadStatus[nPadChan].err == PAD_ERR_NONE)
				return (true);
			else
				return (false);
		break;
		
		default:
			return (false);
		break;
	}
#endif
	
	return (false);
}

void BibWiiInputDevice::SetCurActionSet (int nActionSet)
{
	if ((nActionSet >=0) && (nActionSet < ACTION_MAP_SIZE))
	{
		nCurActionSet = nActionSet;
	}
}


int BibWiiInputDevice::GC_StickX (int nPad)
{
	if((nPad<PAD_CHAN0) || (nPad>PAD_CHAN3))
		return 0;
		
	return PAD_StickX(nPad);
}

int BibWiiInputDevice::GC_StickY (int nPad)
{
	if((nPad<PAD_CHAN0) || (nPad>PAD_CHAN3))
		return 0;
		
	return PAD_StickY(nPad);
}


bool BibWiiInputDevice::Wii_Orientation (int nPad, int & pitch, int & yaw, int & roll)
{
#ifndef GCUBE_EMU

int res;
u32 type;
WPADData *wd;

	res = WPAD_Probe(nPad, &type);
	if (res != WPAD_ERR_NONE)
		return (false);

	wd = WPAD_Data(nPad);

	pitch = wd->orient.pitch;
	yaw = wd->orient.yaw;
	roll  = wd->orient.roll;
#endif
	return (true);
}


bool BibWiiInputDevice::Wii_Cursor (int nPad, int & x, int & y, int & z, int & angle)
{
#ifdef GCUBE_EMU
	if (nPad == 0)
	{
		x = 147;
		extern int nGCubeEmuCounter1;
		y = nGCubeEmuCounter1 % 480;
//		y = 480-205+50-1;

//		y = 480-385+10;

//		x = 25 + 10;
//		y = 480-385 + 10;

//		x = 22 + 20;
//		y = 480-22 - 20;
		
		z = 1;
		static int a = 175;
		angle = a++ / 100;
		return (true);
	}
	else
	{
		return (false);
	}
#else
int res;
u32 type;
WPADData *wd;

	res = WPAD_Probe(nPad, &type);
	if (res != WPAD_ERR_NONE)
		return (false);

	wd = WPAD_Data(nPad);

	if (! wd->ir.valid)
		return (false);

	x = wd->ir.x;
	y = wd->ir.y;
	z = wd->ir.z;
	angle = wd->ir.angle;
	
	return (true);
#endif
}

bool BibWiiInputDevice::Wii_Acceleration (int nPad, int & x, int & y, int & z)
{
#ifndef GCUBE_EMU
int res;
u32 type;
WPADData *wd;

	res = WPAD_Probe(nPad, &type);
	if (res != WPAD_ERR_NONE)
		return (false);

	wd = WPAD_Data(nPad);

	x = wd->accel.x;
	y = wd->accel.y;
	z = wd->accel.z;
	return (true);
#else
	return (false);
#endif
}


bool BibWiiInputDevice::Nunchuk_Stick (int nPad, int & angle, int & magnitude)
{
#ifndef GCUBE_EMU
int res;
u32 type;
WPADData *wd;

	res = WPAD_Probe(nPad, &type);
	if (res != WPAD_ERR_NONE)
		return (false);

	if (type != EXP_NUNCHUK)
		return (false);

	wd = WPAD_Data(nPad);

	if (wd->exp.type != EXP_NUNCHUK)
		return (false);
	
	angle = wd->exp.nunchuk.js.ang;
	magnitude = wd->exp.nunchuk.js.mag * 100;
#endif
	return (true);
}

