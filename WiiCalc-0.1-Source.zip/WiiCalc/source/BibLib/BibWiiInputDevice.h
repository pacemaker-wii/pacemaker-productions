/*
	Wii controller wrapper.
	
*/

#pragma once

#include <gccore.h>
#include <wiiuse/wpad.h>




// No more than 20 actions can be defined.
#define ACTION_MAP_SIZE 20
#define MAX_ACTION_SETS 4

class BibWiiInputDevice
{
public:
	enum eControllerTypes { CTRL_NONE, CTRL_WII_REMOTE, CTRL_EXT_NUNCHUK, CTRL_EXT_CLASSIC, CTRL_GAMECUBE, CTRL_GUITAR_HERO_3 };

	struct SingleAction
	{
		eControllerTypes eController;
		unsigned int ButtonAction;
	};
	
private:
	int nCurActionSet;
	int nNumActions;
	SingleAction ActionMaps [MAX_ACTION_SETS] [ACTION_MAP_SIZE];

public:

	BibWiiInputDevice ();
	~BibWiiInputDevice ();

	void Initialize (int nWidth, int nHeight);
	void ScanInputDevice (void);

	bool IsPresent (eControllerTypes eController, int nPadChan);

	// Action Map functions.
	int DefineAction (SingleAction da [MAX_ACTION_SETS]);

	void SetCurActionSet (int nActionSet);
	int GetCurActionSet (void) { return (nCurActionSet); }
	
	// Use WPAD_CHAN defines to select which controller.
	int ActionDown (int nPadChan, int nActionNum);
	int ActionUp (int nPadChan, int nActionNum);
	int ActionHeld (int nPadChan, int nActionNum);

	// r-r-r-rumble
	void ControlMotor (eControllerTypes eController, int pad, bool bIsOn);
	
	
	/*
		Functions to access controller specific features.
	*/
	
	// Game Cube functions.
	int GC_StickX (int nPad);
	int GC_StickY (int nPad);
//	int GC_SubStickX (int nPad);
//	int GC_SubStickY (int nPad);


	// Wii Remote functions.
	// XY on screen, z is distance from sensor
	bool Wii_Cursor (int nPad, int & x, int & y, int & z, int & angle);
	bool Wii_Orientation (int nPad, int & pitch, int & yaw, int & roll);
	bool Wii_Acceleration (int nPad, int & x, int & y, int & z);
//	bool Wii_GForce (int nPad, int & x, int & y, int & z);

	// Nunchuk functions here:
	// Angle is 0 for straight up, 90 to the right.
	bool Nunchuk_Stick (int nPad, int & angle, int & magnitude);

};



