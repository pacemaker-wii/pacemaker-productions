// SmallBug

#include <wiisprite.h>

class SmallBug
{
private:
	wsp::Sprite SmallBugSprite;
	int xLoc, yLoc;
	int nAngle;
	int nCurStep;
	
	bool bShouldDelete;
public:
	void Initialize (void);
	void Step (void);
	void Draw (void);
	
	bool ShouldDelete (void) { return bShouldDelete; }
};
