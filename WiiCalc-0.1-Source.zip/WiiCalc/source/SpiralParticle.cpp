// SpiralParticle

#include <math.h>

#include "SpiralParticle.h"
#include "ImageServer.h"


void SpiralParticle::Initialize (int _xLoc, int _yLoc)
{
	xLoc = _xLoc;
	yLoc = _yLoc;
	nAngleOffset = rand () % 360;
	bShouldDelete = false;
	nCurStep = 0;

	BlackSpeckSprite.SetImage (isImageServer.GetBlackSpeckImage ());
	BlackSpeckSprite.SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);
	BlackSpeckSprite.SetTransparency (200);

}


void SpiralParticle::Step (void)
{
double nRadius;
int x, y;

	nCurStep ++;
	nCurStep += nCurStep / 100;
	
	nRadius = nCurStep / 10.0;
	x = xLoc + nRadius * cos ((nCurStep+nAngleOffset) * 3.14159 / 180);
	y = yLoc + nRadius * sin ((nCurStep+nAngleOffset) * 3.14159 / 180);
	
	if ((x > 640) || (x < 0) ||
		(y > 480) || (y < 0))
	{
		bShouldDelete = true;
	}

	BlackSpeckSprite.SetPosition (x, y);
}


void SpiralParticle::Draw (void)
{
	BlackSpeckSprite.Draw ();
}
