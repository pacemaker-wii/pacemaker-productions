// Spiral Cluster

#include <math.h>

#include "SmallBugCluster.h"


SmallBugCluster::SmallBugCluster (void)
{
	pSmallBug = NULL;
}

void SmallBugCluster::Initialize (void)
{
	pSmallBug = new SmallBug ();
	pSmallBug->Initialize ();
}

void SmallBugCluster::Render (void)
{
	if (! pSmallBug)
		return;

	pSmallBug->Step ();
	pSmallBug->Draw ();

	if (pSmallBug->ShouldDelete ())
	{
		pSmallBug = NULL;
	}
}

bool SmallBugCluster::IsDone (void)
{
	return  (pSmallBug == NULL);
}
