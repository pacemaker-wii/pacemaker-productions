// CalcWorld.h: interface for the CalcWorld class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include "GameConstants.h"
#include "BibLib/BibWiiInputDevice.h"
#include "BibLib/BibPoint.h"

#include "View.h"
#include "Sound.h"
#include "Calculator.h"
#include "SpiralCluster.h"
#include "SmallBugCluster.h"

class CalcWorld
{
public:	
	enum eGameStateType { SPLASH_SCREEN_PACEMAKER, CALCULATING };
	enum eSelectableObjectsType { OBJ_NONE, 
								  OBJ_0, OBJ_1, OBJ_2, OBJ_3, OBJ_4, OBJ_5, OBJ_6, OBJ_7, OBJ_8, OBJ_9, 
								  OBJ_DOT, OBJ_EQUALS,
								  OBJ_MULTIPLY, OBJ_DIVIDE, OBJ_SUBTRACT, OBJ_ADD, OBJ_FACTORIAL, OBJ_CLEAR,
								  OBJ_PACEMAKER, OBJ_WIICALC_LOGO};

	enum eObjectHighlightType { HIGHLIGHT_NONE, HIGHLIGHT_STANDARD, HIGHLIGHT_WIDE};
	
	BibWiiInputDevice WiiInputDevice;

	// Sounds object
	CalcSound pSound;


private:

	struct FocusObjectMappingType
	{
		int xMin, yMin;
		int xMax, yMax;
		eSelectableObjectsType eObject;
	};
	static FocusObjectMappingType FocusMapping [];

	bool bIsLongLogoHover;
	bool bIsLogoHover;
	unsigned long long llStartLogoHoverTicks;


	class CalcView * pView;
	wsp::Sprite bsBackgroundPic;


	// From WiiInputDevice ActionMap
	//   To skip splash screen.
	int WiiSplashScreenAction;
	int WiiPressAction;
	int WiiHomeAction;
	bool bCursorDataValid;
	int CursorX, CursorY;
	
	eGameStateType eGameState;
	int nGameStateCounter;
	
	eSelectableObjectsType eFocusedObject;	//Object with current focus.
	eSelectableObjectsType ePressedObject;	//Object that is currently being pressed.
	eSelectableObjectsType FindFocusedObject (int x, int y);

	Calculator TheCalculator;
	Calculator::eCalcInputType TranslateWorldToCalculator (eSelectableObjectsType);

	void CheckAndSetLongLogoHover (eSelectableObjectsType eFocusedObject);

	SpiralCluster TheSpiralCluster;
	SmallBugCluster TheSmallBugCluster;
	
public:
	CalcWorld();
	virtual ~CalcWorld();

	void Initialize (int nWidth, int nHeight);
	void UnInitialize (void);


	void SetView (CalcView * inpView) { pView = inpView; }
	CalcView * GetView (void) { return (pView); }

	// Background Sprite accessor method.
	wsp::Sprite & GetBackgroundSprite (void) { return bsBackgroundPic; }


	void UpdateMovement (float fSpeedFactor);

	// Game State methods.
	eGameStateType GetGameState (void) { return (eGameState); }
	void SetGameState (eGameStateType ineGameState) { eGameState = ineGameState; }
	

	eSelectableObjectsType GetFocusedObject (void) { return eFocusedObject;	}
	bool FindObjectLocation (CalcWorld::eSelectableObjectsType eObject, int & x, int & y);
	eObjectHighlightType GetObjectHighlightType (CalcWorld::eSelectableObjectsType eObject);
	eSelectableObjectsType GetPressedObject (void) { return ePressedObject;	}

	double GetDisplayNumber (void) { return TheCalculator.GetDisplayNumber(); }
	const char * GetDisplayString (void);
	bool GetPointer (int & xLoc, int & yLoc);
	
	void RenderClusters (void);
};

