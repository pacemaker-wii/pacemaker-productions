// Spiral Cluster

#include <vector>
#include "SpiralParticle.h"

class SpiralCluster
{
private:
	typedef std::vector<SpiralParticle *> SpiralParticleListType;
	typedef std::vector<SpiralParticle *>::iterator SpiralParticleListIteratorType;

	SpiralParticleListType SpiralParticleList;
	
public:
	void Initialize (void);
	void Render (void);
	bool IsDone (void);

};

