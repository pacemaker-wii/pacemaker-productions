// GameConstants.h

/*
	Version Number to display
*/
#define GAME_VERSION "Version: 0.1, " __DATE__

/*
	PRODUCTION switch (i.e. no debugging stuff)
*/
#define PRODUCTION
//#undef PRODUCTION	// Not in production mode...in debug/development mode.
//#define EXECUTE_UNIT_TESTS

#ifdef EXECUTE_UNIT_TESTS
#undef PRODUCTION
#endif


// These are constants/ranges for the time-independent movement
// stuff.
#define EXPECT_FRAMES_PER_SECOND		60		// Keep at 60 for sprite animation


#define PACEMAKER_SPLASHSCREEN_WAIT_TIME (60 * 60)


