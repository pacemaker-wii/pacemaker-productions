/*

	CalcSound.cpp

*/



#include "Sound.h"
#include <gccore.h>

/*
	These macros include a .wav or a .mp3 binary into the final .elf.
	They also export some symbols to be used to reference the binary data.
*/

#define IncludeWav(name) \
	asm ( \
	   ".globl " #name "\n" \
	   ".balign 32\n" \
	   "" #name "SndData:\n" \
	   ".incbin \"../data/" #name ".wav\"\n" \
		 ); \
	extern u8 name## SndData[];


#define IncludeMp3(name) \
	asm ( \
	   ".globl " #name "\n" \
	   ".globl " #name "Mp3SndData_length\n" \
	   ".balign 32\n" \
	   "" #name "Mp3SndData:\n" \
	   ".incbin \"../data/" #name ".mp3\"\n" \
	   "" #name "Mp3SndData_end:\n" \
	   "" #name "Mp3SndData_length: .long 0\n" \
		 ); \
	extern u8 name## Mp3SndData[]; \
	extern u32 name## Mp3SndData_length;

#if 0
IncludeWav(OUCH);
IncludeWav(NoiseCollector_aluminum);
IncludeMp3(_120701_Tea_and_Crumpets_nal1200_processed_16);
#endif

CalcSound::CalcSound ()
{
#if 0
	LoadSoundWav (SND_OUCH, OUCHSndData);
	LoadSoundWav (SND_CLICK, NoiseCollector_aluminumSndData);

	_120701_Tea_and_Crumpets_nal1200_processed_16Mp3SndData_length = (unsigned int) (& _120701_Tea_and_Crumpets_nal1200_processed_16Mp3SndData_length) - (unsigned int) (_120701_Tea_and_Crumpets_nal1200_processed_16Mp3SndData);
	LoadSoundMp3 (MP3_TEA_AND_CRUMPETS, 
				  _120701_Tea_and_Crumpets_nal1200_processed_16Mp3SndData,
				  _120701_Tea_and_Crumpets_nal1200_processed_16Mp3SndData_length);
#endif
}


int CalcSound::PlaySound (enum CalcSound::eSounds eThisSound)
{
	if (! IsOn ())
		return (0);

	return (BibSound::PlaySound ((int) eThisSound));
}


