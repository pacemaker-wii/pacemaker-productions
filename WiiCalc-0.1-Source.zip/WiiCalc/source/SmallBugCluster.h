// SmallBug Cluster

#include <vector>
#include "SmallBug.h"

class SmallBugCluster
{
private:
	SmallBug * pSmallBug;
	
public:
	SmallBugCluster (void);

	void Initialize (void);
	void Render (void);
	bool IsDone (void);

};

