// SpiralParticle

#include <wiisprite.h>

class SpiralParticle
{
private:
	wsp::Sprite BlackSpeckSprite;
	int xLoc, yLoc;
	int nAngleOffset;
	int nCurStep;
	
	bool bShouldDelete;
public:
	void Initialize (int xLoc, int yLoc);
	void Step (void);
	void Draw (void);
	
	bool ShouldDelete (void) { return bShouldDelete; }
};
