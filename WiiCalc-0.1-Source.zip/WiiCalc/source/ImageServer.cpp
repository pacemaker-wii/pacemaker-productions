
// ImageServer to share image data.

#include <wiisprite.h>
#include "ImageServer.h"

#include "Sprites/CalcBackground.sprite.h"
#include "Sprites/ButtonStdHighlight.sprite.h"
#include "Sprites/ButtonWideHighlight.sprite.h"
#include "Sprites/CalcFont32.sprite.h"
#include "Sprites/PaceMakerSplashScreen.sprite.h"
#include "Sprites/HandPointer.sprite.h"
#include "Sprites/CourierNewFont16.sprite.h"
#include "Sprites/BlackSpeck.sprite.h"
#include "Sprites/SmallBug.sprite.h"


#define DoImageLoadAll(image_var) \
	p ## image_var ## Image = new wsp::Image (); \
	iStatus = p ## image_var ## Image ->LoadImage(image_var); \
	if (iStatus != wsp::IMG_LOAD_ERROR_NONE) \
	{ \
		sprintf (szLastError, "\n\n Image Load Error %s = (%d)\n", #image_var, iStatus); \
		nLastError = iStatus; \
		return (false); \
	}

ImageServer::ImageServer ()
{
}


ImageServer::~ImageServer ()
{
}


bool ImageServer::Initialize (void)
{
wsp::IMG_LOAD_ERROR iStatus;

	szLastError [0] = 0;
	nLastError = 0;
	
	DoImageLoadAll (CalcBackground);
	DoImageLoadAll (ButtonStdHighlight);
	DoImageLoadAll (ButtonWideHighlight);
	DoImageLoadAll (CalcFont32);
	DoImageLoadAll (PaceMakerSplashScreen);
	DoImageLoadAll (HandPointer);
	DoImageLoadAll (CourierNewFont16);
	DoImageLoadAll (BlackSpeck);
	DoImageLoadAll (SmallBug);
	
	return (true);
}

