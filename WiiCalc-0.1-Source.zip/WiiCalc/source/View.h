// CalcView.h: interface for the CalcView class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <wiisprite.h>
#include "BibLib/BibScreenFont.h"
#include "BibLib/BibFrameRate.h"

class CalcView
{
private:
	BibScreenFont Calc_ScreenFont;
	class CalcWorld * pWorld;

	wsp::Sprite PaceMakerSplashScreenSprite;
	wsp::Sprite StdButtonHighlightSprite;
	wsp::Sprite WideButtonHighlightSprite;
	wsp::Sprite CursorPointerSprite;
	
public:
	BibFrameRate fps;

public:
	CalcView();
	~CalcView();

	void Initialize (void);
	void Render (void);
	void SetWorld (class CalcWorld * pinWorld) { pWorld = pinWorld; }

};

