// SmallBugSmallBug

#include <math.h>

#include "SmallBug.h"
#include "ImageServer.h"

#define SMALL_BUG_SPEED 2
#define MAX_ANGLE_DELTA 6

void SmallBug::Initialize (void)
{
	xLoc = rand () % 640;
	yLoc = rand () % 480;
	nAngle = rand () % 360;
	bShouldDelete = false;
	nCurStep = 0;

	SmallBugSprite.SetImage (isImageServer.GetSmallBugImage ());
	SmallBugSprite.SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);
	SmallBugSprite.SetTransparency (200);

}


void SmallBug::Step (void)
{
int nAngleDelta;

	xLoc += SMALL_BUG_SPEED * cos (nAngle * 3.14159 / 180);
	yLoc += SMALL_BUG_SPEED * sin (nAngle * 3.14159 / 180);

	if ((xLoc > 640) || (xLoc < 0) ||
		(yLoc > 480) || (yLoc < 0))
	{
		bShouldDelete = true;
	}

	nAngleDelta = ((rand () - rand ()) % MAX_ANGLE_DELTA);
	nAngle += nAngleDelta;

	SmallBugSprite.SetPosition (xLoc, yLoc);
	SmallBugSprite.SetRotation ((nAngle + 90) / 2);
}


void SmallBug::Draw (void)
{
	SmallBugSprite.Draw ();
}
