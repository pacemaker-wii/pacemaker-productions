
// ImageServer to share image data.

/*
	To add a new image:
	
	1.  Add a DefineImage() MACRO in the ImageServer class.
	2.  Add DoImageLoadAll to Initialize() function.
	3.  Add appropriate include file.

*/

#define DefineImage(name) private: wsp::Image * p ##name## Image; \
		public:  inline wsp::Image * Get ##name## Image (void) { return p ##name## Image; }


class ImageServer
{
private:

public:
	ImageServer ();
	~ImageServer ();

	bool Initialize (void);
	char szLastError [128];
	int nLastError;


	DefineImage(CalcBackground);
	DefineImage(ButtonStdHighlight);
	DefineImage(ButtonWideHighlight);
	DefineImage(CalcFont32);
	DefineImage(PaceMakerSplashScreen);
	DefineImage(HandPointer);
	DefineImage(CourierNewFont16);
	DefineImage(BlackSpeck);
	DefineImage(SmallBug);

};


extern ImageServer isImageServer;
