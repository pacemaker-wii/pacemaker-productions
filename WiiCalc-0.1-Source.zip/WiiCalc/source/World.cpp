// CalcWorld.cpp: implementation for the CalcWorld class.
//
//////////////////////////////////////////////////////////////////////

#include <ogc/lwp_watchdog.h>

#include "GameConstants.h"
#include "World.h"
#include "ImageServer.h"



static BibWiiInputDevice::SingleAction saSplashScreenAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2},
											{BibWiiInputDevice::CTRL_GAMECUBE, PAD_BUTTON_A}
																};

static BibWiiInputDevice::SingleAction saPressAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_A},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_2},
											{BibWiiInputDevice::CTRL_GAMECUBE, PAD_BUTTON_A}
																};

static BibWiiInputDevice::SingleAction saHomeAction [MAX_ACTION_SETS] = {
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_HOME},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_HOME},
											{BibWiiInputDevice::CTRL_WII_REMOTE, WPAD_BUTTON_HOME},
											{BibWiiInputDevice::CTRL_GAMECUBE, PAD_TRIGGER_Z}
																};


CalcWorld::FocusObjectMappingType CalcWorld::FocusMapping [] = 
{
	{ 125, 480-145, 125+75, 480-145+50, CalcWorld::OBJ_0 },
	{ 125, 480-205, 125+75, 480-205+50, CalcWorld::OBJ_1 },
	{ 225, 480-205, 225+75, 480-205+50, CalcWorld::OBJ_2 },
	{ 325, 480-205, 325+75, 480-205+50, CalcWorld::OBJ_3 },
	{ 125, 480-265, 125+75, 480-265+50, CalcWorld::OBJ_4 },
	{ 225, 480-265, 225+75, 480-265+50, CalcWorld::OBJ_5 },
	{ 325, 480-265, 325+75, 480-265+50, CalcWorld::OBJ_6 },
	{ 125, 480-325, 125+75, 480-325+50, CalcWorld::OBJ_7 },
	{ 225, 480-325, 225+75, 480-325+50, CalcWorld::OBJ_8 },
	{ 325, 480-325, 325+75, 480-325+50, CalcWorld::OBJ_9 },
	{ 225, 480-145, 225+75, 480-145+50, CalcWorld::OBJ_DOT },
	{ 525, 480-145, 525+75, 480-145+50, CalcWorld::OBJ_EQUALS },
	{ 425, 480-265, 425+75, 480-265+50, CalcWorld::OBJ_MULTIPLY },
	{ 425, 480-325, 425+75, 480-325+50, CalcWorld::OBJ_DIVIDE },
	{ 425, 480-205, 425+75, 480-205+50, CalcWorld::OBJ_SUBTRACT },
	{ 425, 480-145, 425+75, 480-145+50, CalcWorld::OBJ_ADD },
	{ 325, 480-145, 325+75, 480-145+50, CalcWorld::OBJ_FACTORIAL },
	{ 247, 480-385, 247+128, 480-385+47, CalcWorld::OBJ_CLEAR },
	{  22, 480- 87, 22+595,  480-25   , CalcWorld::OBJ_PACEMAKER },
	{  25, 480-385, 25+150,  480-385+50, CalcWorld::OBJ_WIICALC_LOGO },
};


//!!!! Delete this after debug is complete.
int nDebugCounterL = 0;
int nDebugCounterR = 0;

#ifdef GCUBE_EMU
int nGCubeEmuCounter1 = 0;
extern bool bEmuForceButton;
#endif











CalcWorld::CalcWorld ()
{
}

CalcWorld::~CalcWorld ()
{
}



void CalcWorld::Initialize (int nWidth, int nHeight)
{
	WiiInputDevice.Initialize (nWidth, nHeight);

	// Instantiate button actions.
	WiiSplashScreenAction = WiiInputDevice.DefineAction (saSplashScreenAction);
	WiiPressAction = WiiInputDevice.DefineAction (saPressAction);
	WiiHomeAction = WiiInputDevice.DefineAction (saHomeAction);

	pSound.Initialize ();

	// Load background
	bsBackgroundPic.SetImage (isImageServer.GetCalcBackgroundImage ());
	bsBackgroundPic.SetPosition(0, 0);


	// Set game state to playing
	eGameState = CalcWorld::SPLASH_SCREEN_PACEMAKER;

	// Reset.
	nGameStateCounter = 0;
	bCursorDataValid = false;
	eFocusedObject = OBJ_NONE;
	ePressedObject = OBJ_NONE;
	bIsLongLogoHover = false;
	bIsLogoHover = false;
	llStartLogoHoverTicks = 0;
	
	TheCalculator.Initialize ();
}





/*
	Main Control Loop.

	This is called every game loop.
*/
void CalcWorld::UpdateMovement (float fSpeedFactor)
{
int x, y, z, angle;

	WiiInputDevice.ScanInputDevice ();


	// State machine:
	switch (eGameState)
	{
		case CalcWorld::CALCULATING:
			nGameStateCounter ++;
			
			bCursorDataValid = WiiInputDevice.Wii_Cursor (0, x, y, z, angle);
			if (bCursorDataValid)
			{
				CursorX = x;
				CursorY = y;
				eFocusedObject = FindFocusedObject (x, y);
				ePressedObject = OBJ_NONE;
				
#ifdef GCUBE_EMU
nGCubeEmuCounter1 ++;
if ((nGameStateCounter % 100) == 50)
	bEmuForceButton = true;
#endif
				if (WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiPressAction))
				{
					ePressedObject = eFocusedObject;
					// Do some crazy calculator state machine work here.
					TheCalculator.NewCalculatorInput (TranslateWorldToCalculator (ePressedObject));

					if (ePressedObject == OBJ_PACEMAKER)
					{
						if (TheSmallBugCluster.IsDone ())
							TheSmallBugCluster.Initialize ();
					}

				}
				
				if (WiiInputDevice.ActionHeld (WPAD_CHAN_0, WiiPressAction))
				{
					ePressedObject = eFocusedObject;
				}

#ifdef GCUBE_EMU
bEmuForceButton = false;
#endif
				if (WiiInputDevice.ActionHeld (WPAD_CHAN_0, WiiHomeAction))
				{
					exit (0);
				}
			}
			else
			{
				eFocusedObject = OBJ_NONE;
			}

			CheckAndSetLongLogoHover (eFocusedObject);

			if (GetDisplayNumber () == 42)
			{
				if (TheSpiralCluster.IsDone ())
					TheSpiralCluster.Initialize ();
			}


		break;

		default:
		case CalcWorld::SPLASH_SCREEN_PACEMAKER:

			nGameStateCounter ++;
#ifdef GCUBE_EMU
			nGameStateCounter += 20;
#endif

			if (WiiInputDevice.ActionDown (WPAD_CHAN_0, WiiSplashScreenAction) ||
			    (nGameStateCounter > PACEMAKER_SPLASHSCREEN_WAIT_TIME))
			{
				nGameStateCounter = 0;
				eGameState = CalcWorld::CALCULATING;
			}

			// Don't do any processing.
			return;
		break;
	}

}




CalcWorld::eSelectableObjectsType CalcWorld::FindFocusedObject (int x, int y)
{
int nArraySize;

	nArraySize = sizeof (FocusMapping) / sizeof (FocusObjectMappingType);
	for (int i = 0; i < nArraySize; i ++)
	{
		if ((FocusMapping [i].xMin <= x) && (x <= FocusMapping [i].xMax) &&
			(FocusMapping [i].yMin <= y) && (y <= FocusMapping [i].yMax))
		{
			return (FocusMapping [i].eObject);
		}
	}
	
	return (OBJ_NONE);
}


bool CalcWorld::FindObjectLocation (eSelectableObjectsType eObject, int & x, int & y)
{
int nArraySize;

	nArraySize = sizeof (FocusMapping) / sizeof (FocusObjectMappingType);
	for (int i = 0; i < nArraySize; i ++)
	{
		if (eObject == FocusMapping [i].eObject)
		{
			x = FocusMapping [i].xMin;
			y = FocusMapping [i].yMin;
			return (true);
		}
	}

	return (false);
}


CalcWorld::eObjectHighlightType CalcWorld::GetObjectHighlightType (CalcWorld::eSelectableObjectsType eObject)
{
	switch (eObject)
	{
		default:
		case OBJ_NONE:
		case OBJ_PACEMAKER:
		case OBJ_WIICALC_LOGO:
			return (HIGHLIGHT_NONE);
		break;
		
		case OBJ_0:
		case OBJ_1:
		case OBJ_2:
		case OBJ_3:
		case OBJ_4:
		case OBJ_5:
		case OBJ_6:
		case OBJ_7:
		case OBJ_8:
		case OBJ_9:
		case OBJ_DOT:
		case OBJ_EQUALS:
		case OBJ_MULTIPLY:
		case OBJ_DIVIDE:
		case OBJ_SUBTRACT:
		case OBJ_ADD:
		case OBJ_FACTORIAL:
			return (HIGHLIGHT_STANDARD);
		break;
		
		case OBJ_CLEAR:
			return (HIGHLIGHT_WIDE);
		break;
	}
}


Calculator::eCalcInputType CalcWorld::TranslateWorldToCalculator (CalcWorld::eSelectableObjectsType eObject)
{
	switch (eObject)
	{
		default:
		case CalcWorld::OBJ_NONE:
		case CalcWorld::OBJ_PACEMAKER:
		case CalcWorld::OBJ_WIICALC_LOGO:
			return (Calculator::INP_NONE);
		break;
		
		case CalcWorld::OBJ_0:
			return (Calculator::INP_0);
		break;
		
		case CalcWorld::OBJ_1:
			return (Calculator::INP_1);
		break;
		
		case CalcWorld::OBJ_2:
			return (Calculator::INP_2);
		break;
		
		case CalcWorld::OBJ_3:
			return (Calculator::INP_3);
		break;
		
		case CalcWorld::OBJ_4:
			return (Calculator::INP_4);
		break;
		
		case CalcWorld::OBJ_5:
			return (Calculator::INP_5);
		break;
		
		case CalcWorld::OBJ_6:
			return (Calculator::INP_6);
		break;
		
		case CalcWorld::OBJ_7:
			return (Calculator::INP_7);
		break;
		
		case CalcWorld::OBJ_8:
			return (Calculator::INP_8);
		break;
		
		case CalcWorld::OBJ_9:
			return (Calculator::INP_9);
		break;
		
		case CalcWorld::OBJ_DOT:
			return (Calculator::INP_DOT);
		break;
		
		case CalcWorld::OBJ_EQUALS:
			return (Calculator::INP_EQUALS);
		break;
		
		case CalcWorld::OBJ_MULTIPLY:
			return (Calculator::INP_MULTIPLY);
		break;
		
		case CalcWorld::OBJ_DIVIDE:
			return (Calculator::INP_DIVIDE);
		break;
		
		case CalcWorld::OBJ_SUBTRACT:
			return (Calculator::INP_SUBTRACT);
		break;
		
		case CalcWorld::OBJ_ADD:
			return (Calculator::INP_ADD);
		break;
		
		case CalcWorld::OBJ_FACTORIAL:
			return (Calculator::INP_FACTORIAL);
		break;
		
		case CalcWorld::OBJ_CLEAR:
			return (Calculator::INP_CLEAR);
		break;
	}
}


bool CalcWorld::GetPointer (int & xLoc, int & yLoc)
{
	xLoc = CursorX;
	yLoc = CursorY;
	return (bCursorDataValid);
}



void CalcWorld::CheckAndSetLongLogoHover (eSelectableObjectsType eFocusedObject)
{
unsigned long long llCurLogoHoverTicks;

	// Not focused on logo, turn off hover.
	if (eFocusedObject != OBJ_WIICALC_LOGO)
	{
		bIsLongLogoHover = false;
		bIsLogoHover = false;
		llStartLogoHoverTicks = 0;
		return;
	}

	// Still focused on logo, and we've been here a long time.
	else if (bIsLongLogoHover)
	{
		return;
	}

	// Still focused on logo, and we've been here a short time.
	else if (bIsLogoHover)
	{
		llCurLogoHoverTicks = gettime ();
		
		if (llCurLogoHoverTicks - llStartLogoHoverTicks > (secs_to_ticks(3)))
		{
			bIsLongLogoHover = true;
			return;
		}
	}

	// Just started to focus on the logo.
	else
	{
		llStartLogoHoverTicks = gettime ();
		bIsLogoHover = true;
		return;
	}
}


const char * CalcWorld::GetDisplayString (void)
{
	if (bIsLongLogoHover)
	{
		return (GAME_VERSION);
	}
	
	return TheCalculator.GetDisplayString();
}


void CalcWorld::RenderClusters (void)
{
	TheSpiralCluster.Render ();
	TheSmallBugCluster.Render ();
}
