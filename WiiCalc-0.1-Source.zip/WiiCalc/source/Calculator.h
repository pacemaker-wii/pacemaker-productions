// Calculator Logic

class Calculator
{
public:

	enum eCalcInputType { INP_NONE, 
					  INP_0, INP_1, INP_2, INP_3, INP_4, INP_5, INP_6, INP_7, INP_8, INP_9, 
					  INP_DOT, INP_EQUALS,
					  INP_MULTIPLY, INP_DIVIDE, INP_SUBTRACT, INP_ADD, INP_FACTORIAL, INP_CLEAR};

private:
	enum eCalcStateType { STATE_INPUT_LEFT, STATE_INPUT_RIGHT, STATE_INPUT_SECOND_LEFT, STATE_INPUT_SECOND_RIGHT };

	double fDisplayData;
	double fTotalData;
	int nNumDecimalsEntered;	// Right of decimal point
	int nNumDigitsEntered;		// Total digits
	eCalcInputType eOperation;
	eCalcStateType eState;

	char szDisplayString [64];

	bool IsDigit (eCalcInputType eCalcInput);
	bool IsOperation (eCalcInputType eCalcInput);
	bool IsImmediateOperation (eCalcInputType eCalcInput);
	int GetDigit (eCalcInputType eCalcInput);
	void ResetEntryData (void);
	double AddDigitLeftOfDecimal (double fOriginal, double fAdd);
	double AddDigitRightOfDecimal (double fOriginal, double fAdd);
	double PerformOperation (double fOperand1, double fOperand2, eCalcInputType eOperation);
	double Factorial (double fOperand1);

	void SetForOperation (eCalcInputType eCalcInput);

	const char * GetStateString (eCalcStateType eState);
	const char * GetCalcInputString (eCalcInputType eCalcInput);


public:

	void Initialize (void);
	double GetDisplayNumber (void) { return fDisplayData; }
	const char * GetDisplayString (void);
	double GetTotalNumber (void) { return fTotalData; }
	void NewCalculatorInput (eCalcInputType eCalcInput);

};
