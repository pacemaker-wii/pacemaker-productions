// Spiral Cluster

#include <math.h>

#include "SpiralCluster.h"

void SpiralCluster::Initialize (void)
{
int i, nRadius;
int x, y;
SpiralParticle * sp;

	nRadius = 75;
	for (i = 0; i < 180; i ++)
	{
		sp = new SpiralParticle ();
		x = 320 + nRadius * cos (i*2 * 3.14159 / 180);
		y = 240 + nRadius * sin (i*2 * 3.14159 / 180);

		sp->Initialize (x, y);
		
		SpiralParticleList.push_back (sp);
	}

}

void SpiralCluster::Render (void)
{
SpiralParticleListIteratorType spit;
SpiralParticle * sp;

	
		// Iterate through saved samples and put them into the new buffer.
	for (spit = SpiralParticleList.begin(); spit != SpiralParticleList.end(); /* Increment is below */)
	{
		sp = (*spit);

		sp->Step ();
		sp->Draw ();
		
		// Remove from list now.
		if (sp->ShouldDelete ())
		{
			delete (*spit);
			spit = SpiralParticleList.erase (spit);
		}
		else
		{
			spit++;
		}

	}

}

bool SpiralCluster::IsDone (void)
{
	return  (SpiralParticleList.empty ());
}
