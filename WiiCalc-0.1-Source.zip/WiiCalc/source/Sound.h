/*

	CalcSound.h

*/

#include "BibLib/BibSound.h"

class CalcSound : public BibSound
{
private:

public:
	CalcSound ();

	enum eSounds { SND_CLICK };

	int PlaySound (eSounds eThisSound);

};
