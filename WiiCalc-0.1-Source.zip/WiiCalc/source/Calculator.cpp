// Calculator Logic

#include <math.h>
#include "World.h"

#define MAX_INPUTTED_DIGITS 999

//#define PRINTF_LOGGING

void Calculator::Initialize (void)
{
	fDisplayData = 0;
	fTotalData = 0;
	nNumDecimalsEntered = 0;
	nNumDigitsEntered = 0;
	eState = STATE_INPUT_LEFT;
}



void Calculator::NewCalculatorInput (eCalcInputType eCalcInput)
{

	if (eCalcInput == INP_CLEAR)
	{
		Initialize ();
		return;
	}

#ifdef PRINTF_LOGGING
printf ("eState: %s, eCalcInput: %s (%0.3f,%0.3f)\n", GetStateString(eState), GetCalcInputString(eCalcInput), fDisplayData, fTotalData);
#endif

	switch (eState)
	{
		case STATE_INPUT_LEFT:
			if (IsDigit (eCalcInput))
				fDisplayData = AddDigitLeftOfDecimal (fDisplayData, GetDigit(eCalcInput));
	
			if (eCalcInput == INP_DOT)
			{
				eState = STATE_INPUT_RIGHT;
			}
			
			if (IsImmediateOperation (eCalcInput))
			{
				fDisplayData = PerformOperation (fDisplayData, 0, eCalcInput);
				ResetEntryData ();
			}
			
			if (IsOperation (eCalcInput))
			{
				SetForOperation (eCalcInput);
				ResetEntryData ();
			}
		break;
		
		case STATE_INPUT_RIGHT:
			if (IsDigit (eCalcInput))
			{
				fDisplayData = AddDigitRightOfDecimal (fDisplayData, GetDigit(eCalcInput));
			}
			
			if (IsImmediateOperation (eCalcInput))
			{
				fDisplayData = PerformOperation (fDisplayData, 0, eCalcInput);
				ResetEntryData ();
			}

			if (IsOperation (eCalcInput))
			{
				SetForOperation (eCalcInput);
				ResetEntryData ();
			}
		break;
		
		case STATE_INPUT_SECOND_LEFT:
			if (IsDigit (eCalcInput))
			{
				fDisplayData = AddDigitLeftOfDecimal (fDisplayData, GetDigit(eCalcInput));
			}
			
			if (eCalcInput == INP_DOT)
			{
				eState = STATE_INPUT_SECOND_RIGHT;
			}
			
			if (IsOperation (eCalcInput))
			{
				fDisplayData = PerformOperation (fTotalData, fDisplayData, eOperation);
				fTotalData = fDisplayData;
				eState = STATE_INPUT_SECOND_LEFT;
				SetForOperation (eCalcInput);
				ResetEntryData ();
			}

			if (eCalcInput == INP_EQUALS)
			{
				fDisplayData = PerformOperation (fTotalData, fDisplayData, eOperation);
				fTotalData = 0;
				ResetEntryData ();
				eState = STATE_INPUT_LEFT;
			}
			
			if (IsImmediateOperation (eCalcInput))
			{
				fDisplayData = PerformOperation (fTotalData, fDisplayData, eOperation);
				fTotalData = 0;
				ResetEntryData ();
				eState = STATE_INPUT_LEFT;

				fDisplayData = PerformOperation (fDisplayData, 0, eCalcInput);
			}

		break;
		
		case STATE_INPUT_SECOND_RIGHT:
			if (IsDigit (eCalcInput))
			{
				fDisplayData = AddDigitRightOfDecimal (fDisplayData, GetDigit(eCalcInput));
			}

			if (IsOperation (eCalcInput))
			{
				fDisplayData = PerformOperation (fTotalData, fDisplayData, eOperation);
				SetForOperation (eCalcInput);
				ResetEntryData ();
			}

			if (eCalcInput == INP_EQUALS)
			{
				fDisplayData = PerformOperation (fTotalData, fDisplayData, eOperation);
				fTotalData = 0;
				eState = STATE_INPUT_LEFT;
				ResetEntryData ();
			}

			if (IsImmediateOperation (eCalcInput))
			{
				fDisplayData = PerformOperation (fTotalData, fDisplayData, eOperation);
				fTotalData = 0;
				eState = STATE_INPUT_LEFT;
				ResetEntryData ();

				fDisplayData = PerformOperation (fDisplayData, 0, eCalcInput);
			}
		break;
	}
	

}


void Calculator::ResetEntryData (void)
{
	nNumDecimalsEntered = 0;
	nNumDigitsEntered = 0;
}

double Calculator::AddDigitLeftOfDecimal (double fOriginal, double fAdd)
{
	if (nNumDigitsEntered == 0)
	{
		// Need reset for immediate operations?
		nNumDigitsEntered ++;
		return (fAdd);
	}

	if (nNumDigitsEntered > MAX_INPUTTED_DIGITS)
		return (fOriginal);
	nNumDigitsEntered ++;
	return (fOriginal * 10.0 + fAdd);
}

double Calculator::AddDigitRightOfDecimal (double fOriginal, double fAdd)
{
	if (nNumDigitsEntered > MAX_INPUTTED_DIGITS)
		return (fOriginal);
		
	nNumDigitsEntered ++;
	nNumDecimalsEntered ++;
	return (fOriginal + fAdd / pow (10, nNumDecimalsEntered));
}

bool Calculator::IsDigit (eCalcInputType eCalcInput)
{
	if ((eCalcInput >= INP_0) && (eCalcInput <= INP_9))
		return (true);
	else
		return (false);
}


bool Calculator::IsOperation (eCalcInputType eCalcInput)
{
	if ((eCalcInput >= INP_MULTIPLY) && (eCalcInput <= INP_ADD))
		return (true);
	else
		return (false);
}

bool Calculator::IsImmediateOperation (eCalcInputType eCalcInput)
{
	if (eCalcInput == INP_FACTORIAL)
		return (true);
	else
		return (false);
}

int Calculator::GetDigit (eCalcInputType eCalcInput)
{
	if (! IsDigit (eCalcInput))
		return (-1);
	else
		return (eCalcInput - INP_0);
}

void Calculator::SetForOperation (eCalcInputType eCalcInput)
{
	eOperation = eCalcInput;
	eState = STATE_INPUT_SECOND_LEFT;
	fTotalData = fDisplayData;
	fDisplayData = 0;
	ResetEntryData ();
}


double Calculator::PerformOperation (double fOperand1, double fOperand2, eCalcInputType eOperation)
{
	switch (eOperation)
	{
		default:
			return (NAN);
		break;
		
		case INP_MULTIPLY:
			return (fOperand1 * fOperand2);
		break;

		case INP_DIVIDE:
			return (fOperand1 / fOperand2);
		break;

		case INP_SUBTRACT:
			return (fOperand1 - fOperand2);
		break;
		
		case INP_ADD:
			return (fOperand1 + fOperand2);
		break;
	
		case INP_FACTORIAL:
			return Factorial (fOperand1);
		break;
	
	}
}


double Calculator::Factorial (double fOperand1)
{
int i;
double fTotal;

	fTotal = 1;
	if ((int) fOperand1 <= 1)
	{
		return (1);
	}	

	if ((int) fOperand1 >= 170)
	{
		return (INFINITY);
	}
  
	for (i = 2; i <= (int) fOperand1; i ++)
    {
        fTotal *= i;
    }
	
    return fTotal;
}


const char * Calculator::GetStateString (eCalcStateType eState)
{
	switch (eState)
	{
		case STATE_INPUT_LEFT: return "I_LEFT";
		case STATE_INPUT_RIGHT: return "I_RIGHT";
		case STATE_INPUT_SECOND_LEFT: return "I_SEC_LEFT";
		case STATE_INPUT_SECOND_RIGHT: return "I_SEC_RIGHT";
	}

	return ("INVALID");
}

const char * Calculator::GetCalcInputString (eCalcInputType eCalcInput)
{
	switch (eCalcInput)
	{
		case INP_NONE: return "NONE";
		case INP_0: return "0";
		case INP_1: return "1";
		case INP_2: return "2";
		case INP_3: return "3";
		case INP_4: return "4";
		case INP_5: return "5";
		case INP_6: return "6";
		case INP_7: return "7";
		case INP_8: return "8";
		case INP_9: return "9";
		case INP_DOT: return ".";
		case INP_EQUALS: return "=";
		case INP_MULTIPLY: return "*";
		case INP_DIVIDE: return "/";
		case INP_SUBTRACT: return "-";
		case INP_ADD: return "+";
		case INP_FACTORIAL: return "!";
		case INP_CLEAR: return "clear";
	}
	
	return ("INVALID");
}


const char * Calculator::GetDisplayString (void)
{
double dDisplayNum;

	dDisplayNum = GetDisplayNumber ();

	sprintf (szDisplayString, "%0.8g", dDisplayNum);

	return (szDisplayString);
}

