// CalcView.h: interface for the CalcView class.
//
//////////////////////////////////////////////////////////////////////

#include "View.h"
#include "World.h"
#include "BibLib/BibGraphicsHelper.h"
#include "ImageServer.h"

#include "Sprites/CalcFont32Metrics.sprite.h" 


#define CALC_FONT_WIDTH ((int) (CalcFont32Metrics[0]))
 
 
 
extern int nDebugCounterR;
extern int nDebugCounterL;

CalcView::CalcView()
{
}

CalcView::~CalcView()
{
}


#ifndef PRODUCTION
static int nFrameCounter = 0;
#endif


void CalcView::Initialize (void)
{
	Calc_ScreenFont . Initialize (isImageServer.GetCalcFont32Image (), 
									isImageServer.GetCalcFont32Image ()->GetWidth() / 16, 
									isImageServer.GetCalcFont32Image ()->GetHeight() / 16, 
									CalcFont32Metrics);

	PaceMakerSplashScreenSprite.SetImage (isImageServer.GetPaceMakerSplashScreenImage ());

	StdButtonHighlightSprite.SetImage (isImageServer.GetButtonStdHighlightImage ());
	WideButtonHighlightSprite.SetImage (isImageServer.GetButtonWideHighlightImage ());
	CursorPointerSprite.SetImage (isImageServer.GetHandPointerImage ());
	CursorPointerSprite.SetRefPixelPositioning(wsp::REFPIXEL_POS_PIXEL);
	CursorPointerSprite.SetTransparency (200);
}


/*
	Render the view (to the screen)
*/
void CalcView::Render (void)
{
int x, y;
bool bObjectFound, bIsPressed, bPointerIsValid;
CalcWorld::eSelectableObjectsType eObject;
#ifndef PRODUCTION
char szBuf [1024];
#endif


	// Check to see if we have been initialized.
	if (! pWorld)
		return;

	

	/*
		Do rendering, backgrounds and foregrounds.
	*/
	switch (pWorld -> GetGameState ())
	{
		default:
		case CalcWorld::SPLASH_SCREEN_PACEMAKER:
			PaceMakerSplashScreenSprite.Draw();
			return;	// Don't display anything else, to preserve the purity of the PaceMaker splash screen.
		break;



		case CalcWorld::CALCULATING:
			/*
				Put background bitmaps in here.
			*/
			pWorld -> GetBackgroundSprite ().Draw ();
			
			// Display highlighted buttons.
			
			eObject = pWorld->GetPressedObject ();
			bIsPressed = true;
			if (eObject == CalcWorld::OBJ_NONE)
			{
				eObject = pWorld -> GetFocusedObject ();
				bIsPressed = false;
			}
			if (eObject != CalcWorld::OBJ_NONE)
			{
				bObjectFound = pWorld->FindObjectLocation (eObject, x, y);
				if (bObjectFound)
				{
					CalcWorld::eObjectHighlightType eHighlightType;
					eHighlightType = pWorld->GetObjectHighlightType(eObject);
					if (eHighlightType == CalcWorld::HIGHLIGHT_STANDARD)
					{
						StdButtonHighlightSprite.SetPosition (x - 5, y - 5);
						if (bIsPressed)
							StdButtonHighlightSprite.SetZoom(0.80);
						else
							StdButtonHighlightSprite.SetZoom(1.0);
						StdButtonHighlightSprite.Draw ();
					}
					else if (eHighlightType == CalcWorld::HIGHLIGHT_WIDE)
					{
						WideButtonHighlightSprite.SetPosition (x - 7, y - 6);
						if (bIsPressed)
							WideButtonHighlightSprite.SetZoom(0.75);
						else
							WideButtonHighlightSprite.SetZoom(1.0);
						WideButtonHighlightSprite.Draw ();
					}
					
				}
			}
			
			// Render Calculator Display number.
			int xLoc = 640 - 30 - (strlen (pWorld->GetDisplayString()) * CALC_FONT_WIDTH);
			if (xLoc < 25)
				xLoc = 25;
			Calc_ScreenFont.DisplayText (xLoc, 35, pWorld->GetDisplayString());


			bPointerIsValid = pWorld->GetPointer (x, y);
			if (bPointerIsValid)
			{
				CursorPointerSprite.SetPosition (x, y);
				CursorPointerSprite.Draw ();
			}

			pWorld->RenderClusters ();
			
		break;
	}
	
	

#ifndef PRODUCTION
	/*
		Display debug text.
	*/
	sprintf (szBuf, "Pressed: %d (%d,%d)", pWorld->GetPressedObject (), x, y);
	Calc_ScreenFont.DisplayText (25, 25, szBuf);
	

	sprintf (szBuf, "(%d)", nFrameCounter ++);
	Calc_ScreenFont.DisplayText (40, 50, szBuf);

	/*
		Put the fps at the bottom.
	*/
	sprintf (szBuf, "fps %02.2f", fps.fps);
	Calc_ScreenFont.DisplayText (40, 380, szBuf);
#endif

	
}



