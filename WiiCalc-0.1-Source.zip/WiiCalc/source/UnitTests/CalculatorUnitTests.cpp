// Calculator Unit Tests

#include <stdio.h>
#include <string.h>
#include <math.h>

#include "../Calculator.h"

int nPassedCounter;
int nFailedCounter;

//#define PRINT_PASSES

bool CheckExpectedData (double fExpected, double fActual, double fMargin, const char * szTestName)
{
	if ((fActual >= fExpected - fMargin) && 
		(fActual <= fExpected + fMargin))
	{
		nPassedCounter ++;
#ifdef PRINT_PASSES
		printf ("%s (%g == %g): passed\n", szTestName, fExpected, fActual);
#endif
		return (true);
	}
	else
	{
		nFailedCounter ++;
		printf ("%s: FAILED (%g != %g (+/- %g)\n", szTestName, fExpected, fActual, fMargin);

		printf ("\t%g >= %g\n", fActual, fExpected - fMargin);
		printf ("\t%g <= %g\n", fActual, fExpected + fMargin);
		printf ("\tDelta %g\n", fActual - fExpected);

		return (false);
	}
}


bool CheckExpectedDataString (const char * szExpected, const char * szActual, const char * szTestName)
{
	if (strcmp (szExpected, szActual) == 0)
	{
		nPassedCounter ++;
#ifdef PRINT_PASSES
		printf ("%s (\"%s\" == \"%s\"): passed\n", szTestName, szExpected, szActual);
#endif
		return (true);
	}
	else
	{
		nFailedCounter ++;
		printf ("%s: FAILED (\"%s\" != \"%s\")\n", szTestName, szExpected, szActual);
		return (false);
	}
}


void TestClear (Calculator * pCalc)
{
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	CheckExpectedDataString (pCalc->GetDisplayString(), "0", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 0, 0, __func__);
}

void TestSimpleAdd (Calculator * pCalc)
{
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_2);
	pCalc -> NewCalculatorInput (Calculator::INP_ADD);
	pCalc -> NewCalculatorInput (Calculator::INP_2);
	pCalc -> NewCalculatorInput (Calculator::INP_EQUALS);
	CheckExpectedDataString (pCalc->GetDisplayString(), "4", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 4, 0, __func__);
}

bool TestSimpleSubtract (Calculator * pCalc)
{
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_7);
	pCalc -> NewCalculatorInput (Calculator::INP_SUBTRACT);
	pCalc -> NewCalculatorInput (Calculator::INP_2);
	pCalc -> NewCalculatorInput (Calculator::INP_EQUALS);
	CheckExpectedDataString (pCalc->GetDisplayString(), "5", __func__);
	return (CheckExpectedData (pCalc->GetDisplayNumber(), 5, 0, __func__));
}

bool TestSimpleMultiply (Calculator * pCalc)
{
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_7);
	pCalc -> NewCalculatorInput (Calculator::INP_MULTIPLY);
	pCalc -> NewCalculatorInput (Calculator::INP_2);
	pCalc -> NewCalculatorInput (Calculator::INP_EQUALS);
	CheckExpectedDataString (pCalc->GetDisplayString(), "14", __func__);
	return (CheckExpectedData (pCalc->GetDisplayNumber(), 14, 0, __func__));
}

bool TestSimpleDivide (Calculator * pCalc)
{
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_8);
	pCalc -> NewCalculatorInput (Calculator::INP_DIVIDE);
	pCalc -> NewCalculatorInput (Calculator::INP_2);
	pCalc -> NewCalculatorInput (Calculator::INP_EQUALS);
	CheckExpectedDataString (pCalc->GetDisplayString(), "4", __func__);
	return (CheckExpectedData (pCalc->GetDisplayNumber(), 4, 0, __func__));
}

void TestFactorialOne (Calculator * pCalc)
{
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_3);
	pCalc -> NewCalculatorInput (Calculator::INP_FACTORIAL);
	CheckExpectedDataString (pCalc->GetDisplayString(), "6", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 6, 0, __func__);
}
	
void TestFactorialTwo (Calculator * pCalc)
{
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_3);
	pCalc -> NewCalculatorInput (Calculator::INP_ADD);
	pCalc -> NewCalculatorInput (Calculator::INP_4);
	pCalc -> NewCalculatorInput (Calculator::INP_FACTORIAL);
	CheckExpectedDataString (pCalc->GetDisplayString(), "5040", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 7*6*5*4*3*2, 0, __func__);
}


bool TestComplicatedEquation (Calculator * pCalc)
{
	// 8 * 2 / 2 + 9 =
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_8);
	pCalc -> NewCalculatorInput (Calculator::INP_MULTIPLY);
	pCalc -> NewCalculatorInput (Calculator::INP_2);
	pCalc -> NewCalculatorInput (Calculator::INP_DIVIDE);
	pCalc -> NewCalculatorInput (Calculator::INP_2);
	pCalc -> NewCalculatorInput (Calculator::INP_ADD);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_EQUALS);
	CheckExpectedDataString (pCalc->GetDisplayString(), "17", __func__);
	return (CheckExpectedData (pCalc->GetDisplayNumber(), 17, 0, __func__));
}

void TestFloatingInput (Calculator * pCalc)
{
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_8);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_1);
	pCalc -> NewCalculatorInput (Calculator::INP_2);
	pCalc -> NewCalculatorInput (Calculator::INP_3);
	CheckExpectedDataString (pCalc->GetDisplayString(), "8.123", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 8.123, 0, __func__);
}

void TestComplicatedFloatingEquation (Calculator * pCalc)
{
	// 8.1 * 2.9 / 2.5 + 9.99 =
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_8);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_1);
	CheckExpectedDataString (pCalc->GetDisplayString(), "8.1", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 8.1, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_MULTIPLY);
	pCalc -> NewCalculatorInput (Calculator::INP_2);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_DIVIDE);
	CheckExpectedDataString (pCalc->GetDisplayString(), "0", __func__);
	CheckExpectedData (pCalc->GetTotalNumber(), 8.1 * 2.9, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_2);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_5);
	pCalc -> NewCalculatorInput (Calculator::INP_ADD);
	CheckExpectedDataString (pCalc->GetDisplayString(), "0", __func__);
	CheckExpectedData (pCalc->GetTotalNumber(), 8.1 * 2.9 / 2.5, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_EQUALS);
	CheckExpectedDataString (pCalc->GetDisplayString(), "19.386", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 8.1 * 2.9 / 2.5 + 9.99, 0, __func__);
}

void TestFloatingEquation1 (Calculator * pCalc)
{
	// 8.1 * 2.9 / 2.5 + 9.99 =
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_8);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_1);
	CheckExpectedDataString (pCalc->GetDisplayString(), "8.1", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 8.1, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_MULTIPLY);
	pCalc -> NewCalculatorInput (Calculator::INP_2);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	CheckExpectedDataString (pCalc->GetDisplayString(), "2.9", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 2.9, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_EQUALS);
	CheckExpectedDataString (pCalc->GetDisplayString(), "23.49", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 8.1 * 2.9, 0, __func__);
}

void TestInvalidDots (Calculator * pCalc)
{
	// .8..1. * .2..9.. = .
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_8);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_1);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	CheckExpectedDataString (pCalc->GetDisplayString(), "0.81", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 0.81, 0.001, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_MULTIPLY);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_2);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	CheckExpectedDataString (pCalc->GetDisplayString(), "0.29", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 0.29, 0.01, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_EQUALS);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	CheckExpectedDataString (pCalc->GetDisplayString(), "0.2349", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 0.81 * 0.29, 0.01, __func__);
}

void TestClear2 (Calculator * pCalc)
{
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_8);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_1);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	CheckExpectedDataString (pCalc->GetDisplayString(), "0", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 0, 0, __func__);
	CheckExpectedData (pCalc->GetTotalNumber(), 0, 0, __func__);
}


void TestFactorialInvalid (Calculator * pCalc)
{
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_1);
	pCalc -> NewCalculatorInput (Calculator::INP_6);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	CheckExpectedDataString (pCalc->GetDisplayString(), "169", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 169, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_FACTORIAL);
	CheckExpectedDataString (pCalc->GetDisplayString(), "4.269068e+304", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 4.269068e+304, 1.0e+296, __func__);

	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_1);
	pCalc -> NewCalculatorInput (Calculator::INP_SUBTRACT);
	pCalc -> NewCalculatorInput (Calculator::INP_7);
	pCalc -> NewCalculatorInput (Calculator::INP_EQUALS);
	CheckExpectedDataString (pCalc->GetDisplayString(), "-6", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), -6, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_FACTORIAL);
	CheckExpectedDataString (pCalc->GetDisplayString(), "1", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 1, 0, __func__);

	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_1);
	pCalc -> NewCalculatorInput (Calculator::INP_7);
	pCalc -> NewCalculatorInput (Calculator::INP_5);
	pCalc -> NewCalculatorInput (Calculator::INP_FACTORIAL);
	CheckExpectedDataString (pCalc->GetDisplayString(), "inf", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), INFINITY, 0, __func__);

}

void TestDigitEntryLeft (Calculator * pCalc)
{
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	CheckExpectedDataString (pCalc->GetDisplayString(), "9", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 9, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	CheckExpectedDataString (pCalc->GetDisplayString(), "999999", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 999999.0, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	CheckExpectedDataString (pCalc->GetDisplayString(), "99999999", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 99999999.0, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	CheckExpectedDataString (pCalc->GetDisplayString(), "99999999", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 99999999.0, 0, __func__);
}

void TestDigitEntryRight (Calculator * pCalc)
{
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	CheckExpectedDataString (pCalc->GetDisplayString(), "9", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 9, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_DOT);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	CheckExpectedDataString (pCalc->GetDisplayString(), "9.9999", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 9.9999, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	CheckExpectedDataString (pCalc->GetDisplayString(), "9.9999999", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 9.9999999, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_9);
	CheckExpectedDataString (pCalc->GetDisplayString(), "9.9999999", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 9.999999, 9e-06, __func__);
}


void TestImmediate1 (Calculator * pCalc)
{
	pCalc -> NewCalculatorInput (Calculator::INP_CLEAR);
	pCalc -> NewCalculatorInput (Calculator::INP_6);
	CheckExpectedDataString (pCalc->GetDisplayString(), "6", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 6, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_FACTORIAL);
	CheckExpectedDataString (pCalc->GetDisplayString(), "720", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 720, 0, __func__);
	pCalc -> NewCalculatorInput (Calculator::INP_6);
	CheckExpectedDataString (pCalc->GetDisplayString(), "6", __func__);
	CheckExpectedData (pCalc->GetDisplayNumber(), 6, 0, __func__);
}

void DoCalculatorUnitTests (void)
{
Calculator * pCalc;

	nPassedCounter = 0;
	nFailedCounter = 0;


	pCalc = new Calculator ();
	pCalc -> Initialize ();

	/*
		Tests
	*/

	TestClear (pCalc);
	TestSimpleAdd (pCalc);
	TestSimpleSubtract (pCalc);
	TestFactorialOne (pCalc);
	TestFactorialTwo (pCalc);
	TestSimpleMultiply (pCalc);
	TestSimpleDivide (pCalc);
	TestComplicatedEquation (pCalc);
	TestFloatingInput (pCalc);
	TestFloatingEquation1(pCalc);
	TestComplicatedFloatingEquation(pCalc);
	TestInvalidDots (pCalc);
	TestClear2 (pCalc);
	TestFactorialInvalid (pCalc);
//	TestDigitEntryLeft (pCalc);
//	TestDigitEntryRight (pCalc);
	TestImmediate1 (pCalc);
	
	printf ("%d Passed, %d Failed\n", nPassedCounter, nFailedCounter);

	delete (pCalc);
}


